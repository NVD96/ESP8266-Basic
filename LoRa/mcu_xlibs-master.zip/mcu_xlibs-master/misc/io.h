#define reg8(addr)    (*((volatile uint8_t *)(addr)))
#define reg16(addr)    (*((volatile uint16_t *)(addr)))
#define reg32(addr)    (*((volatile uint32_t *)(addr)))
