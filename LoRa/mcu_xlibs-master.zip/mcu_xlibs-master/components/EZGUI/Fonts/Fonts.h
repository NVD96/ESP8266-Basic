#ifndef __FONTS_H__
#define __FONTS_H__

#include "ezgui_font.h"

extern const Font_t Arial;
extern const Font_t Lobster_Num_16;

#endif
