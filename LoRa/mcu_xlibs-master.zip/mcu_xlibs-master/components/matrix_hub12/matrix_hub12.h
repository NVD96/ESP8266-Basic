/**
  ******************************************************************************
  * @file           : matrix_hub12.h
  * @brief          : Thư viện điều khiển LED ma trận HUB12.
  * @author         : Tiêu Tuấn Bảo
  ******************************************************************************
  * @attention
  * 
  */

#ifndef __MATRIX_RGB__
#define __MATRIX_RGB__

typedef struct {
    
} MATRIX_HUB12_t;

#endif
