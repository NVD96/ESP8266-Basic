# Blynk Sample for ESP32
This is the skeleton to connect to GSM/WiFi, get sensor values and submit to Blynk
* For ESP32
* Watch dog to reconnect networks, Blynk... To reset board after 10 errors.
* Cronjobs to get sensor values
