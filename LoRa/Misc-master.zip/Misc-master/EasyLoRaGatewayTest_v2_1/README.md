# Easy LoRa Gateway Test v2.1
Able to receive from two LoRa chips

![image](https://user-images.githubusercontent.com/29994971/62278263-e9e65000-b471-11e9-9bb7-d6f3ef131766.png)
