# LICENSE

* FREE for personal use.
* For commercial use, please contact us at http://iotthinks.com
* We reserve all the rights.