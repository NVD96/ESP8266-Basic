## EasyLoRaIndustrialNode_BTSerial
* Communicate from phone to ESP32 via bluetooth.
* Reference: https://randomnerdtutorials.com/esp32-bluetooth-classic-arduino-ide/
