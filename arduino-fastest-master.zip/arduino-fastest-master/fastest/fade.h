void fadeLED(int analogLedPIN);
void turnOffFadeLED(int ledPIN); 
