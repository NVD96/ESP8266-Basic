void setTopLine(String line, LiquidCrystal lcd);
void setBottomLine(String line, LiquidCrystal lcd);

void setBothLCDLines(String line1, String line2, LiquidCrystal lcd);
