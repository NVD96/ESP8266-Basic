void writeTo74HC595(byte b);
void turnOnWinLightForPlayer(int playerNumber);
void turnOffAllPlayerLights();
