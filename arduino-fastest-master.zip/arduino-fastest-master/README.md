# arduino-fastest

## Introduction
This repository contains the code that powers a 4 player fastest reaction time game for Arduino.  In order to be useful you'll need to build the project circuit defined at https://circuits.io/circuits/3000931-arduino-four-player-fastest-reaction-time-game 

A full tutorial on building the complete game is at http://www.instructables.com/id/Arduino-Fastest-Reaction-Time-Game-for-1-4-Players/

