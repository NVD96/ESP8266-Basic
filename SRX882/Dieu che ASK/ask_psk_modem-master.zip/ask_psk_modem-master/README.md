# ASK and PSK Modulation and Demodulation
This is a simple simulation of ASK (Amplitude Shift Keying) and PSK (Phase Shift Keying) modulation and demodulation in Labcenter Proteus.
For more info see the "report-1.pdf".

![](https://i.imgur.com/260ktwR.jpg)
![](https://i.imgur.com/r2jRRPf.png)
![](https://i.imgur.com/gaM5vFi.png)
![](https://i.imgur.com/U6Bkx39.png)
