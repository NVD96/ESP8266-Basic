
module.exports = {
  port: 4884,
  backend: {
    type: "redis",
    prefix: "/a"
  }
};
