
module.exports = {
  port: 4883,
  backend: {
    type: "redis"
  }
};
