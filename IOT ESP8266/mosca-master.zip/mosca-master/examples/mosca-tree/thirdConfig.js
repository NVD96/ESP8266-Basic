
module.exports = {
  port: 4885,
  backend: {
    type: "mqtt",
    port: 4884,
    prefix: "/t"
  }
};
