#ifndef _LEA_H_
#define _LEA_H_

#include "ssd1306_hal/io.h"
#include <stdint.h>

extern const uint8_t Lea [] PROGMEM;

#endif
