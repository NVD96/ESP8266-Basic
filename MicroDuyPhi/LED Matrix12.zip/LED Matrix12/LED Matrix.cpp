// LED Matrix.cpp : Defines the entry point for the application.
//
#include "LED Matrix.h"//#include "resource.h"
#include "Objects.h"

//#define _WIN32_WINDOWS 0x0410
#pragma comment(linker, "/OPT:NOWIN98")

#define MAX_LOADSTRING	4096
#define SIZE_CX			800
#define SIZE_CY			600
#define LEFT_WIDTH		180
#define GAP				3

PTextMatrix *TextMatrix;
//MatrixDisp *hMatrixDisp;
MATRIX_INFOR *matrix = NULL;// = new(MATRIXINFOR);
MATRIX_INFOR matrixtemp; // tao ra 1 template de khi khoi tao luc dau cho dialog properties lay tham so ma chua can khoi tao con tro
PAGE *page, *pagetemp, *pageactive;
LineDisp *line, *linetemp;//, *lineactive;
// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szProjectName[MAX_PATH];
TCHAR szLocation[MAX_PATH];
TCHAR szFullNameDir[MAX_PATH];
TCHAR szFullNameFile[MAX_PATH];
UINT pagenumber = 0, fontnumber = 0;

HWND hWnd, hTreeView, hStatus, hToolbar;
HMENU SysMenu;
BOOL open_status = FALSE; // project dang duoc mo
//BOOL edit_status = FALSE;
UINT tvX, tvY;

HTREEITEM hRoot;
TVITEM tvCurrent, tvParentCurrent;
HIMAGELIST hImgTV, hImgDrag;	// Value returned by 'imagelist' keyword in parser
BOOL itemDragging = FALSE;
BOOL item_in_tree;
WNDPROC OldTVProc = NULL;

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	NewProject(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Property(HWND, UINT, WPARAM, LPARAM);
int CALLBACK		BrowseCallbackProc(HWND, UINT, LPARAM, LPARAM);

void				CreateTreeView(HWND);
void				OnButtonDown();
LRESULT CALLBACK	TreeViewProc(HWND, UINT, WPARAM, LPARAM);
void				InsertRoot(LPSTR);
void				InsertPage();
void				InsertFont();
void				InsertLine(short);
TVITEM				GetTVInfo(HTREEITEM); // lay cac thong tin cua hitem dang chon
LRESULT				ProcessTreeViewNotification(LPNMHDR);

void InitValue()
{
	matrixtemp.mt_height = 1; //16
	matrixtemp.mt_width = 8;
	matrixtemp.mt_bank = 0;
	matrixtemp.mt_color_number = 0;
	matrixtemp.mt_color_level = 0;
	matrixtemp.mt_ROMsize = 2;
}

void InsertRootPtr()
{
	matrix = new _1matrix_infor;
	matrix->first_page = NULL;
	strcpy(matrix->mt_sign, "LMP");
	strcpy(matrix->mt_title, szProjectName);
}

void InsertPagePtr(UINT pagepos)
{
	UINT i;
	page = (PAGE*)malloc(sizeof(PAGE)); // new _2page; //	pagetemp = matrix->mt_first_page; // tim page dau tien
	page->first_line = NULL;
	if (pagepos == 0) // click tai hRoot xay ra 2 truong hop - nut rong & nut khong rong
	{
		page->lastpage = NULL;
		if (matrix->first_page == NULL) // Root rong
		{
			page->nextpage = NULL;
			matrix->first_page = page;
			return;
		} else // add at Root khi Root <> NULL =. chen vao dau list
		{
			page->nextpage = matrix->first_page;
			matrix->first_page->lastpage = page;
			matrix->first_page = page;
			return;
		}
	} else
	{
		pagetemp = matrix->first_page;
		i = 1;
		while (i < pagepos) // tim den nut vi tri i
		{
			pagetemp = pagetemp->nextpage;
			i++;
		}
		page->lastpage = pagetemp;
		page->nextpage = pagetemp->nextpage;
		pagetemp->nextpage = page;
		if (page->nextpage != NULL) // page cuoi cung
			page->nextpage->lastpage = page;
	}
}

void InsertLinePtr(UINT pagepos, UINT linepos)
{
	UINT i;
	line = new LineDisp(TextMatrix->pMatrixView->hWndMatrixView, 0, 0);
	pagetemp = matrix->first_page;
	i = 1;
	while (i < pagepos) // tim den nut vi tri Page i
	{
		pagetemp = pagetemp->nextpage;
		i++;
	}
	if (linepos == 0) // click tai Page
	{
		line->lastline = NULL;
		if (pagetemp->first_line == NULL) // nut rong
		{
			line->nextline = NULL;
			pagetemp->first_line = line;
			return;
		} else // nut khong rong
		{
			line->nextline = pagetemp->first_line;
			pagetemp->first_line->lastline = line;
			pagetemp->first_line = line;
			return;
		}
	} else // click tai line
	{
		linetemp = pagetemp->first_line;
		i = 1;
		while (i < linepos) // tim den nut vi tri i
		{
			linetemp = linetemp->nextline;
			i++;
		}
		line->lastline = linetemp;
		line->nextline = linetemp->nextline;
		linetemp->nextline = line;
		if (line->nextline != NULL)
			line->nextline->lastline = line;
	}
}

void UpdateMatrixProject() // cap nhat cac trang thai menu
{
	char str[20];
	TCHAR StatusTextSize[MAX_LOADSTRING];
	TCHAR StatusTextROM[MAX_LOADSTRING];
	UINT EnableFlag;
	if (!open_status)
		EnableFlag = MF_DISABLED | MF_GRAYED; else EnableFlag = MF_ENABLED;
	EnableMenuItem(SysMenu, IDM_PROJECT_CLOSE, EnableFlag);
	EnableMenuItem(SysMenu, IDM_PROJECT_SAVE, EnableFlag);
	EnableMenuItem(SysMenu, IDM_PROJECT_SAVEAS, EnableFlag);

	EnableMenuItem(SysMenu, 1, MF_BYPOSITION | EnableFlag);

	EnableMenuItem(SysMenu, IDM_MATRIX_PROPERTIES, EnableFlag);
	EnableMenuItem(SysMenu, IDM_MATRIX_DELETE, EnableFlag);
	EnableMenuItem(SysMenu, IDM_MATRIX_CONVERTTOIMAGE, EnableFlag);
	EnableMenuItem(SysMenu, IDM_MATRIX_CONVERTALL, EnableFlag);
	EnableMenuItem(SysMenu, IDM_ROM_EXPORTPROJECT, EnableFlag);
	EnableMenuItem(SysMenu, IDM_ROM_DEMO, EnableFlag);
	DrawMenuBar(hWnd);

	strcpy(StatusTextSize, "Matrix: ");
	strcpy(StatusTextROM, "ROM/FLASH: ");
	if (open_status)
	{
		itoa(arr_height[matrixtemp.mt_height] * 16, str, 10);
		strcat(StatusTextSize, str);
		strcat(StatusTextSize, "x");
		itoa(arr_width[matrixtemp.mt_width] * 32, str, 10);
		strcat(StatusTextSize, str);
		strcat(StatusTextSize, "*");
		itoa(arr_color[matrixtemp.mt_color_number], str, 10);
		strcat(StatusTextSize, str);
		strcat(StatusTextSize, "color(s)");
		itoa(arr_ROMsize[matrixtemp.mt_ROMsize] * 64, str, 10);
		strcat(StatusTextROM, str);
		strcat(StatusTextROM, " KBytes");
	} else
	{
		strcpy(StatusTextSize, "Ready!");
		strcpy(StatusTextROM, "Create new.../ Open...");
	}
	SendMessage(hStatus, SB_SETTEXT, 0, (LPARAM)StatusTextSize);
	SendMessage(hStatus, SB_SETTEXT, 1, (LPARAM)StatusTextROM);
}

void UpdateSubMenu(UINT index)
{
	if (index == 0)
	{
		EnableMenuItem(SysMenu, IDM__MATRIX_NEW_TEXT, MF_DISABLED | MF_GRAYED);
		EnableMenuItem(SysMenu, IDM__MATRIX_NEW_IMAGE, MF_DISABLED | MF_GRAYED);
		EnableMenuItem(SysMenu, IDM__MATRIX_NEW_DATETIME, MF_DISABLED | MF_GRAYED);
		EnableMenuItem(SysMenu, IDM__MATRIX_NEW_CHAR, MF_DISABLED | MF_GRAYED);
	} else
	{
		if (index/256 < 256) // char
		{
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_TEXT, MF_DISABLED | MF_GRAYED);
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_IMAGE, MF_DISABLED | MF_GRAYED);
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_DATETIME, MF_DISABLED | MF_GRAYED);
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_CHAR, MF_ENABLED);
		}
		else // text - image - date
		{
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_TEXT, MF_ENABLED);
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_IMAGE, MF_ENABLED);
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_DATETIME, MF_ENABLED);
			EnableMenuItem(SysMenu, IDM__MATRIX_NEW_CHAR, MF_DISABLED | MF_GRAYED);
		}
	}
	DrawMenuBar(hWnd);
}

void UpdateProperty() // cap nhat cac thuoc tinh matrix
{
	matrix->mt_height = matrixtemp.mt_height;
	matrix->mt_width = matrixtemp.mt_width;
	matrix->mt_bank = matrixtemp.mt_bank;
	matrix->mt_color_number = matrixtemp.mt_color_number;
	matrix->mt_color_level = matrixtemp.mt_color_level;
	matrix->mt_ROMsize = matrixtemp.mt_ROMsize;
}

// for matrix
void NewMatrixProject()
{
	InsertRoot(szProjectName);
	InsertRootPtr();
	open_status = TRUE;
	pagenumber = 0;
	fontnumber = 0;
	InsertRootPtr();
	UpdateProperty();
	UpdateMatrixProject();
	SetFocus(hTreeView);
}

void CloseMatrixProject()
{
	TreeView_DeleteAllItems(hTreeView);
	open_status = FALSE;

	UpdateMatrixProject();
	if (matrix) delete(matrix);
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	HACCEL hAccelTable;
	MyRegisterClass(hInstance);
	if (!InitInstance(hInstance, nCmdShow)) return FALSE;
	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_LEDMATRIX);
	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	return msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;
	InitCommonControls();
	wcex.cbSize = sizeof(WNDCLASSEX); 
	wcex.style			= 0;//CS_CLASSDC;//0;//CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_LEDMATRIX);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_3DFACE+1); //(HBRUSH)(COLOR_3DFACE+1); //(HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_LEDMATRIX;
	wcex.lpszClassName	= "LEDMATRIX";
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);
	return RegisterClassEx(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	int cx, cy;
	cx = GetSystemMetrics(SM_CXFULLSCREEN);
	cy = GetSystemMetrics(SM_CYFULLSCREEN);
	hInst = hInstance; // Store instance handle in our global variable
	hWnd = CreateWindowEx(0/*WS_EX_CLIENTEDGE*/, "LEDMATRIX", "LED Matrix", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
		//CW_USEDEFAULT, 0, CW_USEDEFAULT, 0,
		(cx - SIZE_CX) / 2, (cy - SIZE_CY) / 2, SIZE_CX, SIZE_CY,
		NULL, NULL, hInstance, NULL);
	
	TextMatrix = new (PTextMatrix)(hWnd, &matrixtemp);
	if ((cx <= SIZE_CX) || (cy <= SIZE_CY)) ShowWindow(hWnd, SW_SHOWMAXIMIZED); else ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	LPNMHDR pNotifyStruct;
	int statwidths[] = {LEFT_WIDTH, LEFT_WIDTH + LEFT_WIDTH, -1};
	TBBUTTON tbb[3];
	TBADDBITMAP tbab;
	RECT rc;
	int iTVHeight;
	RECT rcTool;
	int iToolHeight;
	RECT rcStatus;
	int iStatusHeight;
	MINMAXINFO * mmiStruct = (MINMAXINFO*)lParam;
	POINT ptPoint;

	switch (message) 
	{
		case WM_CREATE:
			SysMenu = GetMenu(hWnd); //UpdateMatrixProject();
			CreateTreeView(hWnd);
			InitValue();

			// Create Toolbar
			hToolbar = CreateWindowEx(0, TOOLBARCLASSNAME, NULL, WS_CHILD | WS_VISIBLE | TBSTYLE_FLAT | TBSTYLE_TOOLTIPS, 0, 0, 0, 0,
				hWnd, (HMENU)0/*IDC_MAIN_TOOL*/, hInst, NULL);
			SendMessage(hToolbar, TB_BUTTONSTRUCTSIZE, (WPARAM)sizeof(TBBUTTON), 0);
			
			tbab.hInst = HINST_COMMCTRL;
			tbab.nID = IDB_STD_SMALL_COLOR;
			SendMessage(hToolbar, TB_ADDBITMAP, 0, (LPARAM)&tbab);

			ZeroMemory(tbb, sizeof(tbb));
			tbb[0].iBitmap = STD_FILENEW;
			tbb[0].fsState = TBSTATE_ENABLED;
			tbb[0].fsStyle = TBSTYLE_BUTTON;
			tbb[0].idCommand = IDM_PROJECT_NEW;

			tbb[1].iBitmap = STD_FILEOPEN;
			tbb[1].fsState = TBSTATE_ENABLED;
			tbb[1].fsStyle = TBSTYLE_BUTTON;
			tbb[1].idCommand = IDM_PROJECT_OPEN;

			tbb[2].iBitmap = STD_FILESAVE;
			tbb[2].fsState = TBSTATE_ENABLED;
			tbb[2].fsStyle = TBSTYLE_BUTTON;
			tbb[2].idCommand = IDM_PROJECT_SAVE;

			SendMessage(hToolbar, TB_ADDBUTTONS, sizeof(tbb)/sizeof(TBBUTTON), (LPARAM)&tbb);

			// Create Status bar
			hStatus = CreateWindowEx(0, STATUSCLASSNAME, NULL,
				WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP | SBT_TOOLTIPS, 0, 0, 0, 0,
				hWnd, (HMENU)0, hInst, NULL);
			SendMessage(hStatus, SB_SETPARTS, sizeof(statwidths)/sizeof(int), (LPARAM)statwidths);
			UpdateMatrixProject();
			break;

		case WM_SIZE:
			// Size Toolbar
			SendMessage(hToolbar, TB_AUTOSIZE, 0, 0);
			GetWindowRect(hToolbar, &rcTool);
			iToolHeight = rcTool.bottom - rcTool.top;
			// Size status bar and get height
			SendMessage(hStatus, WM_SIZE, 0, 0);
			GetWindowRect(hStatus, &rcStatus);
			iStatusHeight = rcStatus.bottom - rcStatus.top;
			// Size TreeView
			GetClientRect(hWnd, &rc);
			iTVHeight = rc.bottom - iToolHeight - iStatusHeight;
			SetWindowPos(hTreeView, NULL, 0, iToolHeight, LEFT_WIDTH, iTVHeight, SWP_NOZORDER);
			// Size matrix object
			SetWindowPos(TextMatrix->hWndPTextMatrix, NULL, LEFT_WIDTH + GAP, iToolHeight, rc.right - LEFT_WIDTH - GAP, iTVHeight, SWP_NOZORDER);
//			SetWindowPos(hMatrixDisp->hWndMatrix, NULL, LEFT_WIDTH + GAP, iToolHeight, rc.right - LEFT_WIDTH - GAP, iTVHeight - 100, SWP_NOZORDER);
			//hMatrixDisp->OnSize();
			break;

		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_PROJECT_NEW:
					if (DialogBox(hInst, (LPCTSTR)IDD_NEW_PROJECT, hWnd, (DLGPROC)NewProject) == TRUE)
						if (DialogBox(hInst, (LPCTSTR)IDD_PROPERTY, hWnd, (DLGPROC)Property) == TRUE)
						{
							if (open_status) CloseMatrixProject();
							NewMatrixProject();
						}
					break;
				case IDM_PROJECT_OPEN:
					TextMatrix->OnUpdatePTextMatrix(pageactive);
					break;
				case IDM_PROJECT_SAVE:
					TextMatrix->pMatrixView->zoom -= 1;
					TextMatrix->OnUpdatePTextMatrix(pageactive);
					break;
				case IDM__MATRIX_NEW_PAGE:
					if (tvX < fontnumber) // chon vi tri de chen doi tuong
						InsertPagePtr(fontnumber); // chen vao cuoi
					else
						InsertPagePtr(tvX); // chen vao giua
					InsertPage();
					break;
				case IDM__MATRIX_NEW_FONT:
					if (tvX > fontnumber) // chon vi tri de chen doi tuong
						InsertPagePtr(fontnumber); // chen vao dau danh sach Page
					else
						InsertPagePtr(tvX); // chen vao giua
					InsertFont();
					break;
				case IDM__MATRIX_NEW_TEXT:
					InsertLinePtr(tvX, tvY);
					InsertLine(1);
					break;
				case IDM__MATRIX_NEW_IMAGE:
					InsertLinePtr(tvX, tvY);
					InsertLine(2);
					break;
				case IDM__MATRIX_NEW_DATETIME:
					InsertLinePtr(tvX, tvY);
					InsertLine(3);
					break;
				case IDM__MATRIX_NEW_CHAR:
					InsertLinePtr(tvX, tvY);
					InsertLine(4);
					break;
				case IDM_MATRIX_PROPERTIES:
					if (DialogBox(hInst, (LPCTSTR)IDD_PROPERTY, hWnd, (DLGPROC)Property) == TRUE)
						TextMatrix->OnUpdatePTextMatrix(pageactive);
					break;
				case IDM_PROJECT_CLOSE:
					if (open_status) CloseMatrixProject();
					break;
				case IDM_ABOUT:
					DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
					break;
				case IDM_PROJECT_EXIT:
					DestroyWindow(hWnd);
					break;
				default:
					return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;

		case WM_NOTIFY:
			pNotifyStruct = (LPNMHDR)lParam;
			if (pNotifyStruct->hwndFrom == hTreeView)
				return ProcessTreeViewNotification(pNotifyStruct);
			break;

		case WM_GETMINMAXINFO:
			ptPoint.x = SIZE_CX / 2;	//Minimum width of the window.
			ptPoint.y = SIZE_CY / 2;	//Minimum height of the window.
			mmiStruct->ptMinTrackSize = ptPoint;
		//	ptPoint.x = GetSystemMetrics(SM_CXMAXIMIZED);	//Maximum width of the window.
		//	ptPoint.y = GetSystemMetrics(SM_CYMAXIMIZED);	//Maximum height of the window.
		//	mmiStruct->ptMaxTrackSize = ptPoint;
			break;
		case WM_CLOSE:
			DestroyWindow(hWnd);
			return 0;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

LRESULT CALLBACK NewProject(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	BROWSEINFO browseInfo;
	LPMALLOC pMalloc;
	LPITEMIDLIST pidl;
	TCHAR szDir[MAX_PATH];
	BOOL nRet;

	switch (message)
	{
		case WM_INITDIALOG:
			if (GetCurrentDirectory(sizeof(szDir)/sizeof(TCHAR), szDir))
				SetDlgItemText(hDlg, IDC_EDIT2, szDir);
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					GetDlgItemText(hDlg, IDC_EDIT1, szProjectName, MAX_PATH);
					GetDlgItemText(hDlg, IDC_EDIT2, szLocation, MAX_PATH);
					lstrcpy(szFullNameDir, szLocation);
					lstrcat(szFullNameDir, "\\");
					lstrcat(szFullNameDir, szProjectName);
					lstrcat(szFullNameDir, "\\");
					lstrcpy(szFullNameFile, szFullNameDir);
					lstrcat(szFullNameFile, szProjectName);
					lstrcat(szFullNameFile, ".lmp");
					if (!CreateDirectory(szFullNameDir, NULL))
					{
						MessageBox(hDlg, "Please enter valid project name!", "Error!", MB_OK | MB_ICONERROR);
						return FALSE;
					}
					EndDialog(hDlg, LOWORD(wParam));
					return TRUE;
				case IDC_LISTDIR:
					SHGetMalloc(&pMalloc);
					ZeroMemory(&browseInfo, sizeof(browseInfo));
					browseInfo.hwndOwner = hDlg;
					browseInfo.pidlRoot = NULL;// ConvertPathToLpItemIdList(Path); 
					browseInfo.pszDisplayName = 0;//szDisplayName;
					browseInfo.lpszTitle = "...to save the LED MATRIX project:";//lpszTitle;   // passed in
					browseInfo.ulFlags = BIF_RETURNONLYFSDIRS | BIF_STATUSTEXT;   // also passed in
					browseInfo.lpfn = BrowseCallbackProc;
					browseInfo.lParam = (LPARAM)hDlg;
					pidl = SHBrowseForFolder(&browseInfo);
					if (pidl)
					{
						SHGetPathFromIDList(pidl, szDir);
						SetDlgItemText(hDlg, IDC_EDIT2, szDir);
						nRet = TRUE;
					}
					else
						nRet = FALSE;
					pMalloc->Free(pidl);
					pMalloc->Release();
					return nRet;
				case IDCANCEL:
					EndDialog(hDlg, LOWORD(wParam));
					return FALSE;
			}
			break;
	}
	return FALSE;
}

int CALLBACK BrowseCallbackProc(HWND hWndBRCB, UINT uMsg, LPARAM lp, LPARAM pData) 
{
	TCHAR szDir[MAX_PATH];
	switch(uMsg) 
	{
		case BFFM_INITIALIZED: 
			if (GetDlgItemText((HWND)pData, IDC_EDIT2, szDir, MAX_PATH))
				SendMessage(hWndBRCB, BFFM_SETSELECTION, TRUE, (LPARAM)szDir);
			SetWindowText(hWndBRCB, "Browse the folder...");
			break;

		case BFFM_SELCHANGED:
		{
			if (SHGetPathFromIDList((LPITEMIDLIST) lp ,szDir))
				SendMessage(hWndBRCB, BFFM_SETSTATUSTEXT, 0, (LPARAM)szDir);
			else
				SendMessage(hWndBRCB, BFFM_SETSTATUSTEXT, 0, 0);
			break;
		}
		default:
		   break;
	}
    return 0;
}

LRESULT CALLBACK Property(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	BYTE i, bank_sel;
	char str1[20];
	HWND hwnd_bank[3];

	switch (message)
	{
		case WM_INITDIALOG:
			for (i = 0; i < sizeof(arr_height); i++)
			{			//	itoa(arr_height[i], str1, 10);
				itoa(arr_height[i] * 8, str1, 10);			//	lstrcat( str1, " (");			//	lstrcat( str1, str2);			//	lstrcat( str1, ")");
				SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)str1);
			}
			SendDlgItemMessage(hDlg, IDC_COMBO1, CB_SETCURSEL, matrixtemp.mt_height, NULL);

			for (i = 0; i < sizeof(arr_width); i++)
			{			//	itoa(arr_width[i], str1, 10);
				itoa(arr_width[i] * 16, str1, 10);			//	lstrcat( str1, " (");			//	lstrcat( str1, str2);			//	lstrcat( str1, ")");
				SendDlgItemMessage(hDlg, IDC_COMBO2, CB_ADDSTRING, NULL, (LPARAM)str1);
			}
			SendDlgItemMessage(hDlg, IDC_COMBO2, CB_SETCURSEL, matrixtemp.mt_width, NULL);

			for (i = 0; i < 3; i++)
				if (matrixtemp.mt_bank == i)
					SendDlgItemMessage(hDlg, IDC_RADIO1 + i, BM_SETCHECK, BST_CHECKED, 0);

			for (i = 0; i < sizeof(arr_color); i++)
			{
				itoa(arr_color[i], str1, 10);
				lstrcat( str1, " color");
				if (i>0) strcat( str1, "s");
				SendDlgItemMessage(hDlg, IDC_COMBO3, CB_ADDSTRING, NULL, (LPARAM)str1);
			}
			SendDlgItemMessage(hDlg, IDC_COMBO3, CB_SETCURSEL, matrixtemp.mt_color_number, NULL);

			for (i = 0; i < sizeof(arr_colorlv); i++)
			{
				itoa(arr_colorlv[i], str1, 10);
				lstrcat( str1, " level");
				if (i>0) strcat( str1, "s");
				SendDlgItemMessage(hDlg, IDC_COMBO4, CB_ADDSTRING, NULL, (LPARAM)str1);
			}
			SendDlgItemMessage(hDlg, IDC_COMBO4, CB_SETCURSEL, matrixtemp.mt_color_level, NULL);

			for (i = 0; i < sizeof(arr_ROMsize); i++)
			{
				itoa(arr_ROMsize[i]*64, str1, 10);
				lstrcat( str1, " KBytes");
				SendDlgItemMessage(hDlg, IDC_COMBO5, CB_ADDSTRING, NULL, (LPARAM)str1);
			}
			SendDlgItemMessage(hDlg, IDC_COMBO5, CB_SETCURSEL, matrixtemp.mt_ROMsize, NULL);
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					matrixtemp.mt_height = (BYTE)SendDlgItemMessage(hDlg, IDC_COMBO1, CB_GETCURSEL, 0, 0);
					matrixtemp.mt_width = (BYTE)SendDlgItemMessage(hDlg, IDC_COMBO2, CB_GETCURSEL, 0, 0);
					for (i=0; i<3; i++)
						if (SendDlgItemMessage(hDlg, IDC_RADIO1 + i, BM_GETCHECK, 0, 0) == BST_CHECKED) matrixtemp.mt_bank = i;
					matrixtemp.mt_color_number = (BYTE)SendDlgItemMessage(hDlg, IDC_COMBO3, CB_GETCURSEL, 0, 0);
					matrixtemp.mt_color_level = (BYTE)SendDlgItemMessage(hDlg, IDC_COMBO4, CB_GETCURSEL, 0, 0);
					matrixtemp.mt_ROMsize = (BYTE)SendDlgItemMessage(hDlg, IDC_COMBO5, CB_GETCURSEL, 0, 0);

					if (matrix != NULL)
					{
						UpdateProperty(); // lay lai cac tham so cho matrix sau khi thay doi property
						UpdateMatrixProject(); // update status bar
					}
					EndDialog(hDlg, LOWORD(wParam));
					return TRUE;

				case IDC_COMBO1:
					bank_sel = (BYTE)SendDlgItemMessage(hDlg, IDC_COMBO1, CB_GETCURSEL, 0, 0);
					for (i = 0; i<2/*3 bank*/; i++)
					{
						hwnd_bank[i] = GetDlgItem(hDlg, IDC_RADIO1 + i);
						if (((i+1)%arr_height[bank_sel] == 0 || arr_height[bank_sel]%(i+1) == 0) && (i+1) <= arr_height[bank_sel])
							EnableWindow(GetDlgItem(hDlg, IDC_RADIO1 + i), true); else
						{
							if (SendDlgItemMessage(hDlg, IDC_RADIO1 + i, BM_GETCHECK, 0, 0) == BST_CHECKED)
							{
								SendMessage(hwnd_bank[0], BM_SETCHECK, BST_CHECKED, 0);
								SendMessage(hwnd_bank[i], BM_SETCHECK, BST_UNCHECKED, 0);
							}
							EnableWindow(GetDlgItem(hDlg, IDC_RADIO1 + i), false);
						}
					}
					break;
				
				case IDCANCEL:
					EndDialog(hDlg, LOWORD(wParam));
					return FALSE;
			}
			break;
	}
	return FALSE;
}

HBITMAP PictureToBitmap(HINSTANCE hInst, UINT nIDRes, LPTSTR pic)
{
	LPPICTURE gpPic;
	HRSRC hRsrc = FindResource(hInst, MAKEINTRESOURCE(nIDRes), pic); // type
	DWORD len = SizeofResource(hInst, hRsrc);
	HGLOBAL hResData = LoadResource(hInst, hRsrc);
	HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE | GMEM_NODISCARD, len);
	char* pDest = reinterpret_cast<char*> (GlobalLock(hGlobal));
	char* pSrc = reinterpret_cast<char*> (LockResource(hResData));
	CopyMemory(pDest, pSrc, len);
	FreeResource(hResData);
	GlobalUnlock(hGlobal);
	LPSTREAM pStream = NULL;
	HRESULT hr = CreateStreamOnHGlobal(hGlobal, TRUE, &pStream);
	hr = OleLoadPicture(pStream, 0, FALSE, IID_IPicture, (void**)&gpPic);
	pStream->Release();
	GlobalFree(hGlobal);
	HBITMAP hPic = NULL;
	gpPic->get_Handle((UINT*)&hPic);
    hPic = (HBITMAP)CopyImage(hPic, IMAGE_BITMAP, 0, 0, LR_COPYRETURNORG);
	return hPic;
}

void CreateTreeView(HWND hWnd)
{	// Create tree view
	hTreeView = CreateWindowEx(WS_EX_CLIENTEDGE, WC_TREEVIEW, "", //caption not required
		WS_CHILD | WS_VISIBLE | WS_TABSTOP | TVS_HASBUTTONS | TVS_HASLINES | TVS_LINESATROOT | TVS_SHOWSELALWAYS | TVS_TRACKSELECT | 0,
		0, 0, 0, 0, hWnd, (HMENU)0, hInst, NULL);
	HBITMAP hBitmap;
	hImgTV = ImageList_Create(16, 16, ILC_COLOR32 | ILC_MASK, 14, 1);
	hBitmap = PictureToBitmap(hInst, IDR_TREEICON, "IMAGES");
	ImageList_AddMasked(hImgTV, hBitmap, RGB(0, 0, 0));
	TreeView_SetImageList(hTreeView, hImgTV, TVSIL_NORMAL);	// TreeView_SetTextColor(hTreeView, RGB(64, 152, 255)); //
	TreeView_SetBkColor(hTreeView, RGB(64, 64, 64)); // TreeView_SetInsertMarkColor(hTreeView, RGB(0, 140, 0));

	DeleteObject(hBitmap);//	TreeView_SetItemHeight(hTreeView, 20);
	OldTVProc = (WNDPROC)GetWindowLong(hTreeView, GWL_WNDPROC);
	SetWindowLong(hTreeView, GWL_WNDPROC, (LONG)TreeViewProc);
}

void InsertRoot(LPSTR str) // => return hRoot
{
	TVINSERTSTRUCT tvs;

	tvs.itemex.pszText = str;
	tvs.itemex.lParam = 0;
	tvs.itemex.state = TVIS_EXPANDED; //	tvs.itemex.iIntegral = 2;
	tvs.hParent = TVI_ROOT;
	tvs.itemex.mask = TVIF_STATE | TVIF_TEXT | TVIF_IMAGE | TVIF_PARAM | TVIF_CHILDREN;
	tvs.itemex.iImage = 0;
	tvs.itemex.iSelectedImage = 0;
	tvs.itemex.state = TVIS_EXPANDED | TVIS_BOLD;
	tvs.itemex.stateMask = TVIS_EXPANDED | TVIS_BOLD;
	hRoot = TreeView_InsertItem(hTreeView, &tvs); //	TreeView_SelectItem(hTreeView, hRoot); // chon item vua tao ra
}

void ResetNumberPage() // danh lai so trang, so font va date/time
{
	HTREEITEM hItem;
	TVITEM tvItem;
	TCHAR strpage[MAX_LOADSTRING];
	TCHAR strnumber[8];
	UINT index = 0;
	hItem = TreeView_GetChild(hTreeView, hRoot);
	if (!hItem) return;
	while (hItem)
	{
		tvItem.hItem = hItem;
		tvItem.cchTextMax = MAX_LOADSTRING;
		tvItem.pszText = strpage;
		tvItem.mask = TVIF_TEXT | TVIF_HANDLE;
		TreeView_GetItem(hTreeView, &tvItem);
		index += 1;
		if (index <= fontnumber)
		{
			strcpy(strpage, "Font ");
			tvItem.pszText = strpage;
			itoa(index, strnumber, 10);
			strcat(strpage, strnumber);
		} else
		{
			strcpy(strpage, "Page ");
			tvItem.pszText = strpage;
			itoa(index - fontnumber, strnumber, 10);
			strcat(strpage, strnumber);
		}
		TreeView_SetItem(hTreeView, &tvItem);
		hItem = TreeView_GetNextSibling(hTreeView, hItem);
	}
}

UINT GetOrderByItem() // lay thu tu cua tvCurrent cho Page hoac Font
{
	UINT itc;
	HTREEITEM hItem, hItemTemp;

	if (tvCurrent.hItem == hRoot) return 0;
	hItem = TreeView_GetChild(hTreeView, hRoot);
	if (hItem == NULL) return 0;
	hItemTemp = tvCurrent.hItem;
	if (tvCurrent.lParam%256 != 0)
		hItemTemp = tvParentCurrent.hItem; //TreeView_GetParent(hTreeView, tvCurrent.hItem);
	itc = 1;
	while (hItem != hItemTemp)
	{
		itc++;
		hItem = TreeView_GetNextSibling(hTreeView, hItem);
	}
	return itc;
}

void GetOrderByChildItem(UINT &x, UINT &y) // lay thu tu cua tvCurrent cho Page, Font, Line,
{
	HTREEITEM hItemTemp;
	UINT i;

	x = GetOrderByItem();
	if ((x == 0) || (tvParentCurrent.hItem == hRoot)) // neu chon hRoot hoac chon Page/Font
	{
		y = 0; // hRoot
	}
	else
	{
		hItemTemp = TreeView_GetChild(hTreeView, tvParentCurrent.hItem);
		y = 1;
		while (hItemTemp != tvCurrent.hItem)
		{
			y++;
			hItemTemp = TreeView_GetNextSibling(hTreeView, hItemTemp);
		}
	}
	// viet them doan nay de xac dinh page dang chon (active)
	if (x == 0 && y == 0)  // chon hRoot
	{
		pageactive = NULL;
	}
	else
	{
		pageactive = matrix->first_page;
		i = 1;
		while (i < x)
		{
			i++;
			pageactive = pageactive->nextpage;
		}
	}
	return;
}

HTREEITEM GetItemByOrder(UINT itc) // lay hItem theo gia tri chi ra itc
{
	HTREEITEM hItem;
	UINT index;
	hItem = TreeView_GetChild(hTreeView, hRoot);
	if (itc == 0) return hRoot;
	index = 1;
	while (index < itc)
	{
		index++;
		hItem = TreeView_GetNextSibling(hTreeView, hItem);
	}
	return hItem;
}

void InsertPage() // chen 1 page sau item select
{ // xac dinh theo lParam
	TVINSERTSTRUCT tvs;
	HTREEITEM hItem;
	UINT itc;

	tvs.itemex.pszText = "";
	tvs.itemex.lParam = (pagenumber + 1) * 0x010000;
	tvs.itemex.state = TVIS_EXPANDED | TVIS_BOLD;
	tvs.itemex.stateMask = TVIS_EXPANDED | TVIS_BOLD;
	tvs.itemex.mask = TVIF_STATE | TVIF_TEXT | TVIF_IMAGE | TVIF_PARAM | TVIF_SELECTEDIMAGE;//TVIF_TEXT | TVIF_PARAM | TVIF_CHILDREN | TVIF_IMAGE | TVIF_SELECTEDIMAGE;//TVIF_STATE | TVIF_TEXT| TVIF_SELECTEDIMAGE;//TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE;
	tvs.itemex.iImage = 2;
	tvs.itemex.iSelectedImage = 2;
	tvs.hParent = hRoot;
	itc = GetOrderByItem();
	if ((itc == 0) && (fontnumber == 0)) tvs.hInsertAfter = TVI_FIRST; else
	{
		if (itc > fontnumber)
		{
			if (tvCurrent.lParam%256 == 0) tvs.hInsertAfter = tvCurrent.hItem; else
				tvs.hInsertAfter = tvParentCurrent.hItem;;//TreeView_GetParent(hTreeView, tvCurrent.hItem);
		} else
		{
			tvs.hInsertAfter = GetItemByOrder(fontnumber);
		}
	}
	hItem = TreeView_InsertItem(hTreeView, &tvs);
	pagenumber += 1;
	ResetNumberPage();
	TreeView_SelectItem(hTreeView, hItem); // chon item vua tao ra
	TreeView_SelectDropTarget(hTreeView, hItem);
	SetFocus(hTreeView);
}

void InsertFont() // chen 1 font sau font co truoc tai dau item
{ // xac dinh theo lParam
	TVINSERTSTRUCT tvs;
	HTREEITEM hItem;
	UINT itc;

	tvs.itemex.pszText = "";
	tvs.itemex.lParam = (fontnumber + 1) * 0x0100;
	tvs.itemex.state = TVIS_EXPANDED; //	tvs.itemex.iIntegral = 2;
	tvs.itemex.mask = TVIF_STATE | TVIF_TEXT | TVIF_IMAGE | TVIF_PARAM | TVIF_SELECTEDIMAGE;//TVIF_TEXT | TVIF_PARAM | TVIF_CHILDREN | TVIF_IMAGE | TVIF_SELECTEDIMAGE;//TVIF_STATE | TVIF_TEXT| TVIF_SELECTEDIMAGE;//TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE;
	tvs.itemex.iImage = 1;
	tvs.itemex.iSelectedImage = 1;
	tvs.hParent = hRoot;
	itc = GetOrderByItem();
	if ((itc == 0) || (fontnumber == 0)) tvs.hInsertAfter = TVI_FIRST; else
	{
		if (itc <= fontnumber)
		{
			if (tvCurrent.lParam%256 == 0) tvs.hInsertAfter = tvCurrent.hItem; else
				tvs.hInsertAfter = tvParentCurrent.hItem;;//TreeView_GetParent(hTreeView, tvCurrent.hItem);
		} else
		{
			tvs.hInsertAfter = GetItemByOrder(fontnumber);
		}
	}
	hItem = TreeView_InsertItem(hTreeView, &tvs);
	fontnumber += 1;
	ResetNumberPage();
	TreeView_SelectItem(hTreeView, hItem); // chon item vua tao ra
	TreeView_SelectDropTarget(hTreeView, hItem);
	SetFocus(hTreeView);
}

void InsertLine(short type)
{// xac dinh theo lParam
	TVINSERTSTRUCT tvs;
	HTREEITEM hItem;

	tvs.itemex.state = TVIS_EXPANDED; //	tvs.itemex.iIntegral = 2;
	tvs.itemex.mask = TVIF_STATE | TVIF_TEXT | TVIF_IMAGE | TVIF_PARAM | TVIF_SELECTEDIMAGE;//TVIF_TEXT | TVIF_PARAM | TVIF_CHILDREN | TVIF_IMAGE | TVIF_SELECTEDIMAGE;//TVIF_STATE | TVIF_TEXT| TVIF_SELECTEDIMAGE;//TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE;

	if (tvCurrent.lParam%256 == 0) // insert at Page or Font
	{
		tvs.hInsertAfter = TVI_FIRST;
		tvs.hParent = tvCurrent.hItem;
		tvs.itemex.lParam = tvCurrent.lParam + type;
	}
	else // insert at friend
	{
		tvs.hInsertAfter = tvCurrent.hItem;
		tvs.hParent =  tvParentCurrent.hItem;//TreeView_GetParent(hTreeView, tvCurrent.hItem);
		tvs.itemex.lParam = tvParentCurrent.lParam + type;
	}
	switch (type)
	{
		case 1: tvs.itemex.pszText = "Text"; tvs.itemex.iImage = 4; tvs.itemex.iSelectedImage = 4; break;
		case 2: tvs.itemex.pszText = "Image"; tvs.itemex.iImage = 5; tvs.itemex.iSelectedImage = 5; break;
		case 3: tvs.itemex.pszText = "Date/time"; tvs.itemex.iImage = 6; tvs.itemex.iSelectedImage = 6; break;
		case 4: tvs.itemex.pszText = "Char"; tvs.itemex.iImage = 3; tvs.itemex.iSelectedImage = 3; break;
	}
	hItem = TreeView_InsertItem(hTreeView, &tvs);
	TreeView_SelectItem(hTreeView, hItem); // chon item vua tao ra <=> TreeView_Select(hTreeView, htItem, TVGN_CARET);
	TreeView_SelectDropTarget(hTreeView, hItem);
	SetFocus(hTreeView);
}

void OnButtonDown() // chon item khi click chuot
{
	POINT pt;
	TVHITTESTINFO tvHT;
	HTREEITEM hitem;
	GetCursorPos(&pt);
	tvHT.flags = TVHT_ONITEM;
	memcpy(&tvHT.pt, &pt, sizeof(POINT));
	ScreenToClient(hTreeView, &tvHT.pt);
	hitem = TreeView_HitTest(hTreeView, &tvHT);
	if (tvHT.flags & (TVHT_ONITEMRIGHT | TVHT_ONITEM))// | TVHT_ONITEMINDENT))
	{
		TreeView_SelectItem(hTreeView, hitem); // kiem tra xem khi nhan chuot phai nam o vung ngoai treeview
		TreeView_SelectDropTarget(hTreeView, hitem);
		item_in_tree = TRUE;
	}
	else item_in_tree = FALSE;
}

TVITEM GetTVInfo(HTREEITEM hitem) // lay cac thong tin cua hitem dang chon
{
	TVITEM tvitem;
	TCHAR achBuf[MAX_LOADSTRING];
	tvitem.hItem = hitem;
	tvitem.cchTextMax = MAX_LOADSTRING;
	tvitem.pszText = achBuf;
	tvitem.mask = TVIF_TEXT | TVIF_HANDLE;//	TreeView_SelectItem(hTreeView, hitem);
	TreeView_GetItem(hTreeView, &tvitem);
	return tvitem;
}

LRESULT CALLBACK TreeViewProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	POINTS pt;
	TVHITTESTINFO tvht;
	HTREEITEM hitTarget;
	switch(uMsg)
	{
		case WM_MOUSEMOVE:
			if (itemDragging)
			{
				pt = MAKEPOINTS(lParam);
				ImageList_DragMove(pt.x, pt.y); // where to draw the drag from
				ImageList_DragShowNolock(FALSE);
				tvht.pt.x = pt.x; // the highlight items should be as the same points as the drag
				tvht.pt.y = pt.y; //
				if (hitTarget = (HTREEITEM)TreeView_HitTest(hTreeView, (LPARAM)&tvht)) // if there is a hit
					TreeView_SelectDropTarget(hTreeView, hitTarget);   // highlight it
			    ImageList_DragShowNolock(TRUE); 
			} 
			break;
		case WM_LBUTTONDOWN:
		case WM_RBUTTONDOWN:
			SetFocus(hWnd); //tranh truong hop khi bi lostfocus thi khong hilight
			OnButtonDown();
			break;
		case WM_LBUTTONUP:
			if (itemDragging)
			{
				ImageList_DragLeave(hTreeView);
				ImageList_EndDrag();
				ReleaseCapture();
				ShowCursor(TRUE); 
				itemDragging = FALSE;
				ImageList_Destroy(hImgDrag);
				TreeView_SelectDropTarget(hTreeView, tvCurrent.hItem);
			}
		    break;
		case WM_DESTROY:
			SetWindowLong(hTreeView, GWL_WNDPROC, (LONG)OldTVProc);
			OldTVProc = NULL;
			break;
		default:
			break;
	}
	if (OldTVProc != NULL)
		return CallWindowProc(OldTVProc, hWnd, uMsg, wParam, lParam);
	else
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

LRESULT ProcessTreeViewNotification(LPNMHDR p_pNotifyStruct)
{
	LPNMTREEVIEW pNMTreeView;
	LPNMTVCUSTOMDRAW pNMTVCustomDraw;
	HMENU mnPopup;
	POINT pt;

	switch (p_pNotifyStruct->code)
	{
		case NM_RCLICK:  // User clicked right mouse button, track via NMHDR
			pNMTreeView = (LPNMTREEVIEW)p_pNotifyStruct;
			if (item_in_tree) // chuot nam trong vung tree view
			{
				GetCursorPos(&pt);
				mnPopup = GetSubMenu(SysMenu, 1);
				TrackPopupMenu(mnPopup, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hWnd, NULL);
			}
			break;

		case NM_CUSTOMDRAW:
			pNMTVCustomDraw = (LPNMTVCUSTOMDRAW)p_pNotifyStruct;
			switch (pNMTVCustomDraw->nmcd.dwDrawStage)
			{
				case CDDS_PREPAINT:
					return CDRF_NOTIFYITEMDRAW;
				case CDDS_ITEMPREPAINT:
					if (pNMTVCustomDraw->nmcd.lItemlParam == 0) // hRoot
					{
						pNMTVCustomDraw->clrTextBk = RGB(255, 36, 36);
						pNMTVCustomDraw->clrText = RGB(255, 255, 255);
					} else
					if ((pNMTVCustomDraw->nmcd.lItemlParam%256 == 0) && (pNMTVCustomDraw->nmcd.lItemlParam/256 < 256)) // font
						pNMTVCustomDraw->clrText = RGB(255, 255, 0);
					else
					if ((pNMTVCustomDraw->nmcd.lItemlParam%256 == 0) && (pNMTVCustomDraw->nmcd.lItemlParam/256 >= 256)) // page
						pNMTVCustomDraw->clrText = RGB(0, 255, 0);
					else
					{
						pNMTVCustomDraw->clrText = RGB(255, 255, 255); // text - image - date/time
						if (pNMTVCustomDraw->nmcd.uItemState == CDIS_HOT)
							pNMTVCustomDraw->clrText = RGB(255, 128, 255);
					}
					return CDRF_NEWFONT;
			}
			break;

		case TVN_BEGINDRAG:  // Drag-and-drop operation with left mouse button is occuring, track via NMTREEVIEW
			pNMTreeView = (LPNMTREEVIEW)p_pNotifyStruct;
			if (tvCurrent.hItem != hRoot)
			{
				hImgDrag = TreeView_CreateDragImage(hTreeView, pNMTreeView->itemNew.hItem);
				ImageList_BeginDrag(hImgDrag, 0, 0, 0);
				ImageList_DragEnter(hTreeView, pNMTreeView->ptDrag.x, pNMTreeView->ptDrag.y);
				ShowCursor(FALSE); 
				SetCapture(hTreeView);
				itemDragging = TRUE;
			}
			break;

	 	case TVN_SELCHANGED:  // Selection changed
			pNMTreeView = (LPNMTREEVIEW)p_pNotifyStruct;
			tvCurrent = GetTVInfo(TreeView_GetSelection(hTreeView));
			if (tvCurrent.hItem == hRoot) ZeroMemory(&tvParentCurrent, sizeof(tvParentCurrent)); else
				tvParentCurrent = GetTVInfo(TreeView_GetParent(hTreeView, tvCurrent.hItem));
			TreeView_SelectItem(hTreeView, tvCurrent.hItem);
			TreeView_SelectDropTarget(hTreeView, tvCurrent.hItem);
			GetOrderByChildItem(tvX, tvY); // cap nhat lai vi tri XY va lay luon page active
			UpdateSubMenu(tvCurrent.lParam);
			TextMatrix->OnUpdatePTextMatrix(pageactive);
			break;
	}
	return 0;
}
