#include "objects.h"
#include "resource.h"

LineDisp::LineDisp(HWND hWnd, int x, int y)
{
	obj_pos.x = x;
	obj_pos.y = y;
	WNDCLASSEX	wcx;
	wcx.cbSize			= sizeof(wcx);
	wcx.style			= 0;//CS_HREDRAW | CS_VREDRAW;
	wcx.lpfnWndProc		= (WNDPROC)LineDispWndProc;
	wcx.cbClsExtra		= 0;
	wcx.cbWndExtra		= sizeof(LineDisp*);
	wcx.hInstance		= GetModuleHandle(0);
	wcx.hIcon			= 0;
	wcx.hCursor			= LoadCursor (NULL, IDC_IBEAM);
	wcx.hbrBackground	= (HBRUSH)0;		//NO FLICKERING FOR US!!
	wcx.lpszMenuName	= 0;
	wcx.lpszClassName	= "LineDisp";	
	wcx.hIconSm			= 0;
	RegisterClassEx(&wcx);
	hWndLine = CreateWindow("LineDisp", NULL, WS_CHILD | WS_VISIBLE,
		0, 0, 0, 0, hWnd, 0, GetModuleHandle(0), 0);
	SetWindowLong(hWndLine, 0, (long)this);
}

LRESULT CALLBACK LineDisp::LineDispWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LineDisp *pld = (LineDisp *)GetWindowLong(hWnd, 0);
	SetWindowLong(hWnd, 0, (LONG)pld);

	switch(message)
	{
		case WM_CREATE:
			return TRUE;

		default:
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);

}

LineDisp::~LineDisp()
{
}


MatrixView::MatrixView(HWND hWnd)
{
	disp_style = 0;
	zoom = 12;
	matrix_size.cx = 0;
	matrix_size.cy = 0;
	obj_size.cx = 0;
	obj_size.cy = 0;
	mt_draw_size.cx = 0;
	mt_draw_size.cy = 0;
	pt_matrixpos.x = 0;
	pt_matrixpos.y = 0;
	ppage = NULL;

	WNDCLASSEX	wcx;
	wcx.cbSize			= sizeof(wcx);
	wcx.style			= 0;//CS_HREDRAW | CS_VREDRAW;
	wcx.lpfnWndProc		= (WNDPROC)MatrixViewWndProc;
	wcx.cbClsExtra		= 0;
	wcx.cbWndExtra		= sizeof(MatrixView*);
	wcx.hInstance		= GetModuleHandle(0);
	wcx.hIcon			= 0;
	wcx.hCursor			= LoadCursor(NULL, IDC_ARROW);
	wcx.hbrBackground	= (HBRUSH)0;//COLOR_WINDOWTEXT;//13;		//NO FLICKERING FOR US!!
	wcx.lpszMenuName	= 0;
	wcx.lpszClassName	= "MatrixView";	
	wcx.hIconSm			= 0;
	RegisterClassEx(&wcx);
	hWndMatrixView = CreateWindow("MatrixView", NULL, WS_CHILD | WS_VISIBLE,
		0, 0, 0, 0, hWnd, 0, GetModuleHandle(0), 0);
	SetWindowLong(hWndMatrixView, 0, (long)this);
	hdc = GetDC(hWndMatrixView);
}

MatrixView::~MatrixView()
{
}

LRESULT CALLBACK MatrixView::MatrixViewWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	MatrixView *pmv = (MatrixView *)GetWindowLong(hWnd, 0);
	SetWindowLong(hWnd, 0, (LONG)pmv);
//	int a;
	switch(message)
	{
		case WM_NCDESTROY:
			delete pmv;
			return 0;

		case WM_PAINT:
			pmv->OnPaint();
			break;

		default:
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

void MatrixView::OnSetDispStyle(BYTE style)
{
	disp_style = style;
}

void MatrixView::OnSetPageDisp(_2page* ppagedisp)
{
	ppage = ppagedisp;
}

void MatrixView::OnGetObjSize()
{
	//obj_size = matrix_size; // tam thoi lay bang kich thuoc ma tran, con khi thay doi Text thi phai cap nhat lai obj_size
	obj_size.cx = 50;
	obj_size.cy = 12;
	obj_pos.x = 2; // so voi pt_matrixpos
	obj_pos.y = 1;

	if (disp_style == 0) mt_draw_size = matrix_size;// kieu 1 man hinh ti~nh
	if (disp_style == 1) // kieu thiet ke theo chieu ngang
	{
		if (obj_size.cx < matrix_size.cx) mt_draw_size.cx = matrix_size.cx; else mt_draw_size.cx = obj_size.cx;
		mt_draw_size.cy = matrix_size.cy;
	}
	if (disp_style == 2) // kieu thiet ke theo chieu doc
	{
		mt_draw_size.cx = matrix_size.cx;
		if (obj_size.cy < matrix_size.cy) mt_draw_size.cy = matrix_size.cy; else mt_draw_size.cy = obj_size.cy;
	}
}

void MatrixView::OnDrawObj(HDC hdc)
{// CHU Y: trong cac phep bien doi thi van lay vi tri pt_matrixpos lam chuan (0, 0) de tinh
	HBITMAP hbm, hbitmapOld;
	RECT rtObj, rtDraw;

	if (ppage == NULL) return;
	if (ppage->first_line == NULL) return;
	// tinh vi tri cua doi tuong text
	SetRect(&rtObj, (obj_pos.x - pt_matrixpos.x) * zoom, (obj_pos.y - pt_matrixpos.y) * zoom,
		(obj_pos.x - pt_matrixpos.x + obj_size.cx) * zoom, (obj_pos.y - pt_matrixpos.y + obj_size.cy) * zoom);
	// lay giao voi MatrixView
	IntersectRect(&rtObj, &rtObj, &rt_mtv);
	// chuyen ve (0, 0) de tinh kich thuoc cua bitmap
	SetRect(&rtDraw, 0, 0, 0, 0);
	rtDraw.right = rtObj.right - rtObj.left;
	rtDraw.bottom = rtObj.bottom - rtObj.top;

	hdcRect = CreateCompatibleDC(hdc);						// DC ao - Grid
	hbm = CreateCompatibleBitmap(hdc, rtDraw.right, rtDraw.bottom);	// bm hdc
	hbitmapOld = (HBITMAP)SelectObject(hdcRect, hbm);		// luu bm cua hdcRect
	DrawFocusRect(hdcRect, &rtDraw);
	BitBlt(hdc, rtObj.left, rtObj.top, rtDraw.right, rtDraw.bottom, hdcRect, 0, 0, SRCPAINT);
	SelectObject(hdcRect, hbitmapOld);							// tra bm cho hdcRect

	DeleteObject(hbm);
	DeleteObject(hbitmapOld);
	DeleteDC(hdcRect);
}

void MatrixView::OnDrawGrid(HDC hdc)
{
	HBITMAP hbm, hbitmapOld;
	HPEN hpen, hpenOld;
	int x;
	hdcGrid = CreateCompatibleDC(hdc);						// DC ao - Grid
	hbm = CreateCompatibleBitmap(hdc, rt_mtv.right, rt_mtv.bottom);	// bm hdc
	hbitmapOld = (HBITMAP)SelectObject(hdcGrid, hbm);		// luu bm cua hdcMemGrid
	BitBlt(hdcGrid, 0, 0, rt_mtv.right, rt_mtv.bottom, NULL, 0, 0, BLACKNESS);	// xoa hdcMemGrid

	hpen = CreatePen(PS_SOLID, 1, RGB(70, 70, 70));
	hpenOld = (HPEN)SelectObject(hdcGrid, hpen);			// luu hPen cura hdcMemGrid

	for(x = 0; x < rt_mtv.right / zoom; x++)
	{
		MoveToEx(hdcGrid, x * zoom, 0, NULL);
		LineTo(hdcGrid, x * zoom, rt_mtv.bottom);
	}
	for(x = 0; x < rt_mtv.bottom / zoom; x++)
	{
		MoveToEx(hdcGrid, 0, x * zoom, NULL);
		LineTo(hdcGrid, rt_mtv.right, x * zoom);
	}
	BitBlt(hdc, 0, 0, rt_mtv.right, rt_mtv.bottom, hdcGrid, 0, 0, SRCINVERT);

	SelectObject(hdcGrid, hpenOld);							// tra hPen cho hdcMemGrid
	SelectObject(hdcGrid, hbitmapOld);						// tra bm cho hdcMemGrid

	DeleteObject(hbm);
	DeleteObject(hbitmapOld);
	DeleteObject(hpen);
	DeleteObject(hpenOld);
	DeleteDC(hdcGrid);
}

void MatrixView::OnPaint()
{	// sz la kich thuoc bang, chang han 16x128 pixels
	HDC hdcT;
	HBITMAP hbm, hbmOld;

	// tinh lai kich thuoc vung hien thi MatrixView
//	GetClientRect(GetParent(hWndMatrixView), &rt_mtv);
//	sz.cx = (rt_mtv.right - MATRIX_BORDER * zoom) / zoom;
//	MoveWindow(hWndMatrixView, MATRIX_BORDER * zoom, MATRIX_BORDER * zoom, sz.cx * zoom, sz.cy * zoom, TRUE);

	GetClientRect(hWndMatrixView, &rt_mtv);
	hdcT = CreateCompatibleDC(hdc);
	hbm = CreateCompatibleBitmap(hdc, rt_mtv.right, rt_mtv.bottom);
	hbmOld = (HBITMAP)SelectObject(hdcT, hbm);				// luu bm cua hdcMemGrid

	// Draw Text to the HDCTEMP
//	if (ptext) OnDrawText(hdcT);
	// Draw Grid to the HDCTEMP
	OnDrawObj(hdcT);
	OnDrawGrid(hdcT);
	// Draw Rect to the HDCTEMP
//	if (ptext) OnDrawRect(hdcT);

	BitBlt(hdc, 0, 0, rt_mtv.right, rt_mtv.bottom, hdcT, 0, 0, SRCCOPY);
	SelectObject(hdcT, hbmOld);

	DeleteObject(hdcT);
	DeleteObject(hbm);
	DeleteObject(hbmOld);
}

PTextMatrix::PTextMatrix(HWND hWnd, _1matrix_infor* mt_infor)
{
	xPos = yPos = 0; // vi tri cua H va V Scroll
	pmt_infor = mt_infor; // khoi tao bang 1 cau truc default
	numline = 0; // cac bien de tinh toan vi tri Scroll
	numline_in_page = 0;
	numcol = 0;
	numcol_in_page = 0;

	WNDCLASSEX	wcx;
	wcx.cbSize			= sizeof(wcx);
	wcx.style			= CS_HREDRAW | CS_VREDRAW;
	wcx.lpfnWndProc		= (WNDPROC)PTextMatrixWndProc;
	wcx.cbClsExtra		= 0;
	wcx.cbWndExtra		= sizeof(PTextMatrix*);
	wcx.hInstance		= GetModuleHandle(0);
	wcx.hIcon			= 0;
	wcx.hCursor			= LoadCursor(NULL, IDC_ARROW);
	wcx.hbrBackground	= (HBRUSH)(COLOR_APPWORKSPACE + 1);		//NO FLICKERING FOR US!!
	wcx.lpszMenuName	= 0;
	wcx.lpszClassName	= "PTextMatrix";	
	wcx.hIconSm			= 0;
	RegisterClassEx(&wcx);
	hWndPTextMatrix = CreateWindow("PTextMatrix", NULL, WS_HSCROLL | WS_VSCROLL | WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN,
		0, 0, 0, 0, hWnd, 0, GetModuleHandle(0), 0);
	pMatrixView = new (MatrixView)(hWndPTextMatrix);

	sx.cbSize = sizeof(sx);
	sx.fMask = SIF_ALL;
	sx.nMin = 0;
	sx.nMax = 0;
	sx.nPage = 0;
	sx.nPos = 0;
	sx.nTrackPos = 0;
	SetScrollInfo(hWndPTextMatrix, SB_HORZ, &sx, TRUE);

	sy.cbSize = sizeof(sy);
	sy.fMask = SIF_ALL;
	sy.nMin = 0;
	sy.nMax = 0;
	sy.nPage = 0;
	sy.nPos = 0;
	sy.nTrackPos = 0;
	SetScrollInfo(hWndPTextMatrix, SB_VERT, &sy, TRUE);

	SetWindowLong(hWndPTextMatrix, 0, (long)this);
}

PTextMatrix::~PTextMatrix()
{
}

LRESULT CALLBACK PTextMatrix::PTextMatrixWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PTextMatrix *ptm = (PTextMatrix *)GetWindowLong(hWnd, 0);
	SetWindowLong(hWnd, 0, (LONG)ptm);

	switch(message)
	{
		case WM_HSCROLL:
			ptm->HScroll(hWnd, LOWORD(wParam), HIWORD(wParam));
			ptm->OnSize();
			break;
		case WM_VSCROLL:
			ptm->VScroll(hWnd, LOWORD(wParam), HIWORD(wParam));
			ptm->OnSize();
			break;
		case WM_SIZE:
			if (ptm)
			{
				ptm->OnSetScroll();
				ptm->OnSize();
			}
			break;
		case WM_NCDESTROY:
			delete ptm;
			return 0;
		default:
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

void PTextMatrix::OnUpdatePTextMatrix(_2page* ppagecurrent)
{ // dat tham so khi khoi tao cua so
	pMatrixView->matrix_size.cx = arr_width[pmt_infor->mt_width] * 16; // kich thuoc ma tran
	pMatrixView->matrix_size.cy = arr_height[pmt_infor->mt_height] * 8;
	pMatrixView->OnSetPageDisp(ppagecurrent); // dat con tro cho pagecurrent de ve line
	pMatrixView->OnGetObjSize();
	OnSetScroll();
	OnSize(); // ve lai Matrix sau khi thay doi
	//pMatrixView->OnPaint(); // khi khong co scroll thi onsize khong ve lai nen zoom khong co hieu qua
}

void PTextMatrix::OnSize()
{ // tinh lai vi tri cua so MartrixView
	GetScrollInfo(hWndPTextMatrix, SB_HORZ, &sx);
	xPos = sx.nPos; // lay kich thuoc chinh xac vi tri Scroll sau khi resize
	if (rt_ptm.right > (pMatrixView->mt_draw_size.cx + 2 * MATRIX_BORDER) * pMatrixView->zoom) // PTextMatrix mo rong hon MatrixView
	{
		// can phai sua lai doan sau vi mt_draw_size co the la so le => chia 2 bi mat du lieu
		rt_mtv_client.left = (rt_ptm.right / pMatrixView->zoom / 2 - pMatrixView->mt_draw_size.cx / 2) * pMatrixView->zoom; // MATRIX_BORDER * zoom;
		rt_mtv_client.right = (rt_ptm.right / pMatrixView->zoom / 2 + pMatrixView->mt_draw_size.cx / 2) * pMatrixView->zoom; //pMatrixView->sz.cx * zoom + MATRIX_BORDER * zoom;
	} else
	{
		if (xPos < MATRIX_BORDER) // scroll den doan dau trai
			rt_mtv_client.left = (MATRIX_BORDER - xPos) * pMatrixView->zoom;
		else
			rt_mtv_client.left = 0;
		if (numcol - numcol_in_page - xPos <= MATRIX_BORDER) // scroll den cuoi matrix
			rt_mtv_client.right = (numcol - xPos - MATRIX_BORDER) * pMatrixView->zoom;
		else // scrool den doan giua
			rt_mtv_client.right = (rt_ptm.right / pMatrixView->zoom) * pMatrixView->zoom;
	}

	GetScrollInfo(hWndPTextMatrix, SB_VERT, &sy);
	yPos = sy.nPos;
	if (rt_ptm.bottom > (pMatrixView->mt_draw_size.cy + 2 * MATRIX_BORDER) * pMatrixView->zoom) // PTextMatrix mo rong hon MatrixView
	{
		rt_mtv_client.top = (rt_ptm.bottom / pMatrixView->zoom / 2 - pMatrixView->mt_draw_size.cy / 2) * pMatrixView->zoom; // MATRIX_BORDER * zoom;
		rt_mtv_client.bottom = (rt_ptm.bottom / pMatrixView->zoom / 2 + pMatrixView->mt_draw_size.cy / 2) * pMatrixView->zoom; //pMatrixView->sz.cy * zoom + MATRIX_BORDER * zoom;
	} else
	{
		if (yPos < MATRIX_BORDER) // scroll den doan dau tren cung
			rt_mtv_client.top = (MATRIX_BORDER - yPos) * pMatrixView->zoom;
		else
			rt_mtv_client.top = 0;
		if (numline - numline_in_page - yPos <= MATRIX_BORDER) // scroll den cuoi matrix
			rt_mtv_client.bottom = (numline - yPos - MATRIX_BORDER) * pMatrixView->zoom;
		else // scrool den doan giua
			rt_mtv_client.bottom = (rt_ptm.bottom / pMatrixView->zoom) * pMatrixView->zoom;
	}

	if (xPos > MATRIX_BORDER) pMatrixView->pt_matrixpos.x = xPos - MATRIX_BORDER; else pMatrixView->pt_matrixpos.x = 0;
	if (yPos > MATRIX_BORDER) pMatrixView->pt_matrixpos.y = yPos - MATRIX_BORDER; else pMatrixView->pt_matrixpos.y = 0;

	MoveWindow(pMatrixView->hWndMatrixView, rt_mtv_client.left, rt_mtv_client.top, rt_mtv_client.right - rt_mtv_client.left, rt_mtv_client.bottom - rt_mtv_client.top, TRUE);
	pMatrixView->OnPaint();
}

void PTextMatrix::OnSetScroll()
{ // xac dinh cac tham so SCROLL va vung ve
	GetClientRect(hWndPTextMatrix, &rt_ptm);

	numcol = pMatrixView->mt_draw_size.cx + MATRIX_BORDER * 2;
	numcol_in_page = rt_ptm.right / pMatrixView->zoom;
	sx.nPage = numcol_in_page;
	sx.nMax = numcol - 1;
	SetScrollInfo(hWndPTextMatrix, SB_HORZ, &sx, TRUE);

	numline = pMatrixView->mt_draw_size.cy + MATRIX_BORDER * 2;
	numline_in_page = rt_ptm.bottom / pMatrixView->zoom;
	sy.nPage = numline_in_page;
	sy.nMax = numline - 1;
	SetScrollInfo(hWndPTextMatrix, SB_VERT, &sy, TRUE);
}

void PTextMatrix::HScroll(HWND hWnd, int nScrollCode, int nPosition)
{
	sx.nMax = numcol - 1;
	sx.nPage = numcol_in_page;
	GetScrollInfo(hWnd, SB_HORZ, &sx);
    xPos = sx.nPos;
	switch (nScrollCode)
	{
	case SB_RIGHT:
		xPos = sx.nMax;
		break;
	case SB_LEFT:
		xPos = 0;
		break;
	case SB_LINERIGHT: //if (yPos<numline - numline_in_page + 1) 
		xPos += 1;
		break;
	case SB_LINELEFT: //if (yPos>0)
		xPos -= 1;
		break;
	case SB_PAGERIGHT:
		xPos += numcol_in_page;// if (yPos > numline - numline_in_page + 1) yPos = numline - numline_in_page + 1;
		break;
	case SB_PAGELEFT:
		xPos -= numcol_in_page;// if (yPos<0) yPos=0; 
		break;
	case SB_THUMBPOSITION:
		xPos = sx.nTrackPos;
		break;
	case SB_THUMBTRACK:
		xPos = sx.nTrackPos;
		break;
	case SB_ENDSCROLL:
		break;
	default:
		break;
	}
    sx.nPos = xPos;
    SetScrollInfo(hWnd, SB_HORZ, &sx, TRUE);
}

void PTextMatrix::VScroll(HWND hWnd, int nScrollCode, int nPosition)
{
	sy.nMax = numline - 1;
	sy.nPage = numline_in_page;
	GetScrollInfo(hWnd, SB_VERT, &sy);
    yPos = sy.nPos;
	switch (nScrollCode)
	{
	case SB_BOTTOM:
		yPos = sy.nMax;
		break;
	case SB_TOP:
		yPos = 0;
		break;
	case SB_LINEDOWN: //if (yPos<numline - numline_in_page + 1) 
		yPos += 1;
		break;
	case SB_LINEUP: //if (yPos>0)
		yPos -= 1;
		break;
	case SB_PAGEDOWN:
		yPos += numline_in_page;// if (yPos > numline - numline_in_page + 1) yPos = numline - numline_in_page + 1;
		break;
	case SB_PAGEUP:
		yPos -= numline_in_page;// if (yPos<0) yPos=0; 
		break;
	case SB_THUMBPOSITION:
		yPos = sy.nTrackPos;
		break;
	case SB_THUMBTRACK:
		yPos = sy.nTrackPos;
		break;
	case SB_ENDSCROLL:
		break;
	default:
		break;
	}
    sy.nPos = yPos;
    SetScrollInfo(hWnd, SB_VERT, &sy, TRUE);
}

