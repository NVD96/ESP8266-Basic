#ifndef _OBJECTS_H
#define _OBJECTS_H

#include <windows.h>
#include <commdlg.h>
#include <commctrl.h>

static BYTE arr_width[] = {2, 3, 4, 5, 6, 8, 10, 12, 16}; // x32
static BYTE arr_height[] = {1, 2, 3, 4, 6, 8, 10, 12}; // x8 theo module mau 8x16
static BYTE arr_color[] = {1, 3};
static BYTE arr_colorlv[] = {1, 2, 4, 8};
static BYTE arr_ROMsize[] = {2, 4, 8};

#define MATRIX_BORDER	3

class LineDisp;

typedef struct _2page
{
	BYTE running_style;
	LineDisp *first_line;
	_2page *lastpage;
	_2page *nextpage;
} PAGE;

typedef struct _1matrix_infor
{
	TCHAR mt_sign[3]; // dau hieu nhan biet file *.lmp hoac *.lmr
	TCHAR mt_title[MAX_PATH];
	WORD mt_height, mt_width;
	WORD mt_color_number;
	BYTE mt_color_level;
	BYTE mt_bank;
	BYTE mt_ROMsize;
	PAGE *first_page;
} MATRIX_INFOR;

class LineDisp
{
public:
	BYTE line_style;
	WORD line_text_len;
	LPTSTR line_text;	// van ban text, chu thich, data format (date/time)
						// 0 - "the text",
						// 1 - "picture" drag/paint picture,
						// 2 - "hh:mm:ss - dd/mm/yyyy" date/time
						// 3 - "userfont1, userfont2..." user font,
	POINT pt; // x, y location
	RECT line_rect;
	HDC line_DC; // panel
	WORD data_size;
	HFONT line_font;
	LineDisp *lastline;
	LineDisp *nextline;

	HWND	hWndLine;
	POINT	obj_pos;		// vi tri cua dong TEXT
	SIZE	obj_size;		// kich thuoc dai x rong

	LineDisp(HWND, int, int);
	static	LRESULT CALLBACK LineDispWndProc(HWND, UINT, WPARAM, LPARAM);
	virtual	~LineDisp();

};

class MatrixView //:public TextView
{
private:
	HDC		hdc, hdcGrid, hdcText, hdcRect;
public:
	BYTE	disp_style;		// kieu t~inh hoac ngang hoac doc 0 - ti~nh, 1 - ngang, 2 - doc
	RECT	rt_mtv;			// rect cua doi tuong MatrixView - vung ve PTextMatrix
	int		zoom;			// 1, 2, 4, 8
	SIZE	matrix_size;	// kich thuoc ma tran dai x rong

	POINT	obj_pos;		// vi tri cua doi tuong
	SIZE	obj_size;		// kich thuoc bao toan bo cac doi tuong ve Line dung de tinh toan kich thuoc mt_draw_size
	SIZE	mt_draw_size;	// kich thuoc ve cua PTextMatrix phu thuoc vao cac kieu chay disp_style
	POINT	pt_matrixpos;	// vi tri tuong doi goc tren ben trai khi dich chuyen MatrixView trong PTextMatrix
	HWND	hWndMatrixView;
	_2page*	ppage;			// con tro page de tinh toan

	MatrixView(HWND);
	static	LRESULT CALLBACK MatrixViewWndProc(HWND, UINT, WPARAM, LPARAM);
	virtual	~MatrixView();

	void	OnDrawGrid(HDC);
	void	OnDrawObj(HDC);
	void	OnGetObjSize();
	void	OnSetPageDisp(_2page*);
	void	OnSetDispStyle(BYTE);
	void	OnPaint();
};

class PTextMatrix//:public MatrixView
{
	RECT		rt_mtv_client; // rect tam thoi de tinh toan cho window MatrixView
	RECT		rt_ptm; // rect cua doi tuong PTextMatrix
public:
	SCROLLINFO	sx, sy;
	UINT		xPos, yPos; // vi tri cua H va V Scroll
	int			numcol, numline;
	UINT		numcol_in_page, numline_in_page;
	_1matrix_infor* pmt_infor;
	MatrixView *pMatrixView;

	HWND	hWndPTextMatrix;

	PTextMatrix(HWND, _1matrix_infor*);
	static	LRESULT CALLBACK PTextMatrixWndProc(HWND, UINT, WPARAM, LPARAM);
	virtual ~PTextMatrix();

	void	OnSize();
	void	OnSetScroll();
	void	OnUpdatePTextMatrix(_2page*);
	void	HScroll(HWND, int, int);
	void	VScroll(HWND, int, int);
};

#endif
