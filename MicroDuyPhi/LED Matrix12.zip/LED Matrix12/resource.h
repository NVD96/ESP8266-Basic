//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LED Matrix.rc
//
#define IDC_MYICON                      2
#define IDD_LEDMATRIX_DIALOG            102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_LEDMATRIX                   107
#define IDI_SMALL                       108
#define IDC_LEDMATRIX                   109
#define IDR_MAINFRAME                   128
#define IDD_PROPERTY                    132
#define IDD_NEW_PROJECT                 134
#define IDD_LISTDIR                     135
#define IDB_PLANETS                     136
#define IDR_TREEICON                    137
#define IDD_DIALOG1                     141
#define IDC_COMBO1                      1002
#define IDC_COMBO2                      1003
#define IDC_COMBO3                      1004
#define IDC_COMBO4                      1006
#define IDC_RADIO1                      1007
#define IDC_RADIO2                      1008
#define IDC_RADIO3                      1009
#define IDC_EDIT1                       1010
#define IDC_EDIT2                       1011
#define IDC_BUTTON1                     1012
#define IDC_LISTDIR                     1012
#define IDC_COMBO5                      1013
#define IDL_FILES                       1015
#define IDS_PATHTOFILL                  1016
#define IDC_STATIC_WIDTH                1019
#define IDM_PROJECT_NEW                 32780
#define IDM_PROJECT_OPEN                32781
#define IDM_PROJECT_CLOSE               32782
#define IDM_PROJECT_SAVE                32783
#define IDM_PROJECT_SAVEAS              32784
#define IDM_PROJECT_EXIT                32785
#define IDM__MATRIX_NEW_PAGE            32786
#define IDM__MATRIX_NEW_FONT            32787
#define IDM__MATRIX_NEW_TEXT            32788
#define IDM__MATRIX_NEW_IMAGE           32789
#define IDM__MATRIX_NEW_DATETIME        32790
#define IDM__MATRIX_NEW_CHAR            32791
#define IDM_MATRIX_PROPERTIES           32792
#define IDM_MATRIX_DELETE               32793
#define IDM_MATRIX_CONVERTTOIMAGE       32794
#define IDM_MATRIX_CONVERTALL           32795
#define IDM_ROM_IMPORT                  32796
#define IDM_ROM_EXPORTPROJECT           32797
#define IDM_ROM_DEMO                    32798
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32799
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
