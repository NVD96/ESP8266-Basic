     #include <stdio.h>
     #include <stdlib.h>
     #include <math.h>
     
//     #define  N       8
//     #define  Log2N   3
     #define  PI      3.1415926535897
     
     int main(int argc, char* argv[])
     {
     	int temp_N = 2;
     	int k = 0,index;
     	
     	int Log2N;
     	
     	printf("Nhap Log2N: ");
        scanf("%i", &Log2N);
        
        int N = pow(2,Log2N);
     	
     	printf("// bang tra cuu Cos(a) cho FFT %i diem - he so nhan x100\n",N);
        printf("const signed char Cos_table[%i] =\n{\n",N-1);
        for(int buoc=0;buoc<Log2N;buoc++)
         {	
		    temp_N=pow(2, buoc+1);	
			index = pow(2, buoc);				
		    for(int k=0;k<index;k++)
             { 
        	   float x = -2.0*PI*k / temp_N;    
        	   x = cos(x) * 100;
        	   int x100;
        	   if(x>0) x100=x+0.55555;
        	   else x100=x-0.55555;
        	   printf("%i,",x100);  
		       //printf("%.6f,",cos(x));    
		     }
		     printf("    // Temp_N = %i\n",temp_N);
         }
         printf("};\n");
         system("pause");
         return 0;
     }

