            #include <stdio.h>
            #include <stdlib.h>
            #include <math.h>
//            #define  N               8
//            #define  LOG_2_N         3
            
            char *String_data = "RE";

            int bitRev(int a, int nBits)
            {
               int rev_a = 0;
               for (int i=0; i<nBits; i++)
               {
                  rev_a = (rev_a << 1) | (a & 1);
                  a     = a >> 1;
               }
               return rev_a;
            }

            int main(int argc, char* argv[])
            {
               int LOG_2_N;
     	       printf("Nhap Log2N: ");
               scanf("%i", &LOG_2_N);
        
               int N = pow(2,LOG_2_N);
        
               printf("//Nghich dao cho FFF %i diem\n",N);
               printf("void nghich_dao() // du lieu adc doc duoc can phai dua qua ham nay de xu li (goi ham nay 1 lan duy nhat truoc khi tinh FFT)\n{\n");
               printf("   unsigned int i;\n");
               for(int i=0; i<N; i++)
                  if (bitRev(i,LOG_2_N) > i)
                  {
                     printf("   i=%s[%3d]; "       ,String_data,i);
                     printf("%s[%3d]=%s[%3d]; ",String_data,i,String_data,bitRev(i,LOG_2_N));
                     printf("%s[%3d]=i;\n"         ,String_data,bitRev(i,LOG_2_N));
                  }
               printf("}");
               system("pause");
               return 0;
            }
