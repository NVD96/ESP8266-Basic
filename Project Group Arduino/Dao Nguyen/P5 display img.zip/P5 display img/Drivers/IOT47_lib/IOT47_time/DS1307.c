#include "DS1307.h"

unsigned char BCD_Decoder(unsigned char temp)
{
	return (temp & 0x0f) + (temp>>4)*10;
}
unsigned char BCD_Encoder(unsigned char temp)
{
	return ((temp/10)<<4)|(temp%10);
}

#ifdef USE_SOF_I2C
char AckTemp;
void DS1307_init(GPIO_TypeDef *SDA_Port,uint16_t SDA_pin,GPIO_TypeDef *SCL_Port,uint16_t SCL_pin)
{
	I2C_init(SDA_Port,SDA_pin,SCL_Port,SCL_pin); //khoi tao thu vien i2c
}
void ghids(unsigned char add, unsigned char dat)
{
	I2C_Start(); // bat dau ghi	
	I2C_Write(0xd0); //0xd0 la dia chi cua ds1307
	AckTemp=I2C_CheckAck();
	I2C_Write(add);	// gia tri can ghi
	AckTemp=I2C_CheckAck();
	I2C_Write(BCD_Encoder(dat)); 	 // do du lieu trong ds la BCD nen ta can chuyen ca gia tri sang BCD ( day cau lenh chuyen du lieu sang BCD)
	AckTemp=I2C_CheckAck();
	I2C_STOP();	 // ket thuc qua trinh truyen du lieu
	HAL_Delay(1);
}
unsigned char docds(unsigned char add)
{
	unsigned char dat;	
	I2C_Start();   // bat dau doc	
	I2C_Write(0xd0); 	// dau tien gui lenh ghi du lieu(ghi dia chi can lay du lieu trong DS1307)
	AckTemp=I2C_CheckAck();
	I2C_Write(add); // Dia chi ma ta muon doc ( vi du, muon doc giay thi ta ghi dia chi 0x00)
	AckTemp=I2C_CheckAck();
	I2C_Start(); 	 // bat dau doc du lieu
	I2C_Write(0xd1);  	// gui ma lenh doc du lieu tu dia chi(add)
	AckTemp=I2C_CheckAck();
	dat = I2C_Read();	  // doc xong thi luu gia tri da doc dc vao dat
	AckTemp=I2C_CheckAck(); 
	I2C_STOP();			// ket thuc qua trinh doc du lieu	
  return BCD_Decoder(dat);
}

void ghibyte(unsigned char add, unsigned char dat)
{
	I2C_Start(); // bat dau ghi	
	I2C_Write(0xd0); //0xd0 la dia chi cua ds1307
	AckTemp=I2C_CheckAck();
	I2C_Write(add);	// gia tri can ghi
	AckTemp=I2C_CheckAck();
	I2C_Write(dat); 	 // do du lieu trong ds la BCD nen ta can chuyen ca gia tri sang BCD ( day cau lenh chuyen du lieu sang BCD)
	AckTemp=I2C_CheckAck();
	I2C_STOP();	 // ket thuc qua trinh truyen du lieu
	HAL_Delay(1);
}
unsigned char docbyte(unsigned char add)
{
	unsigned char dat;	
	I2C_Start();   // bat dau doc	
	I2C_Write(0xd0); 	// dau tien gui lenh ghi du lieu(ghi dia chi can lay du lieu trong DS1307)
	AckTemp=I2C_CheckAck();
	I2C_Write(add); // Dia chi ma ta muon doc ( vi du, muon doc giay thi ta ghi dia chi 0x00)
	AckTemp=I2C_CheckAck();
	I2C_Start(); 	 // bat dau doc du lieu
	I2C_Write(0xd1);  	// gui ma lenh doc du lieu tu dia chi(add)
	AckTemp=I2C_CheckAck();
	dat = I2C_Read();	  // doc xong thi luu gia tri da doc dc vao dat
	AckTemp=I2C_CheckAck(); 
	I2C_STOP();			// ket thuc qua trinh doc du lieu	
  return dat;
}
#else
I2C_HandleTypeDef *my_i2c;
void DS1307_init(I2C_HandleTypeDef *i2c)
{
	my_i2c=i2c;
}
void ghids(unsigned char add, unsigned char dat)
{
   dat = BCD_Encoder(dat);
   HAL_I2C_Mem_Write(my_i2c,0x68<<1,add,I2C_MEMADD_SIZE_8BIT,(uint8_t *)&dat,1,1000); 
}
unsigned char docds(unsigned char add)
{
	uint8_t dat;
  HAL_I2C_Mem_Read(my_i2c,0x68<<1,add,I2C_MEMADD_SIZE_8BIT,(uint8_t *)&dat,1,100); //read time
	return BCD_Decoder(dat); //chuyen doi
}
void ghibyte(unsigned char add, unsigned char dat)
{
   HAL_I2C_Mem_Write(my_i2c,0x68<<1,add,I2C_MEMADD_SIZE_8BIT,(uint8_t *)&dat,1,1000); 
}
unsigned char docbyte(unsigned char add)
{
  uint8_t dat;
  HAL_I2C_Mem_Read(my_i2c,0x68<<1,add,I2C_MEMADD_SIZE_8BIT,(uint8_t *)&dat,1,100); //read time
	return dat; //chuyen doi
}
#endif
//----------------------------------------------------------------------------end file--------------------------------------------------------------------------//

