#ifndef __DS1307_H__
#define __DS1307_H__

//#define USE_SOF_I2C

#ifdef USE_SOF_I2C
#include "SWI2C.h"
void DS1307_init(GPIO_TypeDef *SDA_Port,uint16_t SDA_pin,GPIO_TypeDef *SCL_Port,uint16_t SCL_pin);
#else 
#include "stm32f1xx_hal.h"
void DS1307_init(I2C_HandleTypeDef *i2c);
#endif
void ghids(unsigned char add, unsigned char dat);
unsigned char docds(unsigned char add);
void ghibyte(unsigned char add, unsigned char dat);
unsigned char docbyte(unsigned char add);
#endif
//----------------------------------------------------------------------------end file--------------------------------------------------------------------------//

