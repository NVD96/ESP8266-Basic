#ifndef __P5_H__
#define __P5_H__

#include "stm32f1xx_hal.h"
#include "font.h"
#include "math.h"
#include "stdlib.h"

#define MAX_BIT       5

#define LAT       12  //B
#define OE        11  //B
#define clk       0   //B

#define D         1   //B
#define C         14  //B
#define B         10  //B
#define A         2   //B

#define A_SSET 0x00000001<<A
#define B_SSET 0x00000001<<B
#define C_SSET 0x00000001<<C
#define D_SSET 0x00000001<<D
#define A_RSET 0x00000001<<(A+16)
#define B_RSET 0x00000001<<(B+16)
#define C_RSET 0x00000001<<(C+16)
#define D_RSET 0x00000001<<(D+16)

#define B2        7 //a6 
#define R2        5 //a4
#define G2        6 //a5

#define B1        4 //a3
#define R1        2 //a1
#define G1        3 //a2


#define OE_P       GPIOB
#define xuat_P     GPIOB
#define clk_P      GPIOB
#define Control_P  GPIOB
#define data_PORT  GPIOA

#define P5_W  63
#define P5_H  31

#define S (unsigned char [])
#define FS (const unsigned char [])
	
typedef void (*func_scan)(char so);
typedef void (*func_set_px)(int x, int y, char cR,char cG,char cB);
extern func_set_px set_px;
extern func_scan scaning;

void P5_init(void);
void P5_zoom_init(void);

void ngatquetled(void);
void math(int hang);
void set_type_scan(char type);
void scan16S(char so);
void scan8S(char so);
void SET_dosang(uint16_t sang);
uint16_t GET_dosang(void);

void P5_chonvitri(int x,int y);
char readbit_font1(int x,int y,char num,int font);
char readbit_font2(int x,int y,char num,int font);
char readbit_font3(int x,int y,unsigned char txt);
char readbit_font4(int x,int y,unsigned char txt);
char readbit_font5(int x,int y,unsigned char txt);
void Set_color(char cR,char cG,char cB);
void P5_dot_font1(char x,char y,char num);
void P5_sendnumber_font1(char x,char y,char num,int font);
void P5_sendnumber_font2(char x,char y,char num,int font);
void P5_sendnumber_font4(char x,char y,char num);
void P5_sendnumber_font5(char x,char y,char num);
void P5_sendnumber_F5(unsigned char num,unsigned char cR,unsigned char cG,unsigned char cB);
void P5_sendnumber_textfont5(unsigned char *s, unsigned char *c);
	
void P5_sendtext_wColor(unsigned char txt,char cR,char cG,char cB);
void P5_sendString_wColor(unsigned char *s,char cR,char cG,char cB);
void P5_sendString_wColorRun(int vitri,char kt,uint16_t index);
void P5_sendtext(unsigned char txt);
void P5_sendString(unsigned char *s);
void P5_clear_alltext(void);
void P5_SetStringRun(unsigned char *s);
unsigned int P5_StringRunGetlength(void);
unsigned char P5_GetStringRun(int vitri);
void P5_SetStringRunY(int y);
void P5_StringRun(void);
void P5_StringRun_init(void);
void Getchu(int vitri);
void String_runSetTxt(int vitri,unsigned char txt);
void String_runSetALLColor(char cR,char cG,char cB);
void P5_image(int sizex,int sizey,int x,int y,unsigned char *img); //in anh ra man hinh
void lattrang_number_font1(int x,int y,int sizex,int sizey,int vitri_y,int num,int font);
void lattrang_number_font2(int x,int y,int sizex,int sizey,int vitri_y,int num,int font);

void P5_sendtextFontAS57_wColor(unsigned char txt,char cR,char cG,char cB);
void P5_sendStringFontAS57_wColor(unsigned char *s,char cR,char cG,char cB);
void display_QR_code(unsigned char txt,char cR,char cG,char cB);

unsigned char getpx(char c,uint16_t x,uint16_t y);
void set_px1(int x, int y, char cR,char cG,char cB);
void set_px2(int x, int y, char cR,char cG,char cB);
void set_R(int x, int y, char c);
void set_G(int x, int y, char c);
void set_B(int x, int y, char c);
void P5_veduongngang(unsigned char x, unsigned char y,unsigned char dodai,char cR,char cG,char cB);
void P5_veduongdoc(unsigned char x, unsigned char y,unsigned char dodai,char cR,char cG,char cB);
void P5_veduongthang(int x, int y,int x1, int y1,char cR,char cG,char cB);
void Clock_Analog_BackGround(void);
void Clock_Analog(int gio,int phut,int giay,unsigned char *c);

int Random(int n);
void P5_ve_hinh_tron_kin(int x0,int y0,int r, char cR,char cG,char cB);
void P5_ve_hinh_tron(int x0,int y0,int r,char cR,char cG,char cB) ;
void P5_outtro(char effect);
void P5_clear(void);
void P5_clearTOP(void);
void P5_clearBOT(void);
void P5_vehinhchunhat_kin(unsigned char x, unsigned char y,unsigned char rong, unsigned char cao,char cR,char cG,char cB);
void P5_vehinhchunhat(unsigned char x, unsigned char y,unsigned char rong, unsigned char cao,char cR,char cG,char cB);
void P5_vehinhchunhat_Vien(unsigned char x, unsigned char y,unsigned char rong, unsigned char cao,char cR,char cG,char cB);
void P5_special(char i);
	
#endif  //__P5_H__
