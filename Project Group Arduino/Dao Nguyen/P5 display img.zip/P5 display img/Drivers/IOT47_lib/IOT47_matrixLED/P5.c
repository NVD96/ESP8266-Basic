#include "P5.h"

func_set_px set_px;

extern TIM_HandleTypeDef htim2;
extern unsigned char loaiLED;

unsigned int const timer_clock16S[8]={18,36,72,144,288,575}; // he so chia nap vao timer
unsigned int const timer_clock8S[8]={36,72,144,288,575,1150}; // he so chia nap vao timer

unsigned int timer_clock[8]={18,36,72,144,288,575}; // he so chia nap vao timer
unsigned char vitri_bit=0; // kiem tra xem dang quet den bit nao
unsigned char hang_led;
uint8_t led[MAX_BIT*64];
uint8_t led2[MAX_BIT*64];
unsigned char display1[3][32][64];
//unsigned char display2[3][32][64];
unsigned char *display=&display1[0][0][0];
//unsigned char *_display=&display1[0][0][0];
#define arrD1 (32*64)
#define arrD2 (64)

signed int P5_x,P5_y;
unsigned char COLOR[2][3]={0,0,0,0,0,0};

int dosang;

int String_RUN_Y=0; //vi tri chu chay theo truc Y 
#define String_maxHEIGHT 16
#define String_maxLEN 128
unsigned char String_RUN[String_maxLEN];
unsigned char String_COLOR[3];


//void P5_setBuff_Accset(char buf)
//{
//	if(buf==0)display=&display1[0][0][0];
//	else display=&display2[0][0][0];
//}
//void P5_setBuff_Disp(void)
//{
//	_display=display;
//}

//---------------------------------Chuong trinh quet LED ma tran --------------------------------------------------------//
const unsigned char scan_data[2][16]=
{
	 0,8,4,12, 2,10,6,14, 1,9,5,13, 3,11,7,15,
	 0,4,2,6,  1,5,3,7,   0,4,2,6,  1,5,3,7,
};

// bat sang hang tu 1->16 ( do tam matrix P5 quet 1/16) (1 thoi diem chi co duy nhat 1 hang duoc sang len)
func_scan scaning;
uint16_t ScanMax;
uint8_t type_scan;
void set_type_scan(char type)
{
	type_scan=type;
	if(type_scan==0) //led P5
	{
		ScanMax=16;
		scaning=&scan16S;
		for(char i=0;i<8;i++)timer_clock[i]=timer_clock16S[i];
	}
	else //led P10
	{
		ScanMax=8;
		scaning=&scan8S;
		for(char i=0;i<8;i++)timer_clock[i]=timer_clock8S[i];
	}
}
void scan16S(char so)
{
	switch(so)
	{
		case 0: Control_P->BSRR= A_RSET|B_RSET|C_RSET|D_RSET;  return;
		case 1: Control_P->BSRR= A_RSET|B_RSET|C_RSET|D_SSET;  return;
		case 2: Control_P->BSRR= A_RSET|B_RSET|C_SSET|D_RSET;  return;
		case 3: Control_P->BSRR= A_RSET|B_RSET|C_SSET|D_SSET;  return;
		case 4: Control_P->BSRR= A_RSET|B_SSET|C_RSET|D_RSET;  return;
		case 5: Control_P->BSRR= A_RSET|B_SSET|C_RSET|D_SSET;  return;
		case 6: Control_P->BSRR= A_RSET|B_SSET|C_SSET|D_RSET;  return;
		case 7: Control_P->BSRR= A_RSET|B_SSET|C_SSET|D_SSET;  return;
		case 8: Control_P->BSRR= A_SSET|B_RSET|C_RSET|D_RSET;  return;
		case 9: Control_P->BSRR= A_SSET|B_RSET|C_RSET|D_SSET;  return;
		case 10:Control_P->BSRR= A_SSET|B_RSET|C_SSET|D_RSET;  return;
		case 11:Control_P->BSRR= A_SSET|B_RSET|C_SSET|D_SSET;  return;
		case 12:Control_P->BSRR= A_SSET|B_SSET|C_RSET|D_RSET;  return;
		case 13:Control_P->BSRR= A_SSET|B_SSET|C_RSET|D_SSET;  return;
		case 14:Control_P->BSRR= A_SSET|B_SSET|C_SSET|D_RSET;  return;
		case 15:Control_P->BSRR= A_SSET|B_SSET|C_SSET|D_SSET;  return;
	}
}
void scan8S(char so)
{
	switch(so)
	{
		case 0: Control_P->BSRR= B_RSET|C_RSET|D_RSET;  return;
		case 1: Control_P->BSRR= B_RSET|C_RSET|D_SSET;  return;
		case 2: Control_P->BSRR= B_RSET|C_SSET|D_RSET;  return;
		case 3: Control_P->BSRR= B_RSET|C_SSET|D_SSET;  return;
		case 4: Control_P->BSRR= B_SSET|C_RSET|D_RSET;  return;
		case 5: Control_P->BSRR= B_SSET|C_RSET|D_SSET;  return;
		case 6: Control_P->BSRR= B_SSET|C_SSET|D_RSET;  return;
		case 7: Control_P->BSRR= B_SSET|C_SSET|D_SSET;  return;
	}
}
void math(int hang)
{  
	uint8_t dat;
	if(type_scan==1)
	{
		uint8_t hang_guongY=7-hang;
		for(int ts=0;ts<MAX_BIT;ts++)
		{
		 for(int i=0;i<64;i++)
		 {
			 dat = 0;
			 if((display[1*arrD1 + (8+hang)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<G2);} //ghi bit 7 G2 
			 if((display[1*arrD1 + (0+hang)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<G1);} //ghi bit 0 G1
			 if((display[0*arrD1 + (0+hang)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<R1);} //ghi bit 1 R1
			 if((display[2*arrD1 + (0+hang)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<B1);} //ghi bit 4 B1
			 if((display[0*arrD1 + (8+hang)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<R2);} //ghi bit 6 R2
			 if((display[2*arrD1 + (8+hang)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<B2);} //ghi bit 9 B2
			 led[ts*64 + i]=dat;
		 }
		 for(int i=0;i<64;i++)
		 {
			 dat = 0;
			 if((display[1*arrD1 + (16+hang_guongY)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<G2);} //ghi bit 7 G2 
			 if((display[1*arrD1 + (24+hang_guongY)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<G1);} //ghi bit 0 G1
			 if((display[0*arrD1 + (24+hang_guongY)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<R1);} //ghi bit 1 R1
			 if((display[2*arrD1 + (24+hang_guongY)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<B1);} //ghi bit 4 B1
			 if((display[0*arrD1 + (16+hang_guongY)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<R2);} //ghi bit 6 R2
			 if((display[2*arrD1 + (16+hang_guongY)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<B2);} //ghi bit 9 B2
			 led2[ts*64 + (63-i)]=dat;
		 }
		} 
	}
	else
	{
		for(int ts=0;ts<MAX_BIT;ts++)
		{
		 for(int i=0;i<64;i++)
		 {
			 dat = 0;
			 if((display[1*arrD1 + (16+hang)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<G2);} //ghi bit 7 G2 
			 if((display[1*arrD1 + (0+hang)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<G1);} //ghi bit 0 G1
			 if((display[0*arrD1 + (0+hang)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<R1);} //ghi bit 1 R1
			 if((display[2*arrD1 + (0+hang)*arrD2 + i]  & (1<<ts)) != 0 ){dat|=(0x01<<B1);} //ghi bit 4 B1
			 if((display[0*arrD1 + (16+hang)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<R2);} //ghi bit 6 R2
			 if((display[2*arrD1 + (16+hang)*arrD2 + i] & (1<<ts)) != 0 ){dat|=(0x01<<B2);} //ghi bit 9 B2
			 led[ts*64 + i]=dat;
		 }
		} 
  }
}
void ngatquetled(void)
{
	TIM4 -> PSC = timer_clock[vitri_bit]; 	 // nap gia tri chia moi 
	TIM4->EGR = 1;                           //set EGR len 1 de load lai PSC
	TIM4 ->SR = 0xFFFFFFFE;                  //xoa co ngat
	
  __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,0);
	
	if(type_scan==1)//voi P10 thi gui them data
	{
		for(int i=0;i<64;i++){data_PORT->ODR=led2[vitri_bit*64 + i];clk_P->BSRR=(1<<(clk+16));clk_P->BSRR=(1<<clk);} 
		for(int i=0;i<64;i++){data_PORT->ODR=led[vitri_bit*64 + i];clk_P->BSRR=(1<<(clk+16));clk_P->BSRR=(1<<clk);} 
	}
  else 
  {
    for(int i=0;i<64;i++){data_PORT->ODR=led[vitri_bit*64 + i];clk_P->BSRR=(1<<(clk+16));clk_P->BSRR=(1<<clk);}	 
  }		
	scaning(scan_data[loaiLED][hang_led]);
	Control_P->BSRR=(1<<LAT); // chot data
	Control_P->BSRR=(1<<(LAT+16));
	__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,dosang);
	
	vitri_bit++;
	if(vitri_bit==MAX_BIT){vitri_bit=0;hang_led++;if(hang_led==ScanMax)hang_led=0;math(scan_data[loaiLED][hang_led]);}	
}
void SET_dosang(uint16_t sang)
{
	 dosang=sang;
}
uint16_t GET_dosang(void)
{
	 return dosang;
}
// ------------------------CHuong trinh xu li do hoa ------------------------------------------------------//
void P5_chonvitri(int x,int y)
{
	P5_x  = x;
	P5_y  = y;
}
char readbit_dot(int x,int y,char num)
{
	char temp = x%8;
	return (number_dot[num][y][x/8] & (0x80 >> temp)) >> (7-temp);
}
char readbit_font1(int x,int y,char num,int font)
{
	char temp = x%8;
	if(font!=4)
	return (number_font1[font][num][y][x/8] & (0x80 >> temp)) >> (7-temp);
	else return (number_font1_canhan[num][y][x/8] & (0x80 >> temp)) >> (7-temp);
}
char readbit_font2(int x,int y,char num,int font)
{
	char temp = x%8;
	return (number_font2[font][num][y][x/8] & (0x80 >> temp)) >> (7-temp);
}
char readbit_font3(int x,int y,unsigned char txt)
{
	char temp = x%8;
	return (font11[txt][y][x/8] & (0x80 >> temp)) >> (7-temp);
}
char readbit_font4(int x,int y,unsigned char txt)
{
	char temp = x%8;
	return (number_font4[txt][y][x/8] & (0x80 >> temp)) >> (7-temp);
}
char readbit_font5(int x,int y,unsigned char txt)
{
	char temp = x%8;
	return (number_font5[txt][y][x/8] & (0x80 >> temp)) >> (7-temp);
}
char readbit_fontAS57(int x,int y,unsigned char txt)
{
	char temp = x%8;
	return (fontAs57[txt*7*1 + y*1 + x/8]& (0x80 >> temp)) >> (7-temp);
}
char readbit_fontQR(int x,int y,unsigned char txt)
{
	char temp = x%8;
	return (QR_code[txt*32*4 + y*4 + x/8]& (0x80 >> temp)) >> (7-temp);
}
void Set_color(char cR,char cG,char cB)
{
	COLOR[1][0] = cR;
	COLOR[1][1] = cG;
	COLOR[1][2] = cB;
}
void P5_sendtextFontAS57_wColor(unsigned char txt,char cR,char cG,char cB) 
{
	Set_color(cR,cG,cB);
	if(P5_y>=P5_H)return;
	if(P5_x>=P5_W)
	{
			 P5_x=0;
			 P5_y+=8;
	}
	if(txt == '\n')
	{
			 P5_x=0;
			 P5_y+=8;
		return;
	}
	int sizew=6;
	if(txt==' ')sizew=2;
	 for(int mau=0;mau<3;mau++)
	 {
		  for(int i=P5_y;i<7+P5_y;i++)
		  {
				 for(int k=P5_x;k<P5_x+sizew;k++)
				 {
					  if(k > P5_W)break;
					  display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_fontAS57(k-P5_x,i-P5_y,txt-32)][mau];
            //set_px();					 
				 }
			}
	 }
	 P5_x += sizew;
}
void P5_init(void)
{
	set_px = &set_px1;
}
void P5_zoom_init(void)
{
	set_px = &set_px2;
}
//void display_QR_code(unsigned char txt,char cR,char cG,char cB) 
//{
//	Set_color(cR,cG,cB);
//	for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=P5_y;i<32+P5_y;i++)
//		  {
//				 for(int k=P5_x;k<P5_x+32;k++)
//				 {
//					  if(k > P5_W)break;
//					  display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_fontQR(k-P5_x,i-P5_y,txt)][mau];
//				 }
//			}
//	 }
//}
void display_QR_code(unsigned char txt,char cR,char cG,char cB)
{
	Set_color(cR,cG,cB);
	for(int i=P5_y;i<32+P5_y;i++)
	{
		 for(int k=P5_x;k<P5_x+32;k++)
		 {
			 if(k > P5_W)break;
			 unsigned char _R,_G,_B;
			 uint16_t _k = k-P5_x;
			 uint16_t _i = i-P5_y;
			 _R = COLOR[readbit_fontQR(_k,_i,txt)][0];
			 _G = COLOR[readbit_fontQR(_k,_i,txt)][1];
			 _B = COLOR[readbit_fontQR(_k,_i,txt)][2];
			 set_px(k,i,_R,_G,_B);
		 }
	}
}
void P5_sendStringFontAS57_wColor(unsigned char *s,char cR,char cG,char cB) 
{
	while(*s)
	 {
		  P5_sendtextFontAS57_wColor(*s,cR,cG,cB);
		  s++;
	 }
}
//void P5_dot_font1(char x,char y,char num) //gui dau cham ra man hinh
//{
//	char width=5;
//	for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=y;i<20+y;i++)
//		  {
//				 for(int k=x;k<width+x;k++)
//				 {
//					  if(COLOR[1][0] < 32)display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_dot(k-x,i-y,num)][mau];
//					  else 
//		        {
//							if(readbit_dot(k-x,i-y,num)!=0)display[mau*arrD1 + i*arrD2 + k] = Color_Font[255-COLOR[1][0]][mau][i-y][k-x]; 
//							else display[mau*arrD1 + i*arrD2 + k] = 0;
//						}
//				 }
//			}
//	 }
//}
void P5_dot_font1(char x,char y,char num) //gui dau cham ra man hinh
{
	char width=5;
	for(int i=y;i<20+y;i++)
	{
		 for(int k=x;k<width+x;k++)
		 {
			  unsigned char _R,_G,_B;
				uint16_t _k = k-x;
				uint16_t _i = i-y;
				if(COLOR[1][0] < 32)
				{
					_R = COLOR[readbit_dot(_k,_i,num)][0];
				  _G = COLOR[readbit_dot(_k,_i,num)][1];
				  _B = COLOR[readbit_dot(_k,_i,num)][2];
					set_px(k,i,_R,_G,_B);
				}
				else 
				{					
					if(readbit_dot(k-x,i-y,num)!=0)
						{
							uint8_t c_index = 255-COLOR[1][0];
							_R = Color_Font[c_index][0][_i][_k];
							_G = Color_Font[c_index][1][_i][_k];
							_B = Color_Font[c_index][2][_i][_k];	
							set_px(k,i,_R,_G,_B);
						}
					else 
						set_px(k,i,0,0,0);
				}
		 }
	}
}
//void P5_sendnumber_font1(char x,char y,char num,int font) //gui so ra man hinh
//{
//	 char width=13;
//	 for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=y;i<20+y;i++)
//		  {
//				 for(int k=x;k<width+x;k++)
//				 {
//					  if(COLOR[1][0] < 32)display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_font1(k-x,i-y,num,font)][mau];
//					  else 
//		        {
//							if(readbit_font1(k-x,i-y,num,font)!=0)display[mau*arrD1 + i*arrD2 + k] = Color_Font[255-COLOR[1][0]][mau][i-y][k-x]; 
//							else display[mau*arrD1 + i*arrD2 + k] = 0;
//						}
//				 }
//			}
//	 }
//}
void P5_sendnumber_font1(char x,char y,char num,int font) //gui so ra man hinh
{
	 char width=13;
		for(int i=y;i<20+y;i++)
		{
			 for(int k=x;k<width+x;k++)
			 {
				  unsigned char _R,_G,_B;
					uint16_t _k = k-x;
					uint16_t _i = i-y;
					if(COLOR[1][0] < 32)
					{
						_R = COLOR[readbit_font1(_k,_i,num,font)][0];
						_G = COLOR[readbit_font1(_k,_i,num,font)][1];
						_B = COLOR[readbit_font1(_k,_i,num,font)][2];
						set_px(k,i,_R,_G,_B);
					}
					else 
					{
						if(readbit_font1(k-x,i-y,num,font)!=0)
						{
							uint8_t c_index = 255-COLOR[1][0];
							_R = Color_Font[c_index][0][_i][_k];
							_G = Color_Font[c_index][1][_i][_k];
							_B = Color_Font[c_index][2][_i][_k];	
							set_px(k,i,_R,_G,_B); 
						}
						else set_px(k,i,0,0,0); 
					}
			 }
		}
}
//void P5_sendnumber_font2(char x,char y,char num,int font) //gui so ra man hinh
//{
//	 char width=9;
//	 char f = 0;
//	 if(font != 0 ) f=1;
//	 if(num>=10)width=3;
//	 for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=y;i<12+y;i++)
//		  {
//				 for(int k=x;k<width+x;k++)
//				 {
//					  display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_font2(k-x,i-y,num,f)][mau];
//				 }
//			}
//	 }
//}
void P5_sendnumber_font2(char x,char y,char num,int font) //gui so ra man hinh
{
	 char width=9;
	 char f = 0;
	 if(font != 0 ) f=1;
	 if(num>=10)width=3;
	 for(int i=y;i<12+y;i++)
		{
			 for(int k=x;k<width+x;k++)
			 {
				  unsigned char _R,_G,_B;
					uint16_t _k = k-x;
					uint16_t _i = i-y;
				  _R = COLOR[readbit_font2(_k,_i,num,f)][0];
					_G = COLOR[readbit_font2(_k,_i,num,f)][1];
					_B = COLOR[readbit_font2(_k,_i,num,f)][2];
					set_px(k,i,_R,_G,_B);
			 }
		}
}
//void P5_sendnumber_font4(char x,char y,char num) //gui so ra man hinh
//{
//	 char width=7;
//	 if(num==10)width=3;
//	 for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=y;i<10+y;i++)
//		  {
//				 for(int k=x;k<width+x;k++)
//				 {
//					  display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_font4(k-x,i-y,num)][mau];
//				 }
//			}
//	 }
//}
void P5_sendnumber_font4(char x,char y,char num) //gui so ra man hinh
{
	 char width=7;
	 if(num==10)width=3;
	 for(int i=y;i<10+y;i++)
		{
			 for(int k=x;k<width+x;k++)
			 {
				  unsigned char _R,_G,_B;
					uint16_t _k = k-x;
					uint16_t _i = i-y;
				  _R = COLOR[readbit_font4(_k,_i,num)][0];
					_G = COLOR[readbit_font4(_k,_i,num)][1];
					_B = COLOR[readbit_font4(_k,_i,num)][2];
					set_px(k,i,_R,_G,_B);
			 }
		}
}
//void P5_sendnumber_font5(char x,char y,char num) //gui so ra man hinh
//{
//	 char width=6;
//	 if(num==10)width=4;
//	 for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=y;i<7+y;i++)
//		  {
//				 for(int k=x;k<width+x;k++)
//				 {
//					  display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_font5(k-x,i-y,num)][mau];
//				 }
//			}
//	 }
//}
void P5_sendnumber_font5(char x,char y,char num) //gui so ra man hinh
{
	 char width=6;
	 if(num==10)width=4;
		  for(int i=y;i<7+y;i++)
		  {
				 for(int k=x;k<width+x;k++)
				 {
					  unsigned char _R,_G,_B;
						uint16_t _k = k-x;
						uint16_t _i = i-y;
						_R = COLOR[readbit_font5(_k,_i,num)][0];
						_G = COLOR[readbit_font5(_k,_i,num)][1];
						_B = COLOR[readbit_font5(_k,_i,num)][2];
					  set_px(k,i,_R,_G,_B);
				 }
			}
}
//void P5_sendnumber_F5(unsigned char num,unsigned char cR,unsigned char cG,unsigned char cB) //gui so ra man hinh
//{
//	 unsigned char CL[2][3]={0,0,0,cR,cG,cB};
//	 char width=6;
//	 if(num==10)width=4;
//	 for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=P5_y;i<7+P5_y;i++)
//		  {
//				 for(int k=P5_x;k<width+P5_x;k++)
//				 {
//					  if(k>P5_W)break;
//					  if(i>P5_H)break;
//					  if(k<0)continue;
//					  if(i<0)continue;
//					  display[mau*arrD1 + i*arrD2 + k] = CL[readbit_font5(k-P5_x,i-P5_y,num)][mau];
//				 }
//			}
//	 }
//	 P5_x +=6;
//}
void P5_sendnumber_F5(unsigned char num,unsigned char cR,unsigned char cG,unsigned char cB) //gui so ra man hinh
{
	 unsigned char CL[2][3]={0,0,0,cR,cG,cB};
	 char width=6;
	 if(num==10)width=4;
		  for(int i=P5_y;i<7+P5_y;i++)
		  {
				 for(int k=P5_x;k<width+P5_x;k++)
				 {
					  if(k>P5_W)break;
					  if(i>P5_H)break;
					  if(k<0)continue;
					  if(i<0)continue;
					  unsigned char _R,_G,_B;
						uint16_t _k = k-P5_x;
						uint16_t _i = i-P5_y;
						_R = CL[readbit_font5(_k,_i,num)][0];
						_G = CL[readbit_font5(_k,_i,num)][1];
						_B = CL[readbit_font5(_k,_i,num)][2];
					  set_px(k,i,_R,_G,_B);
				 }
			}
	 P5_x +=6;
}
void P5_sendnumber_textfont5(unsigned char *s, unsigned char *c)
{
	int i=0;
	while(*s)
	 {
		  P5_sendnumber_F5(*s -1,c[i],c[i+1],c[i+2]);
		  s++;
		  i+=3;
	 }
}
//void P5_sendtext(unsigned char txt) //gui chu tieng Viet ra man hinh
//{
//	 if(P5_x==P5_W)return;
//	 for(int mau=0;mau<3;mau++)
//	 {
//		  for(int i=P5_y;i<16+P5_y;i++)
//		  {
//				 for(int k=P5_x;k<P5_x+Width_font11[txt];k++)
//				 {
//					  if(k > P5_W)break;
//					  display[mau*arrD1 + i*arrD2 + k] = COLOR[readbit_font3(k-P5_x,i-P5_y,txt)][mau];
//				 }
//			}
//	 }
//	 P5_x += Width_font11[txt];
//	 if(P5_x>P5_W)P5_x=P5_W;
//}
void P5_sendtext(unsigned char txt) //gui chu tieng Viet ra man hinh
{
	 if(P5_x==P5_W)return;
		for(int i=P5_y;i<16+P5_y;i++)
		{
			 for(int k=P5_x;k<P5_x+Width_font11[txt];k++)
			 {
					if(k > P5_W)break;
					unsigned char _R,_G,_B;
					uint16_t _k = k-P5_x;
					uint16_t _i = i-P5_y;
					_R = COLOR[readbit_font3(_k,_i,txt)][0];
					_G = COLOR[readbit_font3(_k,_i,txt)][1];
					_B = COLOR[readbit_font3(_k,_i,txt)][2];
					set_px(k,i,_R,_G,_B);
			 }
		}
	 P5_x += Width_font11[txt];
	 if(P5_x>P5_W)P5_x=P5_W;
}
void P5_sendString(unsigned char *s)
{
	 while(*s)
	 {
		  P5_sendtext(*s);
		  s++;
	 }
}
//void P5_sendtext_wColor(unsigned char txt,char cR,char cG,char cB) //gui chu tieng Viet ra man hinh
//{
//	  char cl[2][3]={0,0,0,cR,cG,cB};
//		if(P5_x==P5_W)return;
//		for(int mau=0;mau<3;mau++)
//	  {
//			for(int i=P5_y;i<16+P5_y;i++)
//			{
//				 for(int k=P5_x;k<P5_x+Width_font11[txt];k++)
//				 {
//						if(k > P5_W)break;
//						display[mau*arrD1 + i*arrD2 + k] = cl[readbit_font3(k-P5_x,i-P5_y,txt)][mau];
//				 }
//			}
//		}
//	P5_x += Width_font11[txt];
//	if(P5_x>P5_W)P5_x=P5_W;
//}
void P5_sendtext_wColor(unsigned char txt,char cR,char cG,char cB) //gui chu tieng Viet ra man hinh
{
	  char cl[2][3]={0,0,0,cR,cG,cB};
		if(P5_x==P5_W)return;
		for(int i=P5_y;i<16+P5_y;i++)
		{
			 for(int k=P5_x;k<P5_x+Width_font11[txt];k++)
			 {
					if(k > P5_W)break;
				  unsigned char _R,_G,_B;
					uint16_t _k = k-P5_x;
					uint16_t _i = i-P5_y;
					_R = cl[readbit_font3(_k,_i,txt)][0];
					_G = cl[readbit_font3(_k,_i,txt)][1];
					_B = cl[readbit_font3(_k,_i,txt)][2];
					set_px(k,i,_R,_G,_B);
			 }
		}
	P5_x += Width_font11[txt];
	if(P5_x>P5_W)P5_x=P5_W;
}
void P5_sendString_wColor(unsigned char *s,char cR,char cG,char cB)
{
	 while(*s)
	 {
		  P5_sendtext_wColor(*s,cR,cG,cB);
		  s++;
	 }
}
//void P5_sendString_wColorRun(int vitri,char kt,uint16_t index)
//{
//	 int dem=0,sl=0;
//	 char W = Width_font11[String_RUN[index+vitri]];
//	 if(W==0)W=16;
//	 while(String_RUN[vitri]) 
//	 {
//		   if(String_RUN[vitri]==232)break; //
//		   if(kt==1 && dem==index)
//			 {

//						for(int mau=0;mau<3;mau++)
//							{
//								for(int i=P5_y;i<16+P5_y;i++)
//								{
//									 for(int k=P5_x;k<P5_x+W;k++)
//									 {
//											if(i==20)display[mau*arrD1 + i*arrD2 + k] = 31;
//											else display[mau*arrD1 + i*arrD2 + k] = 0;
//									 }
//								}
//							}
//						P5_x += W;
//						vitri++;dem++;kt=0;
//			 }
//		  P5_sendtext_wColor(String_RUN[vitri],String_COLOR[0],String_COLOR[1],String_COLOR[2]);
//		  vitri++;dem++;
//		  if(dem>10)return;
//			sl++;
//	 } 
//	  //in ki tu ket thuc
//	  dem=0;
//	  if(P5_x<60)
//		{
//			for(int i=P5_y;i<16+P5_y;i++)
//			{
//				 for(int k=P5_x;k<P5_x+63;k++)
//				 {
//						if(k==64)break;
//						if(dem<4)display[0*arrD1 + i*arrD2 + k] = 31;
//						else display[0*arrD1 + i*arrD2 + k] = 0;
//						display[1*arrD1 + i*arrD2 + k] = 0;
//						display[2*arrD1 + i*arrD2 + k] = 0;
//				 }
//			}
//		}
//}
void P5_sendString_wColorRun(int vitri,char kt,uint16_t index)
{
	 int dem=0,sl=0;
	 char W = Width_font11[String_RUN[index+vitri]];
	 if(W==0)W=16;
	 while(String_RUN[vitri]) 
	 {
		   if(String_RUN[vitri]==232)break; //
		   if(kt==1 && dem==index)
			 {
								for(int i=P5_y;i<16+P5_y;i++)
								{
									 for(int k=P5_x;k<P5_x+W;k++)
									 {
											if(i==16)
												set_px(k,i,31,31,31);
											else 
												set_px(k,i,0,0,0);
									 }
								}
						P5_x += W;
						vitri++;dem++;kt=0;
			 }
		  P5_sendtext_wColor(String_RUN[vitri],String_COLOR[0],String_COLOR[1],String_COLOR[2]);
		  vitri++;dem++;
		  if(dem>10)return;
			sl++;
	 } 
	  //in ki tu ket thuc
	  dem=0;
	  if(P5_x<60)
		{
			for(int i=P5_y;i<16+P5_y;i++)
			{
				 for(int k=P5_x;k<P5_x+63;k++)
				 {
						if(k==64)break;
						if(dem<4)set_px(k,i,31,0,0);
						else set_px(k,i,0,0,0);
				 }
			}
		}
}
int chu,kiemtraktdich;
void Getchu(int vitri)
{
	chu=vitri;
	kiemtraktdich=0;
}
void P5_clear_alltext(void)
{
	for(int i=0;i<String_maxLEN;i++) //copy data
	 {
		  String_RUN[i]=0;
	 }
}
void P5_SetStringRun(unsigned char *s)
{	 
	 for(int i=0;i<String_maxLEN;i++)String_RUN[i]=0;//clear data
	 for(int i=0;i<String_maxLEN;i++) //copy data
	 {
		  if((*s) == 0)break;
		  String_RUN[i] = (*s);
		  s++;
	 }
	 chu=kiemtraktdich=0;
}
unsigned char P5_GetStringRun(int vitri)
{
	return String_RUN[vitri];
}
void P5_SetStringRunY(int y)
{
	String_RUN_Y=y; 
}
int debig;
void P5_StringRun(void)
{
	 if(String_RUN[0] == 0) return;
	 for(int x=0;x<P5_W;x++)                       //dich trai toan bo mang du lieu
		 {         
				 for(int y=String_RUN_Y;y<String_maxHEIGHT+String_RUN_Y;y++)
				 {                   
						if(String_COLOR[0]!=255)
						{
							display[0*arrD1 + y*arrD2 + x] = display[0*arrD1 + y*arrD2 + x+1];
							display[1*arrD1 + y*arrD2 + x] = display[1*arrD1 + y*arrD2 + x+1];
							display[2*arrD1 + y*arrD2 + x] = display[2*arrD1 + y*arrD2 + x+1];
						}
						else //use mask
						{
							if(display[0*arrD1 + y*arrD2 + x+1]!=0 || display[1*arrD1 + y*arrD2 + x+1]!=0 || display[2*arrD1 + y*arrD2 + x+1]!=0)
								   {
										 display[0*arrD1 + y*arrD2 + x]=mask_text[0][y-String_RUN_Y][x];
										 display[1*arrD1 + y*arrD2 + x]=mask_text[1][y-String_RUN_Y][x];
										 display[2*arrD1 + y*arrD2 + x]=mask_text[2][y-String_RUN_Y][x];
									 }
							else {
								     display[0*arrD1 + y*arrD2 + x]=0;
								     display[1*arrD1 + y*arrD2 + x]=0;
								     display[2*arrD1 + y*arrD2 + x]=0;
							     }
						}
				 }   
		 }
	
	//dua du lieu moi vao cot cuoi cung
	for(int mau=0;mau<3;mau++)
	{
		 for(int y=String_RUN_Y;y<String_maxHEIGHT+String_RUN_Y;y++)
				 {                 				 
					  if(readbit_font3(kiemtraktdich,y-String_RUN_Y,String_RUN[chu]) == 1)
						{
							if(String_COLOR[0]!=255)display[mau*arrD1 + y*arrD2 + P5_W] = String_COLOR[mau];   
							else //use mask
							{
								display[mau*arrD1 + y*arrD2 + P5_W]=mask_text[mau][y-String_RUN_Y][P5_W]; 
							}
						}
						else display[mau*arrD1 + y*arrD2 + P5_W]=0;
				 } 
	}
	kiemtraktdich++;
	if(kiemtraktdich==Width_font11[String_RUN[chu]])
  {
		chu++;
		kiemtraktdich=0;
		if(String_RUN[chu] == 0)  //STOP
			{
				 chu=0;
			}
	}
}
unsigned int P5_StringRunGetlength(void)
{
	for(int i=0;i<String_maxLEN;i++)
	{
		if(String_RUN[i]==0)return i;
	}
	return String_maxLEN;
}
void P5_StringRun_init(void)
{
	kiemtraktdich=0;
	chu=0;
}
void String_runSetTxt(int vitri,unsigned char txt)
{
	String_RUN[vitri] = txt;
}
void String_runSetALLColor(char cR,char cG,char cB)
{
	 String_COLOR[0] = cR;
	 String_COLOR[1] = cG;
	 String_COLOR[2] = cB;
}

void P5_image(int sizex,int sizey,int x,int y,unsigned char *img) //in anh ra man hinh
{
	for(int Start_x=x;Start_x<sizex+x;Start_x++)
	{
			for(int Start_y=y;Start_y<sizey+y;Start_y++)
			{
				  unsigned char _R,_G,_B;
					uint16_t _s1 = sizex*sizey;
					uint16_t _s2 = Start_y*sizex;
					_R = img[(_s1*0) + Start_x + (_s2)];
					_G = img[(_s1*1) + Start_x + (_s2)];
					_B = img[(_s1*2) + Start_x + (_s2)];
				 set_px(Start_x,Start_y,_R,_G,_B);   
			}
	}
}


void lattrang_number_font1(int x,int y,int sizex,int sizey,int vitri_y,int num,int font)
{
	for(int i=x;i<x+sizex;i++)
	{
		 for(int k=y+sizey-1;k>y;k--)
		 {
			  display[0*arrD1 + k*arrD2 + i] = display[0*arrD1 + (k-1)*arrD2 + i]; 
			  display[1*arrD1 + k*arrD2 + i] = display[1*arrD1 + (k-1)*arrD2 + i];
			  display[2*arrD1 + k*arrD2 + i] = display[2*arrD1 + (k-1)*arrD2 + i];
		 }
	}
	if(vitri_y == 9999)
	{
		 for(int i=x;i<x+sizex;i++)
		 {
        display[0*arrD1 + y*arrD2 + i] = 0; 
			  display[1*arrD1 + y*arrD2 + i] = 0;
			  display[2*arrD1 + y*arrD2 + i] = 0;
		 }
	}
	else
	{
		 for(int mau=0;mau<3;mau++)
		 for(int i=x;i<x+sizex;i++)
		 {
			  if(COLOR[1][0] < 32)display[mau*arrD1 + y*arrD2 + i] = COLOR[readbit_font1(i-x,vitri_y,num,font)][mau];
				else 
				{
					if(readbit_font1(i-x,vitri_y,num,font)!=0)display[mau*arrD1 + y*arrD2 + i] = Color_Font[255-COLOR[1][0]][mau][vitri_y][i-x];
					else display[mau*arrD1 + y*arrD2 + i] = 0;
				}
		 }
	}
}

void lattrang_number_font2(int x,int y,int sizex,int sizey,int vitri_y,int num,int font)
{
	for(int i=x;i<x+sizex;i++)
	{
		 for(int k=y+sizey-1;k>y;k--)
		 {
			  display[0*arrD1 + k*arrD2 + i] = display[0*arrD1 + (k-1)*arrD2 + i];   
			  display[1*arrD1 + k*arrD2 + i] = display[1*arrD1 + (k-1)*arrD2 + i];
			  display[2*arrD1 + k*arrD2 + i] = display[2*arrD1 + (k-1)*arrD2 + i];
		 }
	}
	if(vitri_y == 9999)
	{
		 for(int i=x;i<x+sizex;i++)
		 {
        display[0*arrD1 + y*arrD2 + i] = 0;  
			  display[1*arrD1 + y*arrD2 + i] = 0;
			  display[2*arrD1 + y*arrD2 + i] = 0;
		 }
	}
	else
	{
		 for(int mau=0;mau<3;mau++)
		 for(int i=x;i<x+sizex;i++)
		 {
			  display[mau*arrD1 + y*arrD2 + i] = COLOR[readbit_font2(i-x,vitri_y,num,font)][mau];
		 }
	}
}

//----------------------------------Cac ham de tao ra dong ho kim  analog ------------------------------------//

#define swap(a, b) {int t = a; a = b; b = t; }    // chuong trinh con ( hoan doi gia tri a va b) 
#define ONE_RADIAN 0.0174533

#define CLOCK_RADIUS  15
#define SECOND_HAND_SIZE  14
#define MINUTE_HAND_SIZE  10
#define HOUR_HAND_SIZE    6
uint16_t resizeX=P5_W;
uint16_t resizeY=P5_H;
unsigned char getpx(char c,uint16_t x,uint16_t y)
{
	return display[c*arrD1 + y*arrD2 + x];
}
void set_px1(int x, int y, char cR,char cG,char cB)
{
	if(x<0 || y<0 || x>63 ||y>31)return;
	uint16_t _y1 = y*arrD2;
	display[          _y1 + x]=cR; 
	display[  arrD1 + _y1 + x]=cG;
	display[2*arrD1 + _y1 + x]=cB;
}
void set_px2(int x, int y, char cR,char cG,char cB)
{
	uint16_t x1 =  resizeX*x/P5_W; 
	uint16_t y1 =  resizeY*y/P5_H;
	if(x<0 || y<0 || x>63 ||y>31)return;
	
	uint16_t _y1 = y1*arrD2;
	display[          _y1 + x1]=cR; 
	display[  arrD1 + _y1 + x1]=cG;
	display[2*arrD1 + _y1 + x1]=cB;
}
void set_R(int x, int y, char c)
{
	if(x<0 || y<0 || x>63 ||y>31)return;
	display[0*arrD1 + y*arrD2 + x]=c; 
}
void set_G(int x, int y, char c)
{
	if(x<0 || y<0 || x>63 ||y>31)return;
	display[1*arrD1 + y*arrD2 + x]=c; 
}
void set_B(int x, int y, char c)
{
	if(x<0 || y<0 || x>63 ||y>31)return;
	display[2*arrD1 + y*arrD2 + x]=c; 
}
void P5_veduongngang(unsigned char x, unsigned char y,unsigned char dodai,char cR,char cG,char cB)   // ve 1 duong ke ngang
{
  char dem;
  if(dodai>P5_W)dodai=P5_W;
  for(dem=0;dem<dodai;dem++)
	{
		 set_px(x+dem,y,cR,cG,cB);
	}
} 

void P5_veduongdoc(unsigned char x, unsigned char y,unsigned char dodai,char cR,char cG,char cB)      // ve 1 duong ke doc
{
char dem;
  if(dodai>P5_H) dodai=P5_H;
  for(dem=0;dem<dodai;dem++)
	{
		 set_px(x,y+dem,cR,cG,cB);
	}
}
void P5_veduongthang(int x, int y,int x1, int y1,char cR,char cG,char cB)
{
 int dx,dy,err,ystep; 
 int steep=abs(y1-y) > abs(x1-x);   
 int xtd,ytd;
 if(x==x1)
 {
  ytd=y1-y;  
  ytd=abs(ytd);
  if(y1>y)P5_veduongdoc(x,y,ytd+1,cR,cG,cB);    
  else P5_veduongdoc(x1,y1,ytd+1,cR,cG,cB);  
  return;
 } 
 
 if(y==y1)
 {    
  xtd=x1-x;
  xtd=abs(xtd);
  if(x1>x)P5_veduongngang(x,y,xtd+1,cR,cG,cB);    
  else P5_veduongngang(x1,y1,xtd+1,cR,cG,cB);
  return;
 }
 if (steep) 
  {
    swap(x, y);
    swap(x1, y1);
  }    
  
  if (x > x1) 
  {
    swap(x, x1);
    swap(y, y1);
  }
 dx=x1-x;
 dy=abs(y1-y);
 err=dx/2;  
  
  if (y < y1)ystep = 1;    
  else ystep = -1;
    
  for (; x<=x1; x++) 
  {
    if (steep)
		{
			   set_px(x,y,cR,cG,cB);
		}
    else 
		{
				 set_px(y,x,cR,cG,cB);
    }
		
    err -= dy;      
    if (err < 0) 
    {
      y += ystep;
      err += dx;
    }
  }
}

void P5_vehinhchunhat(unsigned char x, unsigned char y,unsigned char rong, unsigned char cao,char cR,char cG,char cB)
{
   unsigned char x1,y1;
   x1=x+rong-1;
   y1=y+cao-1;
   P5_veduongdoc(x,y,cao,cR,cG,cB); P5_veduongdoc(x1,y,cao,cR,cG,cB);     
   P5_veduongngang(x,y,rong,cR,cG,cB); P5_veduongngang(x,y1,rong,cR,cG,cB);  
}
void P5_vehinhchunhat_kin(unsigned char x, unsigned char y,unsigned char rong, unsigned char cao,char cR,char cG,char cB)
{
   unsigned char x1;
   x1=x+rong;        
   for(;x<x1;x++)P5_veduongdoc(x,y,cao,cR,cG,cB);
}
void P5_vehinhchunhat_Vien(unsigned char x, unsigned char y,unsigned char rong, unsigned char cao,char cR,char cG,char cB)
{
	P5_vehinhchunhat(x,y,rong,cao,31,31,31);
	P5_vehinhchunhat_kin(x+1,y+1,rong-2,cao-2,cR,cG,cB);
}

#define CLOCK_X_Center 15
#define CLOCK_Y_Center 15
void Clock_Analog_BackGround(void)
{
	P5_image(32,32,0,0,(unsigned char *)clock_khung);
}
void Clock_Analog(int gio,int phut,int giay,unsigned char *c)
{
	//ve kim giay
	float angle = ONE_RADIAN*giay*6;
	float x =  CLOCK_X_Center + sin(angle)*SECOND_HAND_SIZE;
  float y =  CLOCK_Y_Center - cos(angle)*SECOND_HAND_SIZE;
	P5_veduongthang(CLOCK_X_Center,CLOCK_Y_Center,x+0.5,y+0.5,c[6],c[7],c[8]);
	
	// ve kim phut
	angle = ONE_RADIAN*phut*6;
	x = CLOCK_X_Center + sin(angle)*MINUTE_HAND_SIZE;
	y = CLOCK_Y_Center - cos(angle)*MINUTE_HAND_SIZE;
  P5_veduongthang(CLOCK_X_Center,CLOCK_Y_Center,x+0.5,y+0.5,c[3],c[4],c[5]);
	
	// ve kim gio
	angle = ONE_RADIAN * (gio+phut/60)*30;
	x = CLOCK_X_Center + sin(angle)*HOUR_HAND_SIZE;
	y = CLOCK_Y_Center - cos(angle)*HOUR_HAND_SIZE;
  P5_veduongthang(CLOCK_X_Center,CLOCK_Y_Center,x+0.5,y+0.5,c[0],c[1],c[2]);
}
//-------------1 vai ham tao hieu ung co ban----------------------//


void P5_ve_hinh_tron(int x0,int y0,int r,char cR,char cG,char cB) 
 {
  int ddF_x,f,x0x,x0y ,x0_x,x0_y,y0x,y0y,y0_x,y0_y,ddF_y,x,y;
 
  if(r<1){return;}//tho�t

  f = 1 - r;
  ddF_x = 1;
  ddF_y = -2 * r;
  x = 0;
  y = r;

  set_px(x0, y0+r, cR,cG,cB);
  set_px(x0, y0-r, cR,cG,cB);
  set_px(x0+r, y0, cR,cG,cB);
  set_px(x0-r, y0, cR,cG,cB);

  while (x<y) 
   {
    if (f >= 0) 
    {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;      

    ddF_x += 2;
    f += ddF_x;
    x0x=x0+x;x0y=x0+y; x0_x=x0-x; x0_y=x0-y;
    y0x=y0+x; y0y=y0+y; y0_x=y0-x; y0_y=y0-y;
    set_px(x0x, y0_y, cR,cG,cB);
    set_px(x0y, y0_x, cR,cG,cB);
    set_px(x0_x, y0_y, cR,cG,cB);
    set_px(x0_y, y0_x, cR,cG,cB);
    set_px(x0_y, y0x, cR,cG,cB);
    set_px(x0_x, y0y, cR,cG,cB);
    set_px(x0y, y0x, cR,cG,cB); 
    set_px(x0x, y0y, cR,cG,cB);   
  }
}
 
void P5_ve_hinh_tron_kin(int x0,int y0,int r, char cR,char cG,char cB) 
{
  int i,f,y0x,y0y,ddF_x,ddF_y,x,y;
  if(r<1){return;}//tho�t
  f = 1 - r;
  ddF_x = 1;
  ddF_y = -2 * r;
  x = 0;
  y = r;

  for (i=y0-r; i<=y0+r; i++)set_px(x0, i, cR,cG,cB);
  
  while (x<y) 
   {
    if (f >= 0)
    {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;
   y0y=y0+y;
   y0x=y0+x;
    for (i=y0-y; i<=y0y; i++) 
    {
      set_px(x0+x, i, cR,cG,cB);
      set_px(x0-x, i, cR,cG,cB);    
    } 
    for (i=y0-x; i<=y0x; i++) 
    {
      set_px(x0+y, i, cR,cG,cB);
      set_px(x0-y, i, cR,cG,cB);
    }    
  }
}
 
int Random(int n)
{
   return rand() %(n+1);
}
void P5_outtro(char effect) //xoa man hinh voi hieu ung tuy chon
{
	char cR= Random(15);
	char cG= 0;
	char cB= 0;
	if(effect==0)
	{
		for(int i=0;i<36;i++)
		  {
				P5_ve_hinh_tron_kin(32,16,i,cR,cG,cB);
				HAL_Delay(30);
			}
		for(int i=0;i<36;i++)
		  {
				P5_ve_hinh_tron_kin(32,16,i,0,0,0);
				HAL_Delay(30);
			}
	}
	else
	{
		//dich man hinh sang trai
		for(int x=0;x<64;x++)
		{
			for(int i=0;i<63;i++)
			{
				for(int y=0;y<32;y++)
				 {
					 display[0*arrD1 + y*arrD2 + i]=display[0*arrD1 + y*arrD2 + i+1];   
					 display[1*arrD1 + y*arrD2 + i]=display[1*arrD1 + y*arrD2 + i+1];
					 display[2*arrD1 + y*arrD2 + i]=display[2*arrD1 + y*arrD2 + i+1];
				 }
			}
			for(int y=0;y<32;y++)
				 {
					 display[0*arrD1 + y*arrD2 + 63]=0;   
					 display[1*arrD1 + y*arrD2 + 63]=0;
					 display[2*arrD1 + y*arrD2 + 63]=0;
				 }
		  HAL_Delay(12);
		}
	}
}
void P5_clear(void)
{
	uint32_t *c = (uint32_t *)display;
	for(int i=0;i<1536;i++)c[i]=0x00000000;
//  {
//		for(int y=0;y<32;y++)
//		 {
//			 display[0*arrD1 + y*arrD2 + i]=0; 
//			 display[1*arrD1 + y*arrD2 + i]=0;
//			 display[2*arrD1 + y*arrD2 + i]=0;
//		 }
//	}
}
//void P5_clear_buff1()
//{
//	uint32_t *c = (uint32_t *)&display1[0][0][0];
//	for(int i=0;i<1536;i++)c[i]=0x00000000;
//}
//void P5_clear_buff2()
//{
//	uint32_t *c = (uint32_t *)&display2[0][0][0];
//	for(int i=0;i<1536;i++)c[i]=0x00000000;
//}
void P5_clearTOP(void)
{
	for(int i=0;i<64;i++)
  {
		for(int y=0;y<16;y++)
		 {
			 display[0*arrD1 + y*arrD2 + i]=0;
			 display[1*arrD1 + y*arrD2 + i]=0;
			 display[2*arrD1 + y*arrD2 + i]=0;
		 }
	}
}
void P5_clearBOT(void)
{
	for(int i=0;i<64;i++)
  {
		for(int y=16;y<32;y++)
		 {
			 display[0*arrD1 + y*arrD2 + i]=0;
			 display[1*arrD1 + y*arrD2 + i]=0;
			 display[2*arrD1 + y*arrD2 + i]=0;
		 }
	}
}
void P5_special(char i)
{
	if(i==0)for(int i=19;i<29;i++)for(int y=25;y<35;y++)set_px(y,i,img_B[0][i-19][y-25],img_B[1][i-19][y-25],img_B[2][i-19][y-25]);
	else P5_vehinhchunhat(25,19,10,10,0,0,0);
}
//void P5_copy_Buff(int buf)
//{
//	uint32_t *c1;
//	uint32_t *c2;
//	if(buf==0)
//	{
//		c1 = (uint32_t *)&display1[0][0][0];
//		c2 = (uint32_t *)&display2[0][0][0];
//	}
//	else
//	{
//		c2 = (uint32_t *)&display1[0][0][0];
//		c1 = (uint32_t *)&display2[0][0][0];
//	}
//	for(int i=0;i<1536;i++)c1[i] = c2[i];
//}

//typedef struct
//{
//	int in;
//	int dec;
//}available_withOutFloat;
//inline void div_withOut_float(int s1,int s2,available_withOutFloat * f_loat) //phep chia thap phan
//{
//	f_loat->in = s1*1000/s2/1000;
//	f_loat->dec = s1*1000/s2%1000;
//}
//inline void mul_withOut_float(int s1,int s2,available_withOutFloat * f_loat) //phep nhan thap phan
//{
//	f_loat->in = s1*10/s2/10;
//	f_loat->dec = s1*10/s2%10;
//}
//void P5_zoom_out(void)
//{
//	int sizeW=64;
//	int sizeH=32;
//	int n,m;
//	float fx; 
//	float fy;
//	for(int dem=0;dem<30;dem++)
//	{
//		P5_clear_buff2();
//		HAL_Delay(10);
//		sizeW--;sizeH--;
//		fx = (float)64/sizeW;
//		fy = (float)32/sizeH;
//		for(int i=0;i<sizeW;i++)
//		{
//			 m = i*fx;
//			 for(int h=0;h<sizeH;h++)
//			 {
//				 n = h*fy;
//				 display2[0][h][i] = display1[0][n][m];
//				 display2[1][h][i] = display1[1][n][m];
//				 display2[2][h][i] = display1[2][n][m];
//			 }
//		 }
//		 P5_copy_Buff(0);	 
//	}
//	P5_setBuff_Accset(1);
//}
//void P5_zoom_in(void)
//{
//	int sizeW=31;
//	int sizeH=0;
//	int n,m;
//	float fx; 
//	float fy;
//	for(int dem=0;dem<31;dem++)
//	{
//		sizeW++;sizeH++;
//		fx = (float)64/sizeW;
//		fy = (float)32/sizeH;
//		for(int i=0;i<sizeW;i++)
//	  {
//			 m = i*fx;			
//			 for(int h=0;h<sizeH;h++)
//			 {			 	 
//				 n = h*fy;
//				 display1[0][h][i] = display2[0][n][m];
//				 display1[1][h][i] = display2[1][n][m];
//				 display1[2][h][i] = display2[2][n][m];
//			 } 
//		}
//	}
//	P5_copy_Buff(0);	 
//	P5_setBuff_Accset(0);
//}
//void P5_zoom_out2(void)
//{
//	int sizeW=64;
//	int sizeH=32;
//	int n,m;
//	float fx; 
//	float fy;
//	int demi=0;
//	for(int dem=0;dem<30;dem++)
//	{
//		P5_clear_buff2();
//		HAL_Delay(10);
//		sizeW--;sizeH--;demi++;
//		fx = (float)64/sizeW;
//		fy = (float)32/sizeH;
//		for(int i=0;i<sizeW;i++)
//		{
//			 m = i*fx;
//			 for(int h=0;h<sizeH;h++)
//			 {
//				 n = h*fy;
//				 display2[0][h+demi][i+demi] = display1[0][n][m];
//				 display2[1][h+demi][i+demi] = display1[1][n][m];
//				 display2[2][h+demi][i+demi] = display1[2][n][m];
//			 }
//		 }
//		 P5_copy_Buff(0);	 
//	}
//	P5_setBuff_Accset(1);
//}
//void P5_zoom_in2(void)
//{
//	int sizeW=31;
//	int sizeH=0;
//	int n,m;
//	float fx; 
//	float fy;
//	int demi=31;
//	for(int dem=0;dem<31;dem++)
//	{
//		sizeW++;sizeH++;demi--;
//		fx = (float)64/sizeW;
//		fy = (float)32/sizeH;
//		for(int i=0;i<sizeW;i++)
//	  {
//			 if((i+demi)>P5_W)break;
//			 m = i*fx;			
//			 for(int h=0;h<sizeH;h++)
//			 {			 	 
//				 if((h+demi)>P5_H)break;
//				 n = h*fy;
//				 display1[0][h+demi][i+demi] = display2[0][n][m];
//				 display1[1][h+demi][i+demi] = display2[1][n][m];
//				 display1[2][h+demi][i+demi] = display2[2][n][m];
//			 } 
//		}
//	}
//	P5_copy_Buff(0);	 
//	P5_setBuff_Accset(0);
//}
//end P5 Lib

