#ifndef __FONT__H__
#define __FONT__H__

#define MAX_FONT 5

#define PAGEFONT   0x0801F400

#include "stdlib.h"
extern const unsigned char number_dot[4][20][2];
extern const unsigned char number_font2[MAX_FONT][14][12][2];
extern const unsigned char font11[][16][2];
extern const unsigned char number_font4[][10][1];
extern const unsigned char number_font5[][7][1];
extern const unsigned char Width_font11[];
extern const unsigned char clock_khung[];
extern const unsigned char Color_Font[][3][20][14];
extern unsigned char img_B[3][10][10];
extern unsigned char mask_text[3][16][64];
extern const unsigned char fontAs57[];
extern unsigned char QR_code[];
extern const unsigned char number_font1[MAX_FONT-1][10][20][2];
extern unsigned char number_font1_canhan[10][20][2];
#endif //__FONT__H__



