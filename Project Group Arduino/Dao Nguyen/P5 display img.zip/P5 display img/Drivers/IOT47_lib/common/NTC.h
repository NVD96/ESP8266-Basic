#ifndef __NTC_H__
#define __NTC_H__

#include "stm32f1xx_hal.h"

#define VCC_ADC 3.3
#define resolution_ADC 0.00080586081
#define Beta 3900          //tra datasheet thong so Beta
#define Rinf 0.0176322702  //Rinf=10000*exp(-Beta/298.15); //10000 = R0 ;  298.15 = 25 do C
	
void NTC_init(ADC_HandleTypeDef *hadc1,ADC_ChannelConfTypeDef *config);
int16_t NTC_getTemp(void);
#endif  //__NTC_H__

//


