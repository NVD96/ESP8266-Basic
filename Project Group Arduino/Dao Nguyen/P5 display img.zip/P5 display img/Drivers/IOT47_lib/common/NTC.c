#include "NTC.h"
#include "math.h"

ADC_HandleTypeDef *my_adc;
ADC_ChannelConfTypeDef *my_Config;

void NTC_init(ADC_HandleTypeDef *hadc,ADC_ChannelConfTypeDef *config)
{
	my_adc=hadc;
	my_Config = config;
}
uint16_t NTC_getAnalog(void)
{
	my_Config->Channel = ADC_CHANNEL_1;
	HAL_ADC_ConfigChannel(my_adc,my_Config);
	HAL_ADC_Start (my_adc);
	HAL_ADC_PollForConversion (my_adc, 10);
	
	return HAL_ADC_GetValue (my_adc);
}
int16_t NTC_getTemp(void)
{
	float vol_NTC;
  float R_NTC;
	uint16_t adc_value;
	adc_value=4095-NTC_getAnalog();
	vol_NTC=resolution_ADC*adc_value;  //tinh duoc dien ap
	R_NTC = 10000 * (3.3/vol_NTC - 1); //tinh dien tro cua NTC
	return Beta/log(R_NTC/Rinf)-273.15;// tinh nhiet do bang phuong trinh Steinhart�Hart equation
}
//
