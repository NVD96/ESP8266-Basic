#include "stm32f1xx_hal.h"

#define IR_PIN GPIO_PIN_15

#define OFF   1
#define ON 	  2
#define LEN   3
#define XUONG 4
#define TRAI  5
#define PHAI  6
#define OK    7
#define MENU  8
#define EXIT  9
#define V1    10
#define V2    11

//------------------------END-----------------------------//

void IR_Start(void);
void IR_Stop(void);
void IR_ngatT(void);
void IR_ngatPin(void);
char GET_key(void);
void SET_key(char val);

