#include <IR.h>

extern TIM_HandleTypeDef htim3; //khai bao timer su dung cho IR

unsigned char IRI;
unsigned long giatri;
char key=0;
const uint32_t Key_IR[11]= //11 phim add san
{
 0x01FE48B7,
 0x01FE58A7,
 0x01FE40BF,
 0x01FE10EF,
 0x01FE20DF,
 0x01FE609F,
 0x01FEA05F,
 0x01FED827,
 0x01FEF807,
 0x01FEB04F,
 0x01FE708F,
};
const uint32_t Key_IR2[11]= //11 phim add san
{
 0x00FFA25D, //off  //0x00FFA25D
 0x00FF629D, //on   //0x00FF629D
 0x00FF02FD, //len  //0x00FF02FD
 0x00FF9867, //xuong//0x00FF9867
 0x00FFE01F, //trai //0x00FFE01F
 0x00FF906F, //phai //0x00FF906F
 0x00FFA857, //ok   //0x00FFA857
 0x00FF18E7, //menu //0x00FF18E7
 0x00FF7A85, //exit //0x00FF7A85
 0x00FF38C7, //VOL- //0x00FF38C7
 0x00FF5AA5, //VOL+ //0x00FF5AA5
};
char GET_key(void)
{
	char k = key;
	key=0;
	return k;
}
void SET_key(char val)
{
	key=val; 
}
uint32_t GET_IR_data(void)
{
	return giatri;
}
void IR_Start(void)
{
	HAL_NVIC_EnableIRQ(EXTI3_IRQn);
}
void IR_Stop(void)
{
	HAL_NVIC_DisableIRQ(EXTI3_IRQn);
}
void IR_ngatT(void)
{
	     HAL_TIM_Base_Stop_IT(&htim3); // stop t2
			 if(IRI == 1) IRI=0;	     		
       else if(IRI == 2)
			 {
				    IR_Stop();//tam thoi cam ngat IR de xu li	
            IRI=0;           			
						HAL_TIM_Base_Stop_IT(&htim3);
						//xu li du lieu tai day      
				     for(int i=0;i<11;i++)if(giatri == Key_IR[i] || giatri == Key_IR2[i])SET_key(i+1);							
					  IR_Start();						
					}		
}
void IR_ngatPin(void)
{
	     unsigned int pulse_width; 
			 HAL_TIM_Base_Stop_IT(&htim3); // stop t2
			 pulse_width = htim3.Instance -> CNT; //lay gia tri dem duoc cua timer ra
			 htim3.Instance -> CNT = 0x63C0;//nap gia tri vao time
			 HAL_TIM_Base_Start_IT(&htim3);//cho timer chay
			 pulse_width = pulse_width - 25536;
			 switch(IRI)
				 {
						case 0: 
										IRI=1;
										break; 
						case 1: 
										if(pulse_width > 3000)
										{
												IRI=2;    
												giatri=0;
										}
										else
												IRI--;
										break;
						case 2: 
												giatri <<= 1;
												if(pulse_width > 1500)
												giatri |= 1;
												break;
	        }
}
