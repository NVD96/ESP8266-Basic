#include "eeprom.h"

uint8_t EEPROM_buffer[100];
uint16_t eeprom_size=100;

void EEPROM_init(uint16_t size)
{
	if(size % 2 == 1)size+=1;
	eeprom_size = size;
	for(uint16_t i=0;i<eeprom_size;i++)
		EEPROM_buffer[i] = Flash_read(i);
}
void EEPROM_restart(void)
{
	for(uint16_t i=0;i<eeprom_size;i++)
		EEPROM_buffer[i] = Flash_read(i);
}
void Flash_Lock()
{
	HAL_FLASH_Lock();
}

void Flash_Unlock()
{
	HAL_FLASH_Unlock();
}

void Flash_Erase(uint32_t addr)
{
Flash_Unlock();
  while((FLASH->SR&FLASH_SR_BSY));
  FLASH->CR |= FLASH_CR_PER; //Page Erase Set
  FLASH->AR = addr; //Page Address
  FLASH->CR |= FLASH_CR_STRT; //Start Page Erase
  while((FLASH->SR&FLASH_SR_BSY));
	FLASH->CR &= ~FLASH_SR_BSY;
  FLASH->CR &= ~FLASH_CR_PER; //Page Erase Clear
Flash_Lock();
}
void EEP_write(uint16_t add, uint8_t data)
{
	EEPROM_buffer[add]=data;
}

uint8_t EEP_read(uint16_t add)
{
	return EEPROM_buffer[add];
}

uint8_t Flash_read(uint8_t add)
{
	int32_t addr;
	addr = DATA_START_ADDRESS + add;
	uint8_t *val = (uint8_t *)addr;
	return *val;
}
void EEP_commit(void)
{
	uint32_t addr;
	uint16_t data;
	Flash_Erase(DATA_START_ADDRESS);
	Flash_Unlock();
	for(int i=0;i<SIZE_EEP/2;i++)
	{
		addr = DATA_START_ADDRESS + (i*2);
		FLASH->CR |= FLASH_CR_PG;				/*!< Programming */
		while((FLASH->SR&FLASH_SR_BSY));
		data=((uint16_t)EEPROM_buffer[i*2+1]<<8) | ((uint16_t)EEPROM_buffer[i*2]);
		*(__IO uint16_t*)addr = data;
		while((FLASH->SR&FLASH_SR_BSY));
		FLASH->CR &= ~FLASH_CR_PG;
	}
	Flash_Lock();
}
