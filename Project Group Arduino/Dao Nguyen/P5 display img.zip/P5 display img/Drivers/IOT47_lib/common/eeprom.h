#ifndef __FLASH__H
#define __FLASH__H

#include "stm32f1xx_hal.h"

#define DATA_START_ADDRESS 		 	((uint32_t)0x0801FC00)	//Page 127
#define SIZE_EEP 1024

void 	Flash_Lock(void);
void 	Flash_Unlock(void);
void 	Flash_Erase(uint32_t addr);
void EEPROM_init(uint16_t size);
void EEPROM_restart(void);
void EEP_write(uint16_t add, uint8_t data);
uint8_t Flash_read(uint8_t add);
uint8_t EEP_read(uint16_t add);
void EEP_commit(void);
#endif

