/*
Chuong trinh quet LED matrix P10 RGB 16x64px, hien thi thoi gian, chay chu
-> 8bit R + 8bit G + 8bit B = 24bit RGB = 16777215 color
-> Clock mcu 72Mhz
-> LED scanning algorithm: Binary Code Modulation, Refer: http://www.batsocks.co.uk/readme/art_bcm_3.htm

Write by Dao Nguyen
Facebook: https://www.facebook.com/nguyendao207
Mail: daonguyen20798@gmail.com
SDT: 0394733311

->Tai nguyen da su dung(Resources used ) :
    + ADC1
		+ TIM2(timer) + TIM3(quet led) + TIM4(PWM OE)
		+ Soft I2C
*/


#include "main.h"
#include "stm32f1xx_hal.h"
#include "font.h"


#define xuat      13 //B
#define OE        11 //B
#define clk       1  //A

#define A         0  //B
#define B         1  //B
#define C         10 //B

#define B2        7
#define R2        6
#define G2        2

#define B1        5
#define R1        4
#define G1        3

#define OE_P       GPIOB
#define xuat_P     GPIOB
#define clk_P      GPIOA
#define A_P        GPIOB
#define B_P        GPIOB
#define C_P        GPIOB

#define OK GPIO_PIN_4
#define UP GPIO_PIN_5


#define TRUE   1
#define DELETE 0

ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;


void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM4_Init(void);
                                    
void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

unsigned int timer_clock[8]={9,18,36,72,144,288,575,1152}; // so xung nap vao timer
unsigned char vitri_bit=0,row=0; // kiem tra xem dang quet den bit nao
unsigned char hang_led,p10_x,p10_y;
unsigned char display[3][16][64];
unsigned char mode=255;
char hieuung=0;
char nhietdo;
unsigned char mode_ef_giay_to[2]={22,38};
unsigned char mode_ef_giay_be[4]={49,14,23,37};

char time[7],giaycu,ngay_al,thang_al,check_TIM4;

int mucsang_CAIDAT;

#define mucsang_CAIDAT_macdinh 500
#define ADD_FLASH_mucsang_CAIDAT 0x0801FF00 //dia chi luu gia tri cai dat


//Quet 1/8
void hang(char so)
{
	switch(so)
	{
    case 0:C_P->BSRR=(1<<(C+16));B_P->BSRR=(1<<(B+16));A_P->BSRR=(1<<(A+16));break;
		case 1:C_P->BSRR=(1<<(C+16));B_P->BSRR=(1<<(B+16));A_P->BSRR=(1<<A);break;
		case 2:C_P->BSRR=(1<<(C+16));B_P->BSRR=(1<<B);A_P->BSRR=(1<<(A+16));break;
		case 3:C_P->BSRR=(1<<(C+16));B_P->BSRR=(1<<B);A_P->BSRR=(1<<A);break;
		case 4:C_P->BSRR=(1<<C);B_P->BSRR=(1<<(B+16));A_P->BSRR=(1<<(A+16));break;
		case 5:C_P->BSRR=(1<<C);B_P->BSRR=(1<<(B+16));A_P->BSRR=(1<<A);break;
		case 6:C_P->BSRR=(1<<C);B_P->BSRR=(1<<B);A_P->BSRR=(1<<(A+16));break;
		case 7:C_P->BSRR=(1<<C);B_P->BSRR=(1<<B);A_P->BSRR=(1<<A);break;
	}
}

//hien thi du lieu tu Ram ra man hinh LED
unsigned char led[8][8][64];
void P10_display()
{
 for(int hang=0;hang<8;hang++)
 {
	for(int ts=0;ts<8;ts++)
	{
	 for(int i=0;i<64;i++)
	 {
		 led[hang][ts][i]=0;
		 if((display[1][8+hang][i] & (1<<ts)) != 0 ){led[hang][ts][i]|=0x04;} //ghi bit 2 G2 
		 if((display[1][0+hang][i] & (1<<ts)) != 0 ){led[hang][ts][i]|=0x08;} //ghi bit 3 G1
		 if((display[0][0+hang][i] & (1<<ts)) != 0 ){led[hang][ts][i]|=0x10;} //ghi bit 4 R1
		 if((display[2][0+hang][i] & (1<<ts)) != 0 ){led[hang][ts][i]|=0x20;} //ghi bit 5 B1
		 if((display[0][8+hang][i] & (1<<ts)) != 0 ){led[hang][ts][i]|=0x40;} //ghi bit 6 R2
		 if((display[2][8+hang][i] & (1<<ts)) != 0 ){led[hang][ts][i]|=0x80;} //ghi bit 7 B2
	 }
	}
 }
}

//chon vi tri can in so hoac text ra
void P10_chonvitri(char y,char x)
{
	 p10_x=x;
	 p10_y=y;
}


/*
//ve 1 hinh vuong
y: toa do truc  0<y<16
x: toa do truc  0<x<63
w: do dai       1<w<64
h: chieu cao    1<h<16
rgb: ma mau rgb 0<r<255  0<g<255  0<b<255
*/
void DRAW_FillRec(char y,char x,char w,char h,unsigned char r,unsigned char g,unsigned char b)
{
	 int _y,_x;
	 w+=x;
	 h+=y;
	 for(_y=y;_y<h;_y++)
		 for(_x=x;_x<w;_x++)
			  display[0][_y][_x]=r;
	 for(_y=y;_y<h;_y++)
		 for(_x=x;_x<w;_x++)
			  display[1][_y][_x]=g;
	 for(_y=y;_y<h;_y++)
		 for(_x=x;_x<w;_x++)
			  display[2][_y][_x]=b;
}


// hien thi so to
void P10_sendnumBIG(char num)
{
		for(int mau=0;mau<3;mau++)
			 for(int y=0;y<15;y++)
	       {
					 if(y+p10_y>15)break;
					 for(int x=0;x<10;x++)
							{
								if(x+p10_x>63)break;
							  display[mau][y+p10_y][x+p10_x]=number_fx[hieuung][num][mau][y][x];				   
					    }
				 }
		p10_x+=11;
}
void P10_sendnumSmall(char num)
{
		for(int mau=0;mau<3;mau++)
			 for(int y=0;y<8;y++)
					 for(int x=0;x<5;x++)
							 display[mau][y+p10_y][x+p10_x]=number_nho_fx[hieuung][num][mau][y][x];
		p10_x+=6;
}

// hien thi dau cham to
void P10_sendRec()
{
		for(int mau=0;mau<3;mau++)
			 for(int y=0;y<4;y++)
					 for(int x=0;x<4;x++)
							 display[mau][y+p10_y][x+p10_x]=recfill_fx[hieuung][mau][y][x];
}
/*
 =  T
 >  .
 ?  /
 @  L
 A  A
 B  C
 C  do
 D  cach
 E  -
*/
unsigned char chuchay[40]={"=>2D30E06E2018DA@:31?12D21CBDDDDDDDDDDDD"}; // vl hahaha
unsigned char dichtrai,chu,ktdich=6;
//chay chu Thu x ngay xx /xx/20xx AL:xx/xx 31oC
void chaychu()
{
	for(char mau=0;mau<3;mau++)
	  for(char y=9;y<16;y++)
	    for(char x=0;x<63;x++)
	        display[mau][y][x] = display[mau][y][x+1]; //dich trai toan bo cac cot sang 1 ben
	
	//dua du lieu moi vao
	for(char mau=0;mau<3;mau++)
	{
	  for(char y=9;y<16;y++)
		 {
			 if( (font5x7[chuchay[chu]-48][y-9] & (0x80>>dichtrai)) == 0)display[mau][y][63] = 0;
			 else 
				 {
					 display[mau][y][63] = color_chuchay[mau][chu];
				 }
		 }
	}
	dichtrai++;
	if(dichtrai==ktdich)
	{
		ktdich=6;
		dichtrai=0;
		chu++;    
		if(chuchay[chu]=='>' || chuchay[chu]==':' || chuchay[chu]=='D')ktdich=3; 
		if(chuchay[chu]=='E')ktdich=3;
		if(chuchay[chu]=='@')ktdich=4;
		if(chuchay[chu]==0)mode = 255;
	}		
}
/*
Note: Co the chay FUll tat ca chu tieng Viet theo y thich. Cac ki tu tieng Viet go \xYY (trong do YY la ma hex cua font tieng viet do - mo muc font.h keo xuong duoi cung de xem)
*/
const unsigned char chuchayCMNM[]={"Ch\xD6\x63 M\xDDng N\xA8m M\xD1i-An Khang Th\xC4nh V\xDB\xD5ng-V\xA7n S\xE0 Nh\xDB \x9E !!!                "}; // -> Chuc Mung Nam Moi - An Khang Thinh Vuong - Van Su Nhu Y !!! ( Tieng Viet co dau)
char demb=0,kiemtraktdich;
void kiemtra_chieudai_text()
{
  ktdich=8;     
       if(chuchayCMNM[chu]=='i' || chuchayCMNM[chu]=='+' || chuchayCMNM[chu]==' ')ktdich=3;
  else if((chuchayCMNM[chu]>=183 && chuchayCMNM[chu]<=187))ktdich=3;    
  else if(chuchayCMNM[chu]=='j')ktdich=5;
  else if(chuchayCMNM[chu]=='f' || chuchayCMNM[chu]=='s')ktdich=6;   
	else if(chuchayCMNM[chu]>=192 && chuchayCMNM[chu]<=196)ktdich=5;  
  else if(chuchayCMNM[chu]=='e' || chuchayCMNM[chu]=='c'||chuchayCMNM[chu]=='l')ktdich=7;
  else if(chuchayCMNM[chu]=='z'||chuchayCMNM[chu]=='I'||chuchayCMNM[chu]=='1' ||chuchayCMNM[chu]=='r'||chuchayCMNM[chu]=='t' )ktdich=7;   
  else if(chuchayCMNM[chu]=='a' || (chuchayCMNM[chu]>=154 && chuchayCMNM[chu]<=170))ktdich=8;
  else if((chuchayCMNM[chu]>=123 && chuchayCMNM[chu]<=125) ||chuchayCMNM[chu]==30 || chuchayCMNM[chu]==31)ktdich=7;   
  else if(chuchayCMNM[chu]=='p' || chuchayCMNM[chu]=='b' || chuchayCMNM[chu]=='o' || chuchayCMNM[chu]=='q' || chuchayCMNM[chu]=='S' || chuchayCMNM[chu]=='7')ktdich=8;
  else if((chuchayCMNM[chu]>=188 && chuchayCMNM[chu]<=198))ktdich=8;  
  else if(chuchayCMNM[chu]=='d' || chuchayCMNM[chu]=='g' || chuchayCMNM[chu]=='h' || chuchayCMNM[chu]=='u' || chuchayCMNM[chu]=='v' || chuchayCMNM[chu]=='x' || chuchayCMNM[chu]=='y' || chuchayCMNM[chu]=='z'|| chuchayCMNM[chu]=='0' || chuchayCMNM[chu]=='8'|| chuchayCMNM[chu]=='9')ktdich=9;   
	else if((chuchayCMNM[chu]>=205 && chuchayCMNM[chu]<=215))ktdich=9;  
  else if((chuchayCMNM[chu]>=221 && chuchayCMNM[chu]<=225))ktdich=9; 
  else if((chuchayCMNM[chu]>=199 && chuchayCMNM[chu]<=204))ktdich=9;
  else if((chuchayCMNM[chu]>='2' && chuchayCMNM[chu]<='6') || chuchayCMNM[chu]==171)ktdich=9;  
  else if(chuchayCMNM[chu]=='k' || chuchayCMNM[chu]=='n' || chuchayCMNM[chu]=='E' || chuchayCMNM[chu]=='F'|| chuchayCMNM[chu]=='J'|| chuchayCMNM[chu]=='L'|| chuchayCMNM[chu]=='P')ktdich=10;  
  else if((chuchayCMNM[chu]>=19 && chuchayCMNM[chu]<=29))ktdich=10;
  else if(chuchayCMNM[chu]=='B' || chuchayCMNM[chu]=='C' || chuchayCMNM[chu]=='D' || chuchayCMNM[chu]=='T'|| chuchayCMNM[chu]=='U' || chuchayCMNM[chu]==18)ktdich=11;   
  else if((chuchayCMNM[chu]>=143 && chuchayCMNM[chu]<=153))ktdich=11;
  else if(chuchayCMNM[chu]=='A' || chuchayCMNM[chu]=='G' || chuchayCMNM[chu]=='H' || chuchayCMNM[chu]=='K'|| chuchayCMNM[chu]=='O'|| chuchayCMNM[chu]=='Q'|| chuchayCMNM[chu]=='R'|| chuchayCMNM[chu]=='Z'|| chuchayCMNM[chu]=='Y'|| chuchayCMNM[chu]=='X')ktdich=12;
  else if((chuchayCMNM[chu]>=1 && chuchayCMNM[chu]<=17))ktdich=12;  
  else if((chuchayCMNM[chu]>=126 && chuchayCMNM[chu]<=142))ktdich=12;
  else if((chuchayCMNM[chu]>=216 && chuchayCMNM[chu]<=220)|| chuchayCMNM[chu]=='N')ktdich=12;
  else if(chuchayCMNM[chu]=='V')ktdich=13;
  else if(chuchayCMNM[chu]=='M' || chuchayCMNM[chu]=='m')ktdich=15;
  else if(chuchayCMNM[chu]=='W')ktdich=16;   
}
char chaychuCMNM()
{
	char b;
	for(char mau=0;mau<3;mau++)
	  for(char y=0;y<16;y++)
	    for(char x=0;x<63;x++)
	        display[mau][y][x] = display[mau][y][x+1]; //dich trai toan bo cac cot sang 1 ben
	
	 //dua du lieu moi vao
		b=demb;
	  for(char y=0;y<16;y++)
		 {
			 display[0][y][63] = 0;
			 display[1][y][63] = 0;
			 display[2][y][63] = 0;
			 if( (font11[chuchayCMNM[chu]][b] & (0x80>>dichtrai)) == 0)display[0][y][63] = 0;
			 else display[0][y][63] = display[0][y][63] = 255;
			 b=b+2; 
		 }
			  for(char y=0;y<16;y++)
			  {
					for(char x=0;x<64;x++)
					{
						if(display[0][y][x]!=0 || display[1][y][x]!=0 || display[2][y][x]!=0)
							 {
								  display[0][y][x] = rd_map_chaychu[0][y][x];
								  display[1][y][x] = rd_map_chaychu[1][y][x];
								  display[2][y][x] = rd_map_chaychu[2][y][x];
							 }
						else
							 {
								  display[0][y][x] = 0;
								  display[1][y][x] = 0;
								  display[2][y][x] = 0;
							 }
							
					}
				}
	    dichtrai++;if(dichtrai==8){dichtrai=0;demb=1;}   
      kiemtraktdich++;
      if(kiemtraktdich==ktdich)
      {
       kiemtraktdich=0;demb=0;dichtrai=0;
       chu++;    
       kiemtra_chieudai_text();
       if(chuchayCMNM[chu]=='\0')return 0; //end
      }  
      return 1;			
}
void latsonho(char num,signed char y0,char x0,char offset)  //lat xuong so nho
{
	char chuc,dv,check=0,dai;
	dv = num%10;
	chuc = num/10;
	if(dv != 0)
     {
		    x0=x0+6;
			  dai = x0+5;
		 }
	else 
	   {
			 check=1;
			 dai = x0 + 11;
		 }
	for(char down=0;down<offset;down++)
	{
	 for(char color=0;color<3;color++)
		{
		 for(signed char y=y0+7;y>y0-1;y--)
		  {
		   for(char x=x0;x<dai;x++) //51 //57
		     {
					 if (y==0) display[color][y][x]=0x00;
					 else display[color][y][x]=display[color][y-1][x];
				 }
			}
		}
	 HAL_Delay(20);
	 P10_display();
	}  // lat xuong so dang hien thi 4 dong
	for(signed char down=7;down>=0;down--)
	{
	 for(char color=0;color<3;color++)
		 for(char y=y0+7;y>y0;y--)
		   for(char x=x0;x<dai;x++) 
		     display[color][y][x]=display[color][y-1][x];
	 if(check)
		 for(char color=0;color<3;color++)
			 {
				for(char x=x0;x<x0+5;x++) 
				 display[color][y0][x]= number_nho_fx[hieuung][chuc][color][down][x-x0];
				for(char x=x0+6;x<dai;x++) 
				 display[color][y0][x]= number_nho_fx[hieuung][dv][color][down][x-(x0+6)];
			 }
	 else 
		  for(char color=0;color<3;color++)
		   {
				 for(char x=x0;x<dai;x++) 
				 display[color][y0][x]= number_nho_fx[hieuung][dv][color][down][x-x0];
		   }
	 HAL_Delay(20);
	 P10_display();
	}  // lat so tiep theo xuong
}
void latsoto(char num,char y0,char x0,char offset)  //lat xuong so nho
{
	char chuc,dv,check=0,dai;
	dv = num%10;
	chuc = num/10;
	if(dv != 0)
     {
		    x0=x0+11;
			  dai = x0+10;
		 }
	else 
	   {
			 check=1;
			 dai = x0 + 21;
		 }
	for(char down=0;down<offset;down++)
	{
	 for(char color=0;color<3;color++)
		 for(char y=y0+14;y>y0-1;y--)
		   for(char x=x0;x<dai;x++) 
		     display[color][y][x]=display[color][y-1][x];
	 HAL_Delay(10);
	 P10_display();
	}  // lat xuong so dang hien thi 4 dong
	for(signed char down=14;down>=0;down--)
	{
	 for(char color=0;color<3;color++)
		 for(char y=y0+14;y>y0;y--)
		   for(char x=x0;x<dai;x++) 
		     display[color][y][x]=display[color][y-1][x];
	 if(check)
		 for(char color=0;color<3;color++)
			 {
				for(char x=x0;x<x0+10;x++) 
				 display[color][y0][x]= number_fx[hieuung][chuc][color][down][x-x0];
				for(char x=x0+11;x<dai;x++) 
				 display[color][y0][x]= number_fx[hieuung][dv][color][down][x-(x0+11)];
			 }
	 else 
		  for(char color=0;color<3;color++)
		   {
				 for(char x=x0;x<dai;x++) 
				 display[color][y0][x]= number_fx[hieuung][dv][color][down][x-x0];
		   }
	 HAL_Delay(10);
	 P10_display();
	}  // lat so tiep theo xuong
}
void insoto(char y,char x,char so)
{
	P10_chonvitri(y,x);
	P10_sendnumBIG(so/10);
	P10_sendnumBIG(so%10);
}


//-------------SOFT I2C----------------------------------------------------------------------//
#define SDA GPIO_PIN_7
#define SCL GPIO_PIN_6
void SDA_in()
{
	GPIO_InitTypeDef GPIO_InitStruct;	
	/*Configure GPIO pin : PB7 */ //in
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
#define __I2C_DELAY 40
void I2C_Delay(unsigned int time)
{
	while(time)
	time--;
}
void SDA_out()
{
	
	GPIO_InitTypeDef GPIO_InitStruct;
	/*Configure GPIO pin : PB7 */ //out
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
void I2C_Start(void)
{
  SDA_out();
	HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_SET);	// dua SCL va SDA len muc 1
	I2C_Delay(__I2C_DELAY);
	HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_RESET);	// keo SDA xuong 0
	I2C_Delay(__I2C_DELAY);    // delay 1 khoang thoi gian ngan
	HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_RESET);	// keo SCL xuong 0  ( qua trinh Start ket thuc)
	I2C_Delay(__I2C_DELAY);
}
void I2C_STOP()
{
  SDA_out();
  HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_RESET); // cho SDA xuong 0 de chuan bi dua len 1
  HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_SET); // dua SCL len muc 1 
  I2C_Delay(__I2C_DELAY);
	HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_SET); // SDA duoc dua len muc 1. Qua trinh Stop hoan tat
  I2C_Delay(__I2C_DELAY);
  HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_RESET);
	I2C_Delay(__I2C_DELAY);
}
unsigned char I2C_CheckAck(void)
{
	  unsigned char ack=0;
	  SDA_in();
	  //SDA_out();
  	//HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_SET);
  	HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_SET);
  	I2C_Delay(__I2C_DELAY/2);
  	ack=HAL_GPIO_ReadPin(GPIOB,SDA);
  	I2C_Delay(__I2C_DELAY/2);
  	HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_RESET);
  	I2C_Delay(__I2C_DELAY/2);
  	if(ack==1) return 0; 
  	return 1;
}
void I2C_Write(unsigned char Data)
{
unsigned char i;
	  SDA_out();
  	for(i=0;i<8;i++)
    {
   	 if(((Data<<i)&0x80) == 0 ) HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_RESET);
		 else HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_SET);
		 HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_SET);
		 I2C_Delay(__I2C_DELAY);
		 HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_RESET);
		 I2C_Delay(__I2C_DELAY);
	  }
}
unsigned char I2C_Read(void)
{
  	unsigned char I2C_data=0,i,temp;
	  SDA_in();
  	for(i=0;i<8;i++)
    {
			  //SDA_out();
    	  //HAL_GPIO_WritePin(GPIOB,SDA,GPIO_PIN_SET); 
      	HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_SET);			  
      	I2C_Delay(__I2C_DELAY);
      	temp=HAL_GPIO_ReadPin(GPIOB,SDA);
      	I2C_Delay(__I2C_DELAY);
      	HAL_GPIO_WritePin(GPIOB,SCL,GPIO_PIN_RESET);
      	I2C_data=I2C_data<<1;
			 if(temp==1)I2C_data=I2C_data|0x01;
    }
    return I2C_data;
}
char AckTemp;
void ghids(unsigned char add, unsigned char dat)
{
	I2C_Start(); // bat dau ghi	
	I2C_Write(0xd0); //0xd0 la dia chi cua ds1307
	AckTemp=I2C_CheckAck();
	I2C_Write(add);	// gia tri can ghi
	AckTemp=I2C_CheckAck();
	I2C_Write(dat); 	 
	AckTemp=I2C_CheckAck();
	I2C_STOP();	 // ket thuc qua trinh truyen du lieu
	HAL_Delay(1);
}
unsigned char docds(unsigned char add)
{
	unsigned char dat;	
	I2C_Start();   // bat dau doc	
	I2C_Write(0xd0); 	// dau tien gui lenh ghi du lieu(ghi dia chi can lay du lieu trong DS1307)
	AckTemp=I2C_CheckAck();
	I2C_Write(add); // Dia chi ma ta muon doc ( vi du, muon doc giay thi ta ghi dia chi 0x00)
	AckTemp=I2C_CheckAck();
	I2C_Start(); 	 // bat dau doc du lieu
	I2C_Write(0xd1);  	// gui ma lenh doc du lieu tu dia chi(add)
	AckTemp=I2C_CheckAck();
	dat = I2C_Read();	  // doc xong thi luu gia tri da doc dc vao dat
	AckTemp=I2C_CheckAck(); 
	I2C_STOP();			// ket thuc qua trinh doc du lieu		
	return (dat);  // tra ve gia tri da doc duoc
}
unsigned char BCD_Decoder(unsigned char temp)
{
	return (temp & 0x0f) + (temp>>4)*10;
}
unsigned char BCD_Encoder(unsigned char temp)
{
	return ((temp/10)<<4)|(temp%10);
}
void laythoigian()
{
	for(char x=0;x<7;x++)time[x] = BCD_Decoder(docds(x));
	nhietdo = docds(0x11);
}

struct MONTH_INFO{
	unsigned int N_AL_DT_DL		:5;
	unsigned int T_AL_DT_DL		:4;
	unsigned int SN_CT_AL		:1;
	unsigned int TN_B_THT		:1;
	unsigned int SN_CT_DL		:2;
};

union LUNAR_RECORD
{
 	unsigned int Word; 
	struct MONTH_INFO Info;
};
void am_lich(unsigned char SolarDay, unsigned char SolarMonth, unsigned int SolarYear)
{	
	unsigned char N_AL_DT_DL; 
	unsigned char T_AL_DT_DL; 
	unsigned char SN_CT_AL;
	unsigned char TN_B_THT;
	unsigned char N_AL_DT_DL_TT;
	unsigned char T_AL_DT_DL_TT;

	union LUNAR_RECORD lr;
        SolarYear+=2000;
        
	lr.Word = LUNAR_CALENDAR_LOOKUP_TABLE[(SolarYear-BEGINNING_YEAR)*12+SolarMonth -1]; 
	N_AL_DT_DL = lr.Info.N_AL_DT_DL;
	T_AL_DT_DL = lr.Info.T_AL_DT_DL;
	SN_CT_AL = lr.Info.SN_CT_AL + 29;
	TN_B_THT =  lr.Info.TN_B_THT;

	lr.Word = LUNAR_CALENDAR_LOOKUP_TABLE[(SolarYear-BEGINNING_YEAR)*12+SolarMonth];
	N_AL_DT_DL_TT = lr.Info.N_AL_DT_DL;
	T_AL_DT_DL_TT = lr.Info.T_AL_DT_DL;

	// Tinh ngay & thang
	if(N_AL_DT_DL == SN_CT_AL && N_AL_DT_DL_TT == 2)
	{
	 	if(SolarDay==1)
		{
		 	ngay_al = N_AL_DT_DL;
			thang_al = T_AL_DT_DL;
		}
		else if(SolarDay==31)
		{
		 	ngay_al = 1;
			thang_al = T_AL_DT_DL_TT;
		}
		else
		{
		 	ngay_al = SolarDay - 1;
			if(TN_B_THT)
			{
				thang_al = T_AL_DT_DL;
			}
			else
			{
			 	thang_al = T_AL_DT_DL==12?1:(T_AL_DT_DL + 1);
			} 
		}
	}
	else
	{
	 	ngay_al = SolarDay + N_AL_DT_DL - 1;
		if(ngay_al<= SN_CT_AL)
		{
		 	thang_al = T_AL_DT_DL;
		}
		else
		{
		 	ngay_al -= SN_CT_AL;

			thang_al = T_AL_DT_DL + 1 - TN_B_THT;
			if(thang_al == 13) thang_al = 1;
		}
	}
}
void number_l2r()
{
			  DRAW_FillRec(0,49,15,16,0,0,0); //clear hinh cu
				DRAW_FillRec(0,0,26,16,0,0,0); //clear hinh cu
		 
		    P10_chonvitri(3,49);  //in dau cham
				P10_sendRec();
				P10_chonvitri(10,49);
				P10_sendRec();
				
		    insoto(1,54,time[1]);		
	
				P10_chonvitri(8,13);
				P10_sendnumSmall(time[2]/10);
				P10_sendnumSmall(time[2]%10);
				
				DRAW_FillRec(10,25,1,1,255,0,0);  //in dau cham
				DRAW_FillRec(14,25,1,1,255,0,0); 
				
				
			for(char x_max = 53;x_max>42;x_max--)
			{
				for(char mau=0;mau<3;mau++)
					for(char y=1;y<16;y++)
						 for(char x=0;x<x_max;x++)
							 display[mau][y][x] = display[mau][y][x+1];
				insoto(1,x_max,time[0]);	
				P10_display();
				HAL_Delay(20);
			}
			for(char mau=0;mau<3;mau++)for(char y=1;y<16;y++)display[mau][y][53]=0;
			P10_display();
}
void number_r2l()
{
			for(char x_max = 0;x_max<11;x_max++)
			{
				for(char mau=0;mau<3;mau++)
					for(char y=1;y<16;y++)
						 for(char x=63;x>0;x--)
							 display[mau][y][x] = display[mau][y][x-1];
				P10_display();
				HAL_Delay(10);
			}
			
			DRAW_FillRec(0,49,15,16,0,0,0); //clear hinh cu
			DRAW_FillRec(0,0,26,16,0,0,0); //clear hinh cu
			
			insoto(1,0,time[2]);
	
				P10_chonvitri(3,22);  //in dau cham
				P10_sendRec();
				P10_chonvitri(10,22);
				P10_sendRec();
			
			  DRAW_FillRec(10,49,1,1,255,0,0);  //in dau cham
				DRAW_FillRec(14,49,1,1,255,0,0); 
				
				P10_chonvitri(8,51);
				P10_sendnumSmall(time[0]/10);
				P10_sendnumSmall(time[0]%10);
			
			  P10_display();
}
unsigned int ADC_val;
void laydosang() //do sang kha kien 200 -> 800 /4095
{
	unsigned int read_ADC[10]={0,0,0,0,0,0,0,0,0,0}; //lay khoang 10 lan 
	for(char solan=0;solan<10;solan++)
	{
		HAL_ADC_Start_DMA(&hadc1,(uint32_t*)&read_ADC[solan],1);
	  HAL_Delay(1);
	  HAL_ADC_Stop_DMA(&hadc1);
	}
	ADC_val = (unsigned int)(read_ADC[0] + read_ADC[1] + read_ADC[2] + read_ADC[3] + read_ADC[4] + read_ADC[5] + read_ADC[6] + read_ADC[7] + read_ADC[8] + read_ADC[9]) / 10;
	     if(ADC_val<mucsang_CAIDAT)__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,1);
	else if(ADC_val<mucsang_CAIDAT+200)__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,100);
	else if(ADC_val<mucsang_CAIDAT+500)__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,200);
	else if(ADC_val<mucsang_CAIDAT+1200)__HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,300);
	else __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,400);
}
void disp_trangchu()
{
laythoigian();
mode = 255;
for(signed char solan=15;solan>=0;solan--)
{
	DRAW_FillRec(0,0,64,16,0,0,0);
	
	insoto(1,0,time[2]);
	
	P10_chonvitri(3,22);  //in dau cham
	P10_sendRec();
	P10_chonvitri(10,22);
	P10_sendRec();
	
	insoto(1,27,time[1]);
	
	DRAW_FillRec(10,49,1,1,255,0,0);  //in dau cham
	DRAW_FillRec(14,49,1,1,255,0,0); 
	
	P10_chonvitri(8,51);
	P10_sendnumSmall(time[0]/10);
	P10_sendnumSmall(time[0]%10);

	for(char y_cao = 0;y_cao<solan;y_cao++)
	{
		for(char mau=0;mau<3;mau++)
			for(char y=0;y<15;y++)
				for(char x=0;x<64;x++)
					display[mau][y][x] = display[mau][y+1][x];
		for(char mau=0;mau<3;mau++)
			for(char x=0;x<64;x++)
				display[mau][15][x] = 0;		
	}
	P10_display();
  HAL_Delay(15);
}
	mode=0;		
}
void P10_sendnumSmall_SET(char num,char color)
{
		for(int mau=0;mau<3;mau++)
			 for(int y=0;y<7;y++)
					 for(int x=0;x<6;x++)
	           {
							  if((font5x7[num][y] & (0x80>>x)) != 0)
								{
									     if(color == 1 && mau ==0)display[mau][y+p10_y][x+p10_x]=0xFF;
									else if(color == 0 && mau ==2)display[mau][y+p10_y][x+p10_x]=0xFF;
									else if(color == 2)display[mau][y+p10_y][x+p10_x]=0x7F;
									else display[mau][y][x]=0;
								}
								else display[mau][y+p10_y][x+p10_x]=0;
						 }
    p10_x+=6;
}
void disp_trangCaiDatTime(char mode1,char mode2,char mode3,char mode4,char mode5,char mode6)
{
	 DRAW_FillRec(0,0,64,16,0,0,0); //xoa man hinh
	 P10_chonvitri(0,11);
	 P10_sendnumSmall_SET(time[2]/10,mode1);
	 P10_sendnumSmall_SET(time[2]%10,mode1);
	
	 DRAW_FillRec(1,24,1,1,0,0,255);  //in dau cham
	 DRAW_FillRec(5,24,1,1,0,0,255); 
	 
	 P10_chonvitri(0,25);
	 P10_sendnumSmall_SET(time[1]/10,mode2);
	 P10_sendnumSmall_SET(time[1]%10,mode2);
	
	 DRAW_FillRec(1,38,1,1,0,0,255);  //in dau cham
	 DRAW_FillRec(5,38,1,1,0,0,255); 
	
	 P10_chonvitri(0,39);
	 P10_sendnumSmall_SET(time[0]/10,mode3);
	 P10_sendnumSmall_SET(time[0]%10,mode3);
	
	 P10_chonvitri(9,0);
	 P10_sendnumSmall_SET(time[4]/10,mode4);
	 P10_sendnumSmall_SET(time[4]%10,mode4); 
   P10_sendnumSmall_SET(15,0);
	 P10_sendnumSmall_SET(time[5]/10,mode5);
	 P10_sendnumSmall_SET(time[5]%10,mode5);
	 P10_sendnumSmall_SET(15,0);
	 P10_sendnumSmall_SET(2,mode6);
	 P10_sendnumSmall_SET(0,mode6);
	 P10_sendnumSmall_SET(time[6]/10,mode6);
	 P10_sendnumSmall_SET(time[6]%10,mode6);
	 
	 
	 P10_display();
}
void disp_trangChayChu()
{
for(char thanhdoc=11;thanhdoc<51;thanhdoc++)
{
	DRAW_FillRec(0,11,41,8,0,0,0); //xoa man hinh
	P10_chonvitri(0,11);
	P10_sendnumSmall(time[2]/10);
	P10_sendnumSmall(time[2]%10);
	
	DRAW_FillRec(2,23,1,1,255,0,0);  //in dau cham
	DRAW_FillRec(6,23,1,1,255,0,0); 
	
	P10_chonvitri(0,25);
	P10_sendnumSmall(time[1]/10);
	P10_sendnumSmall(time[1]%10);
	
	DRAW_FillRec(2,37,1,1,255,0,0);  //in dau cham
	DRAW_FillRec(6,37,1,1,255,0,0); 
	
	P10_chonvitri(0,39);
	P10_sendnumSmall(time[0]/10);
	P10_sendnumSmall(time[0]%10);
	
	for(char mau=0;mau<3;mau++)for(char y_doc=0;y_doc<8;y_doc++)display[mau][y_doc][thanhdoc] = 0x7F;
	for(char mau=0;mau<3;mau++)
	  for(char y_doc=0;y_doc<8;y_doc++)
		   for(char phiasau_thanhdoc=thanhdoc+1;phiasau_thanhdoc<51;phiasau_thanhdoc++)
			   display[mau][y_doc][phiasau_thanhdoc]=0x00;
	P10_display();
	HAL_Delay(20);
}
	DRAW_FillRec(0,50,1,8,0,0,0); //xoa man hinh
  P10_display();

  if(time[3]!=1){chuchay[0]='=';chuchay[2]=time[3]+48;}
  else {chuchay[0]='F';chuchay[2]='G';}
	
  chuchay[4]=time[4]/10+48;
  chuchay[5]=time[4]%10+48;
  chuchay[7]=time[5]/10+48;
  chuchay[8]=time[5]%10+48;
  chuchay[12]=time[6]/10+48;
  chuchay[13]=time[6]%10+48;
  am_lich(time[4],time[5],time[6]);
  chuchay[18]=ngay_al/10+48;
  chuchay[19]=ngay_al%10+48;
  
  chuchay[21]=thang_al/10+48;
  chuchay[22]=thang_al%10+48;
  chuchay[24]=nhietdo/10+48;
  chuchay[25]=nhietdo%10+48;

	mode=2;	//mode chay chu
	dichtrai=0;chu=0;ktdich=6;
}
void thoatTrangChayChu()
{
mode=255;
for(char solan=0;solan<64;solan++)
{
	for(char mau=0;mau<3;mau++)
	  for(char y=0;y<8;y++)
	    for(char x=0;x<63;x++)
	      display[mau][y][x] = display[mau][y][x+1];
	for(char mau=0;mau<3;mau++)
	  for(char y=0;y<8;y++)
	    display[mau][y][63] = 0;
	for(char mau=0;mau<3;mau++)
	  for(char y=8;y<16;y++)
	    for(signed char x=63;x>0;x--)
	      display[mau][y][x] = display[mau][y][x-1];
	for(char mau=0;mau<3;mau++)
	  for(char y=8;y<16;y++)
	    display[mau][y][0] = 0;
	P10_display();
	HAL_Delay(20);
}
}
void trangchu()
{
 if(time[0]==35){mode=255;number_l2r();mode=1;}
 if(time[0]==55){mode=255;number_r2l();mode=0;}						 
 if(mode==0)latsonho(time[0],8,51,4);
 else if(mode==1)latsoto(time[0],1,43,4);
 if(time[0]==0)
	{
	 insoto(1,27,time[1]);  //in phut
	 insoto(1,0,time[2]); //in gio
	}
}
void cuonlen()
{
mode=255; 
for(char solancuon=0;solancuon<4;solancuon++)
{
	for(char mau=0;mau<3;mau++)
	 for(char y=0;y<15;y++)
	   for(char x=0;x<10;x++)
			 display[mau][y][x]=display[mau][y+1][x];
	for(char mau=0;mau<3;mau++)for(char x=0;x<10;x++)display[mau][15][x]=0;
	P10_display();
	HAL_Delay(15);
} //cuon len gio 5 lan
for(char solancuon=0;solancuon<4;solancuon++)
{
	for(char mau=0;mau<3;mau++)
	 for(char y=0;y<15;y++)
	   for(char x=0;x<21;x++)
			 display[mau][y][x]=display[mau][y+1][x];
	for(char mau=0;mau<3;mau++)for(char x=0;x<21;x++)display[mau][15][x]=0;
	P10_display();
	HAL_Delay(15);
} //cuon len gio 5 lan
for(char solancuon=0;solancuon<4;solancuon++)
{
	for(char mau=0;mau<3;mau++)
	 for(char y=0;y<15;y++)
	   for(char x=0;x<26;x++)
			 display[mau][y][x]=display[mau][y+1][x];
	for(char mau=0;mau<3;mau++)for(char x=0;x<26;x++)display[mau][15][x]=0;
	P10_display();
	HAL_Delay(15);
} //cuon len gio va dau 2 cham 7 lan
for(char solancuon=0;solancuon<4;solancuon++)
{
	for(char mau=0;mau<3;mau++)
	 for(char y=0;y<15;y++)
	   for(char x=0;x<37;x++)
			 display[mau][y][x]=display[mau][y+1][x];
	for(char mau=0;mau<3;mau++)for(char x=0;x<37;x++)display[mau][15][x]=0;
	P10_display();
	HAL_Delay(15);
} //cuon len gio va dau 2 cham va phut 5 lan
for(char solancuon=0;solancuon<4;solancuon++)
{
	for(char mau=0;mau<3;mau++)
	 for(char y=0;y<15;y++)
	   for(char x=0;x<48;x++)
			 display[mau][y][x]=display[mau][y+1][x];
	for(char mau=0;mau<3;mau++)for(char x=0;x<48;x++)display[mau][15][x]=0;
	P10_display();
	HAL_Delay(15);
} //cuon len gio va dau 2 cham va phut 5 lan
for(char solancuon=0;solancuon<4;solancuon++)
{
	for(char mau=0;mau<3;mau++)
	 for(char y=0;y<15;y++)
	   for(char x=0;x<56;x++)
			 display[mau][y][x]=display[mau][y+1][x];
	for(char mau=0;mau<3;mau++)for(char x=0;x<56;x++)display[mau][15][x]=0;
	P10_display();
	HAL_Delay(15);
}
for(char solancuon=0;solancuon<16;solancuon++)
{
	for(char mau=0;mau<3;mau++)
	 for(char y=0;y<15;y++)
	   for(char x=0;x<64;x++)
			 display[mau][y][x]=display[mau][y+1][x];
	for(char mau=0;mau<3;mau++)for(char x=0;x<64;x++)display[mau][15][x]=0;
	P10_display();
	HAL_Delay(15);
} //cuon len tat ca
}
void flash_write(uint32_t add,uint32_t dat)
{
	HAL_FLASH_Unlock();
	HAL_FLASH_Program(OB_WRP_PAGES124TO127,add,dat);
	HAL_FLASH_Lock();
}
uint32_t flash_read(uint32_t add)
{
	return *(uint32_t*)add;
}

char cai(char so,char max,char min,char mode1,char mode2,char mode3,char mode4,char mode5,char mode6)
{
 disp_trangCaiDatTime(mode1,mode2,mode3,mode4,mode5,mode6);
 while(1)
 {
	 if(HAL_GPIO_ReadPin(GPIOB,UP) == 0 )
	 {
		 HAL_Delay(200);
		 time[so]++;if(time[so]>max)time[so]=min;
		 disp_trangCaiDatTime(mode1,mode2,mode3,mode4,mode5,mode6); // lam moi hien thi
	 }
	 if(HAL_GPIO_ReadPin(GPIOB,OK) == 0 )
	 {
	   HAL_Delay(20);
		 while( HAL_GPIO_ReadPin(GPIOB,OK) == 0 ); //cho nha phim 
		 return time[so];
	 }
 }
}
void caidat()
{
	if(HAL_GPIO_ReadPin(GPIOB,OK) == 0 )
	{
		 HAL_Delay(20);
		 while( HAL_GPIO_ReadPin(GPIOB,OK) == 0 ); //cho nha phim 
		 mode=255;
		 ghids(2,BCD_Encoder(cai(2,23,0,1,0,0,0,0,0)));
		 ghids(1,BCD_Encoder(cai(1,59,0,0,1,0,0,0,0)));
	   ghids(0,BCD_Encoder(cai(0,59,0,0,0,1,0,0,0)));
		 ghids(4,BCD_Encoder(cai(4,31,1,0,0,0,1,0,0)));
		 ghids(5,BCD_Encoder(cai(5,12,1,0,0,0,0,1,0)));
	   ghids(6,BCD_Encoder(cai(6,99,18,0,0,0,0,0,1)));
		
		if(time[5]>=3)time[3] = (time[4]+2*time[5]+(3*(time[5]+1)) / 5 + (2000+time[6]) + ((2000+time[6]) / 4)) % 7;
    else time[3] = (time[4]+2*(time[5]+12)+(3*((time[5]+12)+1)) / 5 + ((2000+time[6])-1) + (((2000+time[6])-1) / 4)) % 7;
    time[3]++;   
    ghids(3,BCD_Encoder(time[3]));  // tinh thu 
		disp_trangchu();
	}
	if(HAL_GPIO_ReadPin(GPIOB,UP) == 0 )
	{
		 HAL_Delay(20);
		 while( HAL_GPIO_ReadPin(GPIOB,UP) == 0 ); //cho nha phim
		 mode=255;
		 DRAW_FillRec(0,0,64,16,0,0,0); //xoa man hinh
		 while(1)
		 {			    
			  P10_chonvitri(9,0); //1234
			  P10_sendnumSmall_SET(mucsang_CAIDAT/1000,1);
			  P10_sendnumSmall_SET(mucsang_CAIDAT%1000/100,1);
			  P10_sendnumSmall_SET(mucsang_CAIDAT%100/10,1);
			  P10_sendnumSmall_SET(mucsang_CAIDAT%10,1);
			  laydosang();			
			  P10_chonvitri(0,0); //1234
				P10_sendnumSmall_SET(ADC_val/1000,2);
			  P10_sendnumSmall_SET(ADC_val%1000/100,2);
			  P10_sendnumSmall_SET(ADC_val%100/10,2);
			  P10_sendnumSmall_SET(ADC_val%10,2);
				if(HAL_GPIO_ReadPin(GPIOB,UP) == 0 )
					{
						HAL_Delay(100);
            mucsang_CAIDAT+=50;if(mucsang_CAIDAT>2000)mucsang_CAIDAT=0;
					}
				if(HAL_GPIO_ReadPin(GPIOB,OK) == 0 )
					{
						HAL_Delay(20);
						while(HAL_GPIO_ReadPin(GPIOB,OK) == 0 ); // cho nha phim
						flash_write(ADD_FLASH_mucsang_CAIDAT,mucsang_CAIDAT);  // luu muc sang cai dat vao flash
						break;
					}
			  P10_display();
			  HAL_Delay(100);
		 }
		 disp_trangchu();
	}
}
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_ADC1_Init();
  MX_TIM4_Init();
				
			  HAL_TIM_Base_Start_IT(&htim3);
				HAL_TIM_Base_Start_IT(&htim4);
				HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_4);
				laydosang();
	
  mucsang_CAIDAT = flash_read(ADD_FLASH_mucsang_CAIDAT);
	if(mucsang_CAIDAT>4000 || mucsang_CAIDAT<0)mucsang_CAIDAT=mucsang_CAIDAT_macdinh;
	
	laythoigian();		
	hieuung = time[1]%4;
	disp_trangchu();
  while (1)
  {	     
				 laythoigian();	     
				 HAL_Delay(100);	 
				 if(time[0] != giaycu)
				 {
					 laydosang();
					 giaycu = time[0];
					 if(time[0]==10) // mode chay chu
						 {
							 if(time[1]%5==0) //5 phut chay chu cmnm 1 lan
							 {
								  mode=255;
								  DRAW_FillRec(0,0,64,16,0,0,0); //xoa man hinh
								  kiemtra_chieudai_text();
								  dichtrai=chu=demb=0;
									while(1)
									{
										 if(chaychuCMNM()==0)break; //chay xong thi thoat
										 P10_display();
										 HAL_Delay(50);
									}
							 }
							 else
							 {
									hieuung = time[1]%4;
									cuonlen();
									disp_trangChayChu();
									while(1)
									{
										 if(mode!=2)break;
										 time[0] = BCD_Decoder(docds(0)); //lay giay
										 if(giaycu!=time[0])
										 {
											 laydosang();
											 giaycu=time[0];
											 latsonho(time[0],0,39,4);
										 }
									}					
								}
								disp_trangchu();
						 }
					 else trangchu();
			   }
				 caidat();
  }

}

char demnhaygiay;
const char toado_demnhaygiay_to_top[5]={3,4,5,4,3}; //toa do dau cham to top
const char toado_demnhaygiay_to_bot[5]={10,9,8,9,10}; //toa do dau cham to bot
const char toado_demnhaygiay_nho_top[5]={10,11,12,11,10}; //toa do dau cham nho top
const char toado_demnhaygiay_nho_bot[5]={14,13,12,13,14}; //toa do dau cham nho bot
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) 
	{
		 if(htim->Instance==TIM3)
			 { 
				    htim3.Init.Prescaler = timer_clock[vitri_bit]; 
					  TIM_Base_SetConfig(htim->Instance, &htim->Init);		//set lai bo dem	
				    __HAL_TIM_CLEAR_IT(&htim3, TIM_IT_UPDATE);          //xoa co
				 
				    //TIM3->PSC = timer_clock[vitri_bit];  //set lai bo dem
		        //TIM3->SR = 0; //xoa co  -> k hieu sao k chay
				 
				    xuat_P->BSRR=(1<<(xuat+16)); 
				 
				    for(int i=0;i<64;i++){GPIOA->ODR=led[hang_led][vitri_bit][i];clk_P->BSRR=(1<<clk);}	 			
						
						hang(hang_led);
						xuat_P->BSRR=(1<<xuat); // chot data					
						
            vitri_bit++;
						if(vitri_bit==8){vitri_bit=0;hang_led++;if(hang_led==8)hang_led=0;}								
			 }
		if(htim->Instance==TIM4) //200ms ngat 1 lan
			 {
				   check_TIM4++;		   
					 if(mode==0 || mode==1) //che do nhay giay thu 1
					 {
						 if(check_TIM4%2!=0)
						 {
								DRAW_FillRec(3,mode_ef_giay_to[mode],4,11,0,0,0); //clear hinh cu
								DRAW_FillRec(10,mode_ef_giay_be[mode],1,5,0,0,0);  //xoa hinh cu		
								P10_chonvitri(toado_demnhaygiay_to_top[demnhaygiay],mode_ef_giay_to[mode]);
								P10_sendRec(); //in dau cham TOP
								P10_chonvitri(toado_demnhaygiay_to_bot[demnhaygiay],mode_ef_giay_to[mode]); 
								P10_sendRec(); //in dau cham BOT	      
								//in dau cham nho TOP
								if(hieuung==2)
								 {
									 DRAW_FillRec(toado_demnhaygiay_nho_top[demnhaygiay],mode_ef_giay_be[mode],1,1,0,255,0); 
								   DRAW_FillRec(toado_demnhaygiay_nho_bot[demnhaygiay],mode_ef_giay_be[mode],1,1,0,255,0);
								 }
							  else
							   {
									 DRAW_FillRec(toado_demnhaygiay_nho_top[demnhaygiay],mode_ef_giay_be[mode],1,1,255,0,0); 
								   DRAW_FillRec(toado_demnhaygiay_nho_bot[demnhaygiay],mode_ef_giay_be[mode],1,1,255,0,0);				
								 }
								demnhaygiay++;if(demnhaygiay==5)demnhaygiay=0;
								P10_display(); //display
						 }
					 }
				 else if(mode==2)
				 { 
					  if(check_TIM4%2!=0)
						 {
							DRAW_FillRec(2,mode_ef_giay_be[mode],1,5,0,0,0);  //xoa hinh cu	
							DRAW_FillRec(2,mode_ef_giay_be[mode+1],1,5,0,0,0);  //xoa hinh cu
							DRAW_FillRec(toado_demnhaygiay_nho_top[demnhaygiay]-8,mode_ef_giay_be[mode],1,1,255,0,0); 
							DRAW_FillRec(toado_demnhaygiay_nho_bot[demnhaygiay]-8,mode_ef_giay_be[mode],1,1,255,0,0);			
							DRAW_FillRec(toado_demnhaygiay_nho_top[demnhaygiay]-8,mode_ef_giay_be[mode+1],1,1,255,0,0); 
							DRAW_FillRec(toado_demnhaygiay_nho_bot[demnhaygiay]-8,mode_ef_giay_be[mode+1],1,1,255,0,0);							 
							demnhaygiay++;if(demnhaygiay==5)demnhaygiay=0;
						 }
					  chaychu();
					  P10_display(); //display
				 }
			 }
	}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Common config 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 400;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_LOW;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim2);

}

/* TIM3 init function */
static void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 65535;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 38;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM4 init function */
static void MX_TIM4_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 36000;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 199;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4 
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10 
                          |GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA1 PA2 PA3 PA4 
                           PA5 PA6 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4 
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB10 
                           PB13 PB14 PB6 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10 
                          |GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB4 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
