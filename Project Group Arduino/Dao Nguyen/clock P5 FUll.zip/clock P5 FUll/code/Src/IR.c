#include <IR.h>
#include "flash.h"
#include "P5.h"

extern TIM_HandleTypeDef htim3; //khai bao timer su dung cho IR

unsigned char IRI;
unsigned long giatri;
char chedohoclenh;
char key=0;
uint16_t Key_IR[6];
uint16_t GET_KEY_IR(int key)
{
	 return Key_IR[key];
}
void SET_KEY_IR(int key,int dat)
{
	 Key_IR[key]=dat;
}
uint16_t GET_datakeyIR(char i)
{
	return Key_IR[i];
}
void SET_datakeyIR(uint16_t i,uint16_t val)
{
	Key_IR[i]=val; 
}
char GET_key(void)
{
	char k = key;
	key=0;
	return k;
}
void SET_key(char val)
{
	key=val; 
}
uint32_t GET_IR_data(void)
{
	return giatri;
}
char GET_chedohoclenh(void)
{
	return chedohoclenh;
}
void SET_chedohoclenh(char mode)
{
	chedohoclenh=mode; 
}
void IR_Start(void)
{
	HAL_NVIC_EnableIRQ(EXTI3_IRQn);
}
void IR_Stop(void)
{
	HAL_NVIC_DisableIRQ(EXTI3_IRQn);
}
void IR_ngatT(void)
{
	     HAL_TIM_Base_Stop_IT(&htim3); // stop t2
			 if(IRI == 1) IRI=0;	     		
       else if(IRI == 2)
			 {
				    IR_Stop();//tam thoi cam ngat IR de xu li	
            IRI=0;           			
						HAL_TIM_Base_Stop_IT(&htim3);
						//xu li du lieu tai day      
						if(GET_chedohoclenh() != 0) //neu dang o trong mode hoc lenh
						{
							   uint16_t data;
							   data=GET_IR_data();
							   //clear key IR			   
                 //so sanh trung lap data
								 if(data != 0 && data != Key_IR[0] && data != Key_IR[1] && data != Key_IR[2] && data != Key_IR[3] && data != Key_IR[4] && data != Key_IR[5] )
								 {
													if(GET_chedohoclenh() == 1) {SET_chedohoclenh(2);Key_IR[0]=data;P5_clear();P5_chonvitri(0,0);P5_sendString_wColor(S{71,105,165,109,32,180,207,0},31,0,0);P5_chonvitri(0,16);P5_sendString_wColor(S{115,163,110,103,0},31,0,0);}         
										else  if(GET_chedohoclenh() == 2) {SET_chedohoclenh(3);Key_IR[1]=data;P5_clear();P5_chonvitri(0,0);P5_sendString_wColor(S{72,201,99,32,110,214,116},31,31,0);P5_chonvitri(0,16);P5_sendString_wColor(S{109,101,110,117,0},31,31,0);}
										else  if(GET_chedohoclenh() == 3) {SET_chedohoclenh(4);Key_IR[2]=data;P5_clear();P5_chonvitri(0,0);P5_sendString_wColor(S{72,201,99,32,110,214,116,0},31,31,31);P5_chonvitri(0,16);P5_sendString_wColor(S{116,114,163,105,0},31,0,31);}
										else  if(GET_chedohoclenh() == 4) {SET_chedohoclenh(5);Key_IR[3]=data;P5_clear();P5_chonvitri(0,0);P5_sendString_wColor(S{72,201,99,32,110,214,116,0},31,31,31);P5_chonvitri(0,16);P5_sendString_wColor(S{112,104,165,105,0},31,0,31);}
										else  if(GET_chedohoclenh() == 5) {SET_chedohoclenh(6);Key_IR[4]=data;P5_clear();P5_chonvitri(0,0);P5_sendString_wColor(S{72,201,99,32,110,214,116,0},31,31,31);P5_chonvitri(0,16);P5_sendString_wColor(S{116,104,111,163,116,0},0,0,31);}
										else  if(GET_chedohoclenh() == 6)  //hoc lenh ket thuc
											{
												 Key_IR[5]=data;
												 EEP_write(5,data);
												 SET_chedohoclenh(0);
											}

								 }
						} 
						else
						{
							   uint16_t data;
							   data=GET_IR_data();
							        if(data == Key_IR[0])SET_key(1);
							   else if(data == Key_IR[1])SET_key(2);
								 else if(data == Key_IR[2])SET_key(3);
                 else if(data == Key_IR[3])SET_key(4);
                 else if(data == Key_IR[4])SET_key(5);
                 else if(data == Key_IR[5])SET_key(6);							
						}			
					  IR_Start();						
					}		
}
void IR_ngatPin(void)
{
	     unsigned int pulse_width; 
			 HAL_TIM_Base_Stop_IT(&htim3); // stop t2
			 pulse_width = htim3.Instance -> CNT; //lay gia tri dem duoc cua timer ra
			 htim3.Instance -> CNT = 0x63C0;//nap gia tri vao time
			 HAL_TIM_Base_Start_IT(&htim3);//cho timer chay
			 pulse_width = pulse_width - 25536;
			 switch(IRI)
				 {
						case 0: 
										IRI=1;
										break; 
						case 1: 
										if(pulse_width > 5000)
										{
												IRI=2;    
												giatri=0;
										}
										else
												IRI--;
										break;
						case 2: 
												giatri <<= 1;
												if(pulse_width > 3000)
												giatri |= 1;
												break;
	        }
}


