#include "stm32f1xx_hal.h"

#define saiso 300
#define IR_PIN GPIO_PIN_3

//------------------------END-----------------------------//

void IR_Start(void);
void IR_Stop(void);
void IR_ngatT(void);
void IR_ngatPin(void);
char GET_chedohoclenh(void);
void SET_chedohoclenh(char mode);
char GET_key(void);
void SET_key(char val);
uint32_t GET_IR_data(void);
uint16_t GET_KEY_IR(int key);
void SET_KEY_IR(int key,int dat);
