#include <REGX52.H>
#include "ds1307.h"

void delay_ms()
{
	int y;
	for(y=0;y<200;y++);
}
void I2C_Start(void)
{
	SDA = 1;	
	SCL = 1;	// dua SCL va SDA len muc 1
	SDA = 0;	// keo SDA xuong 0
	delay_ms(); // delay 1 khoang thoi gian ngan
	SCL = 0;	  // keo SCL xuong 0  ( qua trinh Start ket thuc)
	SDA = 1;	  // dua SDA len muc 1 ( cau lenh nay khong can cung dc)
}
void I2C_STOP()
{
  SDA=0; // cho SDA xuong 0 de chuan bi dua len 1
  SCL=1; // dua SCL len muc 1 
  SDA=1; // SDA duoc dua len muc 1. Qua trinh Stop hoan tat
}
/*------------------------end Stop------------------*/
bit I2C_Write(unsigned char dat) // khai bao ham truyen du lieu va bien dat  
{
	unsigned char i;  // khai bao bien i
	bit outbit;		  // khai bao bit 
	
	for (i = 1; i <= 8; i++)	//vong lap for lap 8 lan tuong duong 8 bit ( 1 byte)
	{
		outbit=dat&0x80;	    // g�n bien outbit cho byte can truen & 0x80 ; 
		SDA = outbit;			 // cho SDA bang voi gia tri cua outbit ( 1 hoac 0)
		dat = dat << 1;			 // dich trai 1 lan
		SCL = 1;
		SCL = 0;				 // tao 1 xung clock tren chan SCL de dich gia tri 1 hoac 0 tren chan SDA vao slaver
    }	
	SDA = 1;	
	SCL = 1;	  // dua SDA va SCL len muc 1 chuan bi doc bit ack
	outbit = SDA;	// lay bit ack tu chan SDA
	SCL = 0;		// cho SCL ve 0	 
	return(outbit);	// lay gia tri ve
}
unsigned char I2C_Read(bit ack)
{
	unsigned char i, dat;
	bit inbit;	
	dat = 0;
	for(i=1;i<=8;i++)	// moi lan doc 1 bit. 8 lan doc = 1 byte
	 {
		SCL = 1;	   // cho SCL len =1 , slaver se gui 1 bit vao chan SDA
		inbit = SDA;	// lay gia tri cua chan SDA g�n vao inbit
		dat = dat << 1;	 // dich byte data sang tr�i  1 lan
		dat = dat | inbit;	// muc dich la g�n gi� tri cua bit inbit vao byte dat
		SCL = 0;		// cho SLC xuong muc 0 san sang cho lan doc bit tiep thep
	 }
	if (ack) SDA = 0;	 // cac cau lenh  nay dung de doc bit ack ( co the k can quan tam)
	else SDA = 1;
	SCL = 1;	
	SCL = 0;	
	SDA = 1;							 
	return(dat);
}
 /*------------------------end I2C read------------------*/
// ham ghi du lieu vao ds1307
void ghi(unsigned char add, unsigned char dat)
{
	I2C_Start(); // bat dau ghi	
	I2C_Write(0xd0); //0xd0 la dia chi cua ds1307
	I2C_Write(add);	// gia tri can ghi
	I2C_Write(((dat/10)<<4)|(dat%10)); 	 // do du lieu trong ds la BCD nen ta can chuyen ca gia tri sang BCD ( day cau lenh chuyen du lieu sang BCD)
	I2C_STOP();	 // ket thuc qua trinh truyen du lieu
}
unsigned char doc(unsigned char add)
{
	unsigned char dat;
	
	I2C_Start();   // bat dau doc
	
	I2C_Write(0xd0); 	// dau tien gui lenh ghi du lieu(ghi dia chi can lay du lieu trong DS1307)
	I2C_Write(add); // Dia chi ma ta muon doc ( vi du, muon doc giay thi ta ghi dia chi 0x00)
	I2C_Start(); 	 // bat dau doc du lieu
	I2C_Write(0xd1);  	// gui ma lenh doc du lieu tu dia chi(add)
	dat = I2C_Read(0);	  // doc xong thi luu gia tri da doc dc vao dat
	I2C_STOP();			// ket thuc qua trinh doc du lieu
	dat = (dat & 0x0f) + (dat>>4)*10;	 // du lieu doc ra o dang BCD nen chuyen sang he 10					  
	return (dat);  // tra ve gia tri da doc duoc
}
void Out_1hz(char c)
{
	I2C_Start();																			
	I2C_Write(0xD0); 														
	I2C_Write(0x07);
	if(c==1)I2C_Write(0x10);
	else I2C_Write(0);
	I2C_STOP();
}

void DS1307_get_TIME_and_Date(unsigned char *s)
{
	int i;
	for(i=0;i<8;i++)s[i]=doc(i);
}
