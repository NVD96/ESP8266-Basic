#ifndef __DS1307_H__
#define __DS1307_H__

/* C�c lenh dinh nghia giao tiep i2c*/
#define SCL  P1_0
#define SDA  P1_1		

void I2C_Start(void);
void I2C_STOP();
bit I2C_Write(unsigned char dat); // khai bao ham truyen du lieu va bien dat
unsigned char I2C_Read(bit ack);
void ghi(unsigned char add, unsigned char dat);
unsigned char doc(unsigned char add);
void Out_1hz(char c);

void DS1307_get_TIME_and_Date(unsigned char s[7]);

	
#endif  //__DS1307_H__

