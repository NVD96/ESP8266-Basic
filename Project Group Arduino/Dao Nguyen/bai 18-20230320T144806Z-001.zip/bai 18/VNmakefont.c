#include "VNmakefont.h"

const uint32_t UTF8_table[] =
{
0x00E4BDA0, //你
0x00E5A5BD, //好
0x00EC9588, //안
0x00EB8595, //녕
0x00ED9598, //하
0x00EC84B8, //세
0x00EC9A94, //요


	
};

//(C) 2020 By Dao Nguyen IOT47.com
const uint8_t Microsoft_Sans_Serif[]={
10,
10,11,2,0,
0x40,0x00,0x2C,0x00,0x4F,0xC0,0x52,0x40,0xD2,0x80,0xCA,0x80,0xCA,0x80,0x4A,0x40,0x52,0x40,0x52,0x00,0x46,0x00,//你
11,11,2,0,
0x40,0x00,0x47,0xC0,0xF0,0x40,0x50,0x80,0x51,0x00,0x91,0x00,0x97,0xE0,0xD1,0x00,0x21,0x00,0x51,0x00,0x83,0x00,//好
9,10,2,0,
0x71,0x00,0x89,0x00,0x89,0x00,0x89,0x80,0x71,0x00,0x01,0x00,0x41,0x00,0x40,0x00,0x40,0x00,0x7F,0x00,//안
7,10,1,0,
0x82,0x9E,0x82,0x9E,0x82,0xFA,0x02,0x3C,0x42,0x3C,//녕
10,10,2,0,
0x21,0x00,0xFD,0x00,0x01,0x00,0x79,0x00,0x85,0x00,0x85,0xC0,0x85,0x00,0x79,0x00,0x01,0x00,0x01,0x00,//하
9,10,2,0,
0x22,0x80,0x22,0x80,0x22,0x80,0x2E,0x80,0x52,0x80,0x52,0x80,0x8A,0x80,0x02,0x80,0x02,0x80,0x02,0x80,//세
9,8,2,0,
0x3E,0x00,0x63,0x00,0x41,0x00,0x63,0x00,0x3E,0x00,0x22,0x00,0x22,0x00,0xFF,0x80,//요

};

//(C) 2020 By Dao Nguyen IOT47.com
const uint16_t Microsoft_Sans_Serif_MAP[]={
5,31,57,81,95,119,143,
};

const Font Font1  = {Microsoft_Sans_Serif,Microsoft_Sans_Serif_MAP};

uint16_t UTF8_GetAddr(unsigned char *utf8_char,unsigned char *char_offset)
{
  *char_offset=1;
	uint32_t utf8_value=0x00000000;
  unsigned char temp = 0xF0 & (*utf8_char);
	if((*utf8_char)<128) //nếu đây là kí tự trong bảng ascii
    utf8_value = *utf8_char;
  else if(temp == 0xC0) //loại utf-8 2 byte
  {
    *char_offset=2;
    utf8_value= (uint32_t)(*utf8_char) << 8;
    utf8_value|=(uint32_t)(*(utf8_char+1));
  }
  else if(temp == 0xE0)    //loại utf-8 3 byte
  {
    *char_offset = 3;                  
    utf8_value= (uint32_t)(*utf8_char) << 16;     
    utf8_value|=(uint32_t)(*(utf8_char+1)) << 8;    
    utf8_value|=(uint32_t)(*(utf8_char+2));           
  }
  else if(temp == 0xF0)    //loại utf-8 4 byte
  {
    *char_offset = 4;                  
    utf8_value= (uint32_t)(*utf8_char) << 24;     
    utf8_value|=(uint32_t)(*(utf8_char+1)) << 16;    
    utf8_value|=(uint32_t)(*(utf8_char+2)) << 8;   
    utf8_value|=(uint32_t)(*(utf8_char+3));       
  }
  else return 0;
  for(unsigned char i = 0; i < sizeof(UTF8_table)/4; i++)
  {
       if(utf8_value == UTF8_table[i])    
         return i;
  }
  return 0;
}

void set_px(int16_t x, int16_t y,Color my_color)
{
	if(x < 0) return;
	if(y < 0) return;
	if(x > P5_W) return;
	if(y > P5_H) return;
	Buffer_RGB[0*arrD1 + y*arrD2 + x] = my_color.r;
	Buffer_RGB[1*arrD1 + y*arrD2 + x] = my_color.g;
	Buffer_RGB[2*arrD1 + y*arrD2 + x] = my_color.b;
}

unsigned char read_font(int16_t x, int16_t y,  uint16_t txt, Font my_font)
{
    unsigned char temp = x % 8;
    unsigned char x1 = 0x80 >> temp;
    unsigned int str = my_font.font_map[txt];
    unsigned char line = my_font.font[str - 2];
    return my_font.font[str+y*line +x/8]& x1;
}

unsigned char putChar(int16_t x,int16_t y,uint16_t txt,Font my_font,Color color,Color backcolor)
{
    unsigned int str = my_font.font_map[txt];
    int size_w = my_font.font[str-4]; //lấy chiều rộng Font   
    int size_h = my_font.font[str-3]; //lấy chiều cao Font 
    int mid_line = my_font.font[0]; //lấy mid line - đường cơ bản
    int start_y=0;
    int offset = my_font.font[str-2];
    if(size_h < mid_line)start_y=mid_line-size_h;
    start_y += my_font.font[str-1];
    for(int i=0;i<size_w;i++)
        for(int h=0;h<size_h;h++)
            if(read_font(i,h,txt,my_font) != 0)
                set_px(i+x,h+y+start_y,color);
            else set_px(i+x,h+y+start_y,backcolor);
    return size_w;
} uint16_t utf8_addr;
void put_String(int16_t x,int16_t y,char *s,Font my_font,Color color,Color backcolor)
{
   unsigned char offset=0;
  
   while(*s)
   {
      utf8_addr=UTF8_GetAddr((unsigned char *)s,&offset);
      x +=putChar(x,y,utf8_addr,my_font,color,backcolor)+1;
      s+=offset;
   }
}
//end file
