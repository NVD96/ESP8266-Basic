
#include <mega8.h>
#include <delay.h>
unsigned char dem;
unsigned char sang=200;
interrupt [TIM1_OVF] void ngattimer1_1ms(void)
{  
  if(sang>=dem)PORTC.0=1;
  else PORTC.0=0;                                                                   
  dem++;
  TCNT1H=0xFE;      // Khoi tao lai gia tri cho TCNT1
  TCNT1L=0x0B;          
}

void main(void)
{

PORTC=0xff;
DDRC=0xff;

// KHOI TAO TIMER1
TCCR1A=0x00;
TCCR1B=0x01;        // Chia tan so cho 1

TCNT1H=0xFE;      // Khoi tao lai gia tri cho TCNT1
TCNT1L=0x0B;

TIMSK=0x04;    // Kich hoat ngat tran TIMER1 
#asm("sei")    // Kich hoat ngat toan cuc  

while (1)
      {
        if(sang<255)sang++;   
        else sang=0;
        delay_ms(10);
      }   
}
