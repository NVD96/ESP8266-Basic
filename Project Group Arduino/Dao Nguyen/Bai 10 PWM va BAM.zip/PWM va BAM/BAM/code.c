/*           
-> 0.125us cho 1 xung  timer     (16mhz)
bit 0: 39us   312 xung   -> FEC7   
bit 1: 78us   624 xung   -> FD8F   
bit 2: 156us  1248 xung  -> FB1F
bit 3: 312    2496 xung  -> F63F
bit 4: 625    5000 xung  -> EC77
bit 5: 1250   10000 xung -> D8EF
bit 6: 2500   20000 xung -> B1DF
bit 7: 5000us 40000 xung -> 63BF  
<100hz>

-> 0.5us cho 1 xung  timer     (8mhz)
bit 0: 39us   78 xung    -> FFB1   
bit 1: 78us   156 xung   -> FF63   
bit 2: 156us  312 xung   -> FEC7
bit 3: 312    625 xung   -> FD8E
bit 4: 625    1250 xung  -> FB1D
bit 5: 1250   2500 xung  -> F63B
bit 6: 2500   5000 xung  -> EC77
bit 7: 5000us 10000 xung -> D8EF  
<100hz>

*/

#include <mega8.h>
#include <delay.h>

unsigned char vitri_bit=0;
unsigned char sang=167;  
unsigned int vl_bit_timer[8]={0xFFB1,0xFF63,0xFEC7,0xFD8E,0xFB1D,0xF63B,0xEC77,0xD8EF};
//unsigned int vl_bit_timer[8]={0xFEC7,0xFD8F,0xFB1F,0xF63F,0xEC77,0xD8FF,0xB1DF,0x64BF};
//8 lan
interrupt [TIM1_OVF] void ngattimer1_1ms(void)
{       
  if((sang & (1<<vitri_bit)))PORTC.0=1;
  else PORTC.0=0;
  
  TCNT1H=vl_bit_timer[vitri_bit]>>8;      // Khoi tao lai gia tri cho TCNT1     ( bit 0);
  TCNT1L=vl_bit_timer[vitri_bit];      
  
  vitri_bit++;if(vitri_bit==7)vitri_bit=0;  //tang bit len 1
}

void main(void)
{
PORTC=0xff;
DDRC=0xff;

// KHOI TAO TIMER1
TCCR1A=0x00;
TCCR1B=0x01;        // Chia tan so cho 1

TIMSK=0x04;    // Kich hoat ngat tran TIMER1 

#asm("sei")    // Kich hoat ngat toan cuc  

while (1)
      {
      
      }
}
