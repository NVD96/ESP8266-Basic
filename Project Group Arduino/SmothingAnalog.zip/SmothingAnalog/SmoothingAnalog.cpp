#include <Arduino.h>
#include "SmoothingAnalog.h"

SmoothingAnalog::SmoothingAnalog(char analogPin, int numOfArray)
{
	_analogPin = analogPin;
	_numOfAnalog = numOfArray;
}

SmoothingAnalog::SmoothingAnalog(char analogPin)
{
	_analogPin = analogPin;
	_numOfAnalog = 10;
}

SmoothingAnalog::SmoothingAnalog()
{
	_analogPin = A0;
	_numOfAnalog = 10;
}

int SmoothingAnalog::getAnalog()
{
	_totalAnalog -= _analogArray[_analogIndex];
	_analogArray[_analogIndex] = analogRead(_analogPin);
	_totalAnalog += _analogArray[_analogIndex];
	_analogIndex++;
	if (_analogIndex >= _numOfAnalog)
		_analogIndex = 0;

	_averageAnalog = _totalAnalog/_numOfAnalog;
	return _averageAnalog;
}