#ifndef SmoothingAnalog_h
#define SmoothingAnalog_h

#include <Arduino.h>

class SmoothingAnalog
	{
	public:
		SmoothingAnalog(char analogPin, int numOfArray);
		SmoothingAnalog(char analogPin);
		SmoothingAnalog();

		int getAnalog();

	private:
		char _analogPin;
		int _numOfAnalog;
		int _analogIndex = 0;
		int _totalAnalog = 0;
		int _averageAnalog = 0;
		int _analogArray[50];
	};

#endif