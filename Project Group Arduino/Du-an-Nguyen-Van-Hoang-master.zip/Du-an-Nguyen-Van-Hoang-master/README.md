# Du-an-Nguyen-Van-Hoang

Các dự án được chia sẻ bởi bạn [Nguyễn Văn Hoàng](https://www.facebook.com/bboyfinishpower)

Bài viết gốc: [https://www.facebook.com/groups/congdongarduinovn/permalink/2896525780634083](https://www.facebook.com/groups/congdongarduinovn/permalink/2896525780634083)

File gốc: [https://drive.google.com/file/d/1LaRveWnP2TPU0SLGPcmkMcguOVRB5KnB/view?usp=sharing](https://drive.google.com/file/d/1LaRveWnP2TPU0SLGPcmkMcguOVRB5KnB/view?usp=sharing)

Một số thay đổi đã thực hiện so với file gốc:

- Xóa các file thừa.
- Chuyển toàn bộ file docx thành pdf.
- Nén các thư mục thư viện chứa nhiều file nhỏ thành 1 file zip duy nhất.
- Xóa phần mềm Arduino IDE và Fritzing do vượt quá kích thước file tối đa được Github hỗ trợ:
	* Arduino IDE: [https://www.arduino.cc/en/main/software](https://www.arduino.cc/en/main/software)
	* Phần mềm Fritzing: [https://github.com/fritzing/fritzing-app/releases](https://github.com/fritzing/fritzing-app/releases)
	* Thư viện các linh kiện cho Fritzing: [https://github.com/fritzing/fritzing-parts](https://github.com/fritzing/fritzing-parts) 