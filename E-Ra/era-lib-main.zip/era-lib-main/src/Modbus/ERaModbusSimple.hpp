#ifndef INC_ERA_MODBUS_SIMPLE_HPP_
#define INC_ERA_MODBUS_SIMPLE_HPP_

#if defined(ERA_MODBUS)
    #include <Modbus/ERaModbus.hpp>
#endif

#endif /* INC_ERA_MODBUS_SIMPLE_HPP_ */
