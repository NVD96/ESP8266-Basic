#ifndef INC_ZCL_CLUSTER_MULTISTATE_HPP_
#define INC_ZCL_CLUSTER_MULTISTATE_HPP_

/*TODO Multistate*/
/** Multistate Attribute IDs */
enum ZbZclMultistateAttrT {
	ZCL_MULTISTATE_BASIC_ATTR_PREVALUE = 0x0055,
};

#endif /* INC_ZCL_CLUSTER_MULTISTATE_HPP_ */
