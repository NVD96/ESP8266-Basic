#ifndef INC_ERA_SIMPLE_ZIGBEE_GSM_HPP_
#define INC_ERA_SIMPLE_ZIGBEE_GSM_HPP_

#define ERA_ZIGBEE

#include <ERaSimpleGsm.hpp>

#endif /* INC_ERA_SIMPLE_ZIGBEE_GSM_HPP_ */
