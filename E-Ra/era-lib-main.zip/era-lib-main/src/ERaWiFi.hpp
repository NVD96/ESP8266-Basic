#ifndef INC_ERA_WIFI_HPP_
#define INC_ERA_WIFI_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleWiFi.hpp>

#endif /* INC_ERA_WIFI_HPP_ */
