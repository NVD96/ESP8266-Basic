#ifndef INC_ERA_ARDUINO_GSM_CLIENT_HPP_
#define INC_ERA_ARDUINO_GSM_CLIENT_HPP_

#if !defined(ERA_PROTO_TYPE)
    #define ERA_PROTO_TYPE            "GSM"
#endif

#endif /* INC_ERA_ARDUINO_GSM_CLIENT_HPP_ */
