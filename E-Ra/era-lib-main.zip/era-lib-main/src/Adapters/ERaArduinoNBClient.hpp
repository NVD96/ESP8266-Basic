#ifndef INC_ERA_ARDUINO_NB_CLIENT_HPP_
#define INC_ERA_ARDUINO_NB_CLIENT_HPP_

#if !defined(ERA_PROTO_TYPE)
    #define ERA_PROTO_TYPE            "NB"
#endif

#endif /* INC_ERA_ARDUINO_NB_CLIENT_HPP_ */
