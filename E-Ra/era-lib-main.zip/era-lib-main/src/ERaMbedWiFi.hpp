#ifndef INC_ERA_MBED_WIFI_HPP_
#define INC_ERA_MBED_WIFI_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleMbedWiFi.hpp>

#endif /* INC_ERA_MBED_WIFI_HPP_ */
